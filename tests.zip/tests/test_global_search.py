"""
Verifies fixes to CentralizedDB.global_search():

1. SECURITY: previously searched/returned results across EVERY
   workspace mixed together — no workspace_id filtering existed at
   all. Fixed to filter by workspace_id, matching the pattern already
   established for every other workspace-scoped feature.
2. Coverage expanded: distributors and retailers are now indexed
   separately (was one merged "masters" bucket), with phone/address/
   pincode now searchable too (previously only name/gst/zone/region).
   Sales Orders/CI (order_lifecycle_tracking) and Stock
   (article_master_v2) are now indexed too.
"""
from centralized_db_system.db import CentralizedDB


def test_search_is_workspace_isolated(tmp_path):
    db_path = str(tmp_path / "search_isolation.sqlite3")
    db = CentralizedDB(db_path)

    db.add_master_distributor(name="Bernina International", location="Delhi", workspace_id="ws-1")
    db.add_master_distributor(name="Some Other Company", location="Delhi", workspace_id="ws-2")

    with __import__("sqlite3").connect(db_path) as conn:
        db._refresh_global_search_index(conn)

    ws1_results = db.global_search("Delhi", workspace_id="ws-1")
    ws2_results = db.global_search("Delhi", workspace_id="ws-2")

    ws1_names = [r.get("contact_person") or r.get("firm_name") for r in ws1_results["results"]["distributors"]]
    ws2_names = [r.get("contact_person") or r.get("firm_name") for r in ws2_results["results"]["distributors"]]

    assert any("Bernina" in (n or "") for n in ws1_names)
    assert not any("Bernina" in (n or "") for n in ws2_names), (
        "BUG REPRODUCED: ws-2's search leaked ws-1's distributor"
    )
    assert any("Some Other Company" in (n or "") for n in ws2_names)
    assert not any("Some Other Company" in (n or "") for n in ws1_names)


def test_search_finds_distributor_by_phone_number(tmp_path):
    """Previously only name/gst/zone/region were indexed — phone
    number searches never matched anything."""
    db_path = str(tmp_path / "search_phone.sqlite3")
    db = CentralizedDB(db_path)

    db.add_master_distributor(
        name="Test Distributor", phone_number="9891788026", workspace_id="ws-1"
    )
    with __import__("sqlite3").connect(db_path) as conn:
        db._refresh_global_search_index(conn)

    results = db.global_search("9891788026", workspace_id="ws-1")
    matches = results["results"]["distributors"]
    assert any(
        (m.get("contact_person") == "Test Distributor") for m in matches
    ), f"Searching by phone number should find the distributor. Got: {matches}"


def test_search_returns_structured_columns_not_jumbled_text(tmp_path):
    """The person explicitly asked for name/distributor/phone/etc. in
    SEPARATE fields (a proper spreadsheet-like result), not one
    jumbled concatenated string."""
    db_path = str(tmp_path / "search_structured.sqlite3")
    db = CentralizedDB(db_path)

    dist_id = db.add_master_distributor(
        name="Bombay Dyeing Chennai", phone_number="9840440815", location="Chennai", workspace_id="ws-1"
    )
    db.add_master_retailer(
        name="Chennai Bombay Dyeing Showroom", distributor_id=dist_id,
        phone_number="9840440815", location="Chennai", workspace_id="ws-1",
    )
    with __import__("sqlite3").connect(db_path) as conn:
        db._refresh_global_search_index(conn)

    results = db.global_search("Chennai", workspace_id="ws-1")

    dist_match = results["results"]["distributors"][0]
    assert dist_match["firm_name"] == "Bombay Dyeing Chennai"
    assert dist_match["phone_number"] == "9840440815"
    assert dist_match["city"] == "Chennai"
    assert "content" not in dist_match, "Should return separate fields, not one jumbled content string"

    retail_match = results["results"]["retailers"][0]
    assert retail_match["name"] == "Chennai Bombay Dyeing Showroom"
    assert retail_match["distributor_name"] == "Bombay Dyeing Chennai"
    assert "content" not in retail_match


def test_search_covers_distributors_and_retailers_separately(tmp_path):
    db_path = str(tmp_path / "search_categories.sqlite3")
    db = CentralizedDB(db_path)

    dist_id = db.add_master_distributor(name="Bernina International", workspace_id="ws-1")
    db.add_master_retailer(name="Local Bernina Shop", distributor_id=dist_id, workspace_id="ws-1")

    with __import__("sqlite3").connect(db_path) as conn:
        db._refresh_global_search_index(conn)

    results = db.global_search("Bernina", workspace_id="ws-1")
    assert len(results["results"]["distributors"]) >= 1
    assert len(results["results"]["retailers"]) >= 1
