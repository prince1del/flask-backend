"""
Verifies the Order Sheet -> Filled Order -> SO -> CI fixes:

1. Company Profile was found completely missing from the codebase
   (table, functions, route, registration) despite being built and
   verified earlier — rebuilt here.
2. GST extraction now correctly finds GSTINs regardless of whether
   the checksum (last) character is a digit or a letter — the
   original regex only matched digit-ending GSTINs, silently missing
   real ones like Bombay Dyeing's own "27AAACT2328K1ZB" (ends in a
   letter).
3. CI-to-SO linking is no longer silently automatic — it now requires
   an explicit confirm call, which also creates the achievement
   record at that point (not at upload time).
"""
import re

from centralized_db_system.db import CentralizedDB


def test_company_profile_roundtrip(tmp_path):
    db_path = str(tmp_path / "company_profile_test.sqlite3")
    db = CentralizedDB(db_path)

    saved = db.upsert_company_profile(
        workspace_id="ws-1",
        company_name="Bombay Dyeing",
        gst_number="27aaact2328k1zb",  # lowercase on purpose
    )
    assert saved["gst_number"] == "27AAACT2328K1ZB", "GST should be normalized to uppercase"

    fetched = db.get_company_profile("ws-1")
    assert fetched["company_name"] == "Bombay Dyeing"

    # Workspace isolation
    other = db.get_company_profile("ws-2")
    assert other is None


def test_gstin_regex_handles_letter_ending_checksums():
    """
    BUG REPRODUCED (before fix): the original GSTIN regex required the
    last (checksum) character to be a digit, so Bombay Dyeing's own
    real GSTIN "27AAACT2328K1ZB" (ends in the letter B) was silently
    never detected — only the buyer's GST (which happened to end in a
    digit in our sample data) was found, making the "exclude our own
    GST" logic accidentally work by omission rather than by design.
    """
    GSTIN_PATTERN = re.compile(r"\b\d{2}[A-Z]{5}\d{4}[A-Z]\d[A-Z][A-Z0-9]\b")

    text = "GST NO: 27AAACT2328K1ZB   Buyer GST No : 07AAACB4006G1Z9"
    matches = GSTIN_PATTERN.findall(text.upper())
    assert "27AAACT2328K1ZB" in matches, "Letter-ending GSTIN should be detected"
    assert "07AAACB4006G1Z9" in matches, "Digit-ending GSTIN should still be detected"


def test_identify_buyer_gst_excludes_own_company():
    def _identify_buyer_gst(all_gst_numbers, own_company_gst):
        if not all_gst_numbers:
            return None
        own_normalized = (own_company_gst or "").strip().upper()
        candidates = [g for g in all_gst_numbers if g != own_normalized]
        if len(candidates) == 1:
            return candidates[0]
        return None

    result = _identify_buyer_gst(
        ["27AAACT2328K1ZB", "07AAACB4006G1Z9"], "27AAACT2328K1ZB"
    )
    assert result == "07AAACB4006G1Z9"


def test_dual_signal_so_matching_with_real_document_text(tmp_path):
    """
    Verifies the enhanced SO-upload matching: Buyer Code AND Buyer GST
    (extracted after excluding the workspace's own company GST) both
    independently resolve to the same distributor for a real Bombay
    Dyeing Sales Order document (Bernina International).
    """
    db_path = str(tmp_path / "dual_signal_test.sqlite3")
    db = CentralizedDB(db_path)

    db.upsert_company_profile(
        workspace_id="ws-1", company_name="Bombay Dyeing", gst_number="27AAACT2328K1ZB"
    )
    dist_id = db.add_master_distributor(
        name="Bernina International P Ltd",
        buyer_code="3220002",
        gst_no="07AAACB4006G1Z9",
        workspace_id="ws-1",
    )

    GSTIN_PATTERN = re.compile(r"\b\d{2}[A-Z]{5}\d{4}[A-Z]\d[A-Z][A-Z0-9]\b")

    def _extract_all_gstins(text):
        matches = GSTIN_PATTERN.findall((text or "").upper())
        seen = []
        for m in matches:
            if m not in seen:
                seen.append(m)
        return seen

    def _identify_buyer_gst(all_gst_numbers, own_company_gst):
        if not all_gst_numbers:
            return None
        own_normalized = (own_company_gst or "").strip().upper()
        candidates = [g for g in all_gst_numbers if g != own_normalized]
        return candidates[0] if len(candidates) == 1 else None

    real_so_text = (
        "THE BOMBAY DYEING & MANUFACTURING CO. LTD.\n"
        "GST NO: 27AAACT2328K1ZB\n"
        "Contract No : 102875606\n"
        "Buyer Code : 3220002\n"
        " BERNINA INTERNATIONAL P LTD\n"
        "GST No : 07AAACB4006G1Z9\n"
    )

    buyer_code = "3220002"  # already-proven extraction
    profile = db.get_company_profile("ws-1")
    buyer_gst = _identify_buyer_gst(
        _extract_all_gstins(real_so_text), profile["gst_number"]
    )

    matched_by_code = db.get_master_distributor_by_buyer_code(buyer_code, workspace_id="ws-1")
    matched_by_gst = db.get_master_distributor_by_gst(buyer_gst, workspace_id="ws-1")

    assert matched_by_code is not None and matched_by_code["id"] == dist_id
    assert matched_by_gst is not None and matched_by_gst["id"] == dist_id
    assert matched_by_code["id"] == matched_by_gst["id"], (
        "Both signals should agree on the same distributor for this real document"
    )


def test_confirm_ci_link_creates_achievement(tmp_path):
    """
    Verifies the new explicit confirm-link flow: linking a CI to an
    SO and creating the achievement now only happens via this single,
    explicit call — never automatically at upload time.
    """
    db_path = str(tmp_path / "confirm_link_test.sqlite3")
    db = CentralizedDB(db_path)

    tracking_id = db.create_order_lifecycle_tracking(
        order_ref_no="SO-TEST-001",
        distributor_id=1,
        payment_status="PENDING",
        workspace_id="ws-1",
    )

    # The link should not exist until explicitly confirmed.
    before = db.get_order_lifecycle_tracking(tracking_id, workspace_id="ws-1")
    assert before.get("commercial_invoice_file_reference") is None

    linked_tracking_id = db.link_commercial_invoice_to_order_lifecycle(
        order_ref_no="SO-TEST-001",
        commercial_invoice_file_reference="/uploads/ci_test.pdf",
        commercial_invoice_parsed={"total": 40194.0},
        workspace_id="ws-1",
    )
    assert linked_tracking_id == tracking_id

    achievement_id = db.create_achievement(
        order_lifecycle_tracking_id=tracking_id,
        amount=40194.0,
        currency="INR",
        source="ci",
        created_by="tester",
        workspace_id="ws-1",
        notes="Confirmed via test",
    )
    assert isinstance(achievement_id, int)

    achievements = db.list_achievements(tracking_id=tracking_id)
    assert len(achievements) == 1
    assert achievements[0]["amount"] == 40194.0
