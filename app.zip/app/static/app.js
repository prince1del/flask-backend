const authState = {
  accessToken: null,
  username: null,
  role: null,
};

const partyMasterState = {
  distributors: [],
  retailers: [],
};

let pendingUpdateMetadata = null;

const financeState = {
  accounts: [],
  gstReturns: [],
  vatReturns: [],
};

const appIconDefinitions = [
  { key: 'dashboard', icon: '📊', title: 'Dashboard', description: 'Open the analytics dashboard', action: 'openAnalyticsDashboard' },
  { key: 'fileLibrary', icon: '📁', title: 'File Library', description: 'Browse storage and documents', action: 'openFileLibrary' },
  { key: 'partyMaster', icon: '👥', title: 'Party Master', description: 'Manage distributors & retailers', action: 'openPartyMasterSection' },
  { key: 'orders', icon: '📦', title: 'Orders', description: 'Manage order workflows', action: 'openOrderManagement' },
  { key: 'invoices', icon: '🧾', title: 'Invoices', description: 'Create and review invoices', action: 'loadInvoices' },
  { key: 'settings', icon: '⚙️', title: 'Settings', description: 'Open app settings', action: 'openWorkspaceSettings' },
];

function saveAuthToken(token) {
  if (token) {
    localStorage.setItem('authAccessToken', token);
  } else {
    localStorage.removeItem('authAccessToken');
  }
}

function saveUsername(username) {
  if (username) {
    localStorage.setItem('authUsername', username);
  } else {
    localStorage.removeItem('authUsername');
  }
}

function saveRole(role) {
  if (role) {
    localStorage.setItem('authRole', role);
  } else {
    localStorage.removeItem('authRole');
  }
}

// Sales Executives only see what's actually been built and tested so
// far in NEXORA — everything else (Purchase, Inventory, Finance,
// Reports, Analytics, Orders, Approvals, Cloud Hub, Banking, Settings,
// and the still-decorative Sales sub-tabs) is hidden from the UI
// only. Nothing on the backend is touched, so re-enabling any of
// these later is just uncommenting/removing an id from this list —
// no rebuilding required.
const SALES_EXECUTIVE_HIDDEN_NAV_IDS = [
  'nav-purchase', 'nav-inventory', 'nav-finance', 'nav-reports',
  'nav-analytics', 'nav-orders', 'nav-approvals', 'nav-cloudhub',
  'nav-banking', 'nav-settings',
];
const SALES_EXECUTIVE_HIDDEN_SALES_SUBTAB_IDS = [
  'sales-tab-overview', 'sales-tab-invoices', 'sales-tab-orders', 'sales-tab-reports',
];
const SALES_EXECUTIVE_HIDDEN_ELEMENT_IDS = [
  'sales-fake-metrics',
  'dashboard-fake-overview-cards',
  'dashboard-fake-ai-summary',
  'dashboard-fake-health',
  'dashboard-fake-activities',
  'dashboard-fake-priorities',
  'dashboard-fake-rightbar',
];

function applyRoleBasedUI() {
  if (authState.role !== 'sales_executive') {
    return;
  }
  SALES_EXECUTIVE_HIDDEN_NAV_IDS.forEach((id) => {
    document.getElementById(id)?.classList.add('hidden');
  });
  SALES_EXECUTIVE_HIDDEN_SALES_SUBTAB_IDS.forEach((id) => {
    document.getElementById(id)?.classList.add('hidden');
  });
  SALES_EXECUTIVE_HIDDEN_ELEMENT_IDS.forEach((id) => {
    document.getElementById(id)?.classList.add('hidden');
  });
  document.getElementById('dashboard-honest-placeholder')?.classList.remove('hidden');
}

function loadAuthState() {
  authState.accessToken = localStorage.getItem('authAccessToken');
  authState.username = localStorage.getItem('authUsername');
  authState.role = localStorage.getItem('authRole');
  const userInfoEl = document.getElementById('user-info') || document.getElementById('user-name');
  const askNexoraButton = document.getElementById('ask-nexora-btn');

  if (authState.accessToken) {
    document.getElementById('loginModal')?.classList.add('hidden');
    document.getElementById('dashboard')?.classList.remove('hidden');
    askNexoraButton?.classList.remove('hidden');
    applyRoleBasedUI();
    if (userInfoEl) {
      userInfoEl.textContent = authState.username || 'Admin User';
    }
  } else {
    askNexoraButton?.classList.add('hidden');
  }
}

function getStoredUpdateVersion(key) {
  return localStorage.getItem(key) || null;
}

function shouldShowUpdate(version, manual) {
  const deferredVersion = getStoredUpdateVersion('deferredUpdateVersion');
  const pendingVersion = getStoredUpdateVersion('pendingUpdateVersion');
  if (manual) {
    return true;
  }
  if (deferredVersion === version || pendingVersion === version) {
    return false;
  }
  return true;
}

function initApp() {
  loadAuthState();
  updateGreeting();
  loadRecentActivities();
  loadDashboard();
  loadYears();
  loadAppIconTray();
  checkForUpdates();
}

async function login() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const errorEl = document.getElementById('loginError');

  if (!username || !password) {
    errorEl.textContent = 'Username and password are required.';
    return;
  }

  try {
    const response = await fetch('/api/v1/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
      credentials: 'same-origin',
    });

    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error?.message || 'Login failed');
    }

    authState.accessToken = data.data.access_token;
    authState.username = data.data.user.username || username;
    authState.role = data.data.user.role || null;
    saveAuthToken(authState.accessToken);
    saveUsername(authState.username);
    saveRole(authState.role);
    applyRoleBasedUI();

    try {
      await fetch('/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({ username, password }).toString(),
        credentials: 'same-origin',
      });
    } catch (e) {
      console.warn('Session login failed:', e);
    }

    document.getElementById('loginModal')?.classList.add('hidden');
    document.getElementById('dashboard')?.classList.remove('hidden');
    document.getElementById('ask-nexora-btn')?.classList.remove('hidden');
    const userInfoEl = document.getElementById('user-info') || document.getElementById('user-name');
    if (userInfoEl) {
      userInfoEl.textContent = authState.username;
    }
    errorEl.textContent = '';
    loadDashboard();
    loadYears();
  } catch (error) {
    errorEl.textContent = error.message || 'Invalid username or password.';
  }
}

async function logout(reason) {
  try {
    await fetch('/logout', {
      method: 'GET',
      credentials: 'same-origin',
    });
  } catch (e) {
    console.warn('Logout request failed:', e);
  }

  authState.accessToken = null;
  authState.username = null;
  authState.role = null;
  saveAuthToken(null);
  saveUsername(null);
  saveRole(null);
  closeAllModals();
  const loginModal = document.getElementById('loginModal');
  const dashboard = document.getElementById('dashboard');
  const loginError = document.getElementById('loginError');
  const askNexoraButton = document.getElementById('ask-nexora-btn');
  if (loginModal) loginModal.classList.remove('hidden');
  if (dashboard) dashboard.classList.add('hidden');
  if (askNexoraButton) askNexoraButton.classList.add('hidden');
  if (loginError) {
    loginError.textContent = reason === 'session-expired'
      ? 'Your session has expired. Please log in again.'
      : '';
  }
}

function loadDashboard() {
  updateStorageStatus();
}

async function fetchWithAuth(url, options = {}) {
  const headers = options.headers ? { ...options.headers } : {};
  if (authState.accessToken) {
    headers.Authorization = `Bearer ${authState.accessToken}`;
  }
  const response = await fetch(url, { ...options, headers, credentials: 'same-origin' });
  if (response.status === 401) {
    logout('session-expired');
  }
  return response;
}

function getApiErrorMessage(data, defaultMessage = 'An error occurred') {
  if (!data) {
    return defaultMessage;
  }
  if (typeof data === 'string') {
    return data;
  }
  if (data.error) {
    if (typeof data.error === 'string') {
      return data.error;
    }
    if (data.error.message) {
      return data.error.message;
    }
    if (data.error.code) {
      return `${data.error.code}: ${data.error.message || defaultMessage}`;
    }
  }
  if (data.message) {
    return data.message;
  }
  return defaultMessage;
}

function formatBytes(bytes) {
  if (bytes === null || bytes === undefined) {
    return 'N/A';
  }
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  let index = 0;
  let value = Number(bytes);
  while (value >= 1024 && index < sizes.length - 1) {
    value /= 1024;
    index += 1;
  }
  return `${value.toFixed(1)} ${sizes[index]}`;
}

async function updateStorageStatus() {
  const statusEl = document.getElementById('storage-status');
  const infoEl = document.getElementById('storage-info');

  if (statusEl) {
    statusEl.textContent = 'Checking storage status...';
  }
  if (infoEl) {
    infoEl.textContent = 'Loading storage details...';
  }

  if (!authState.accessToken) {
    if (statusEl) {
      statusEl.textContent = 'Storage features require login.';
    }
    if (infoEl) {
      infoEl.textContent = 'Connect Google Drive after login to see storage information.';
    }
    return;
  }

  try {
    const accountResponse = await fetchWithAuth('/api/v1/storage/account');
    const accountData = await accountResponse.json();
    if (!accountResponse.ok || !accountData.success) {
      throw new Error(accountData.error || 'Unable to load storage account');
    }

    if (!accountData.data.connected) {
      if (statusEl) {
        statusEl.textContent = 'Google Drive not connected';
      }
      if (infoEl) {
        infoEl.textContent = 'Please connect your storage account to enable sync and file library features.';
      }
      return;
    }

    const dashboardResponse = await fetchWithAuth('/api/v1/storage/dashboard');
    const dashboardData = await dashboardResponse.json();
    if (!dashboardResponse.ok || !dashboardData.success) {
      throw new Error(dashboardData.error || 'Unable to load storage dashboard');
    }

    if (statusEl) {
      statusEl.textContent = 'Google Drive connected';
    }
    if (infoEl) {
      const stats = dashboardData.data.storage_info || {};
      const fileCount = stats.file_count ?? 0;
      const totalSize = stats.total_size ?? 0;
      const quota = stats.quota ?? 0;
      infoEl.textContent = `Files: ${fileCount} • Used: ${formatBytes(totalSize)} / ${formatBytes(quota)}`;
    }
  } catch (error) {
    if (statusEl) {
      statusEl.textContent = 'Storage status unavailable';
    }
    if (infoEl) {
      infoEl.textContent = error.message || 'Unable to fetch storage information.';
    }
  }
}

function showUploadModal() {
  toggleModal('uploadModal', true);
}

function showAddYearModal() {
  toggleModal('addYearModal', true);
}

async function showManualEntryModal() {
  await loadYears();
  toggleModal('manualEntryModal', true);
}

async function showReportUploadModal() {
  await loadYears();
  toggleModal('reportUploadModal', true);
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) {
    modal.classList.add('hidden');
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal').forEach((modal) => {
    modal.classList.add('hidden');
  });
}

function closeScan() {
  closeModal('scanModal');
}

function toggleModal(id, show) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.toggle('hidden', !show);
}

function populateYearSelects(years = []) {
  const allYears = years;
  const yearSelect = document.getElementById('yearSelect');
  const reportYear = document.getElementById('reportYear');

  if (!yearSelect || !reportYear) return;

  yearSelect.innerHTML = '';
  reportYear.innerHTML = '';

  if (!allYears.length) {
    allYears.push({ id: 1, year: '2024-2025' }, { id: 2, year: '2025-2026' });
  }

  allYears.forEach((year) => {
    const option1 = document.createElement('option');
    option1.value = year.id;
    option1.textContent = year.year;
    yearSelect.appendChild(option1);

    const option2 = document.createElement('option');
    option2.value = year.id;
    option2.textContent = year.year;
    reportYear.appendChild(option2);
  });
}

async function loadYears() {
  const summary = document.getElementById('target-summary');
  const yearsList = document.getElementById('years-list');

  if (summary) {
    summary.innerHTML = '<p>Loading fiscal year summary...</p>';
  }
  if (yearsList) {
    yearsList.innerHTML = '<p>Loading configured years...</p>';
  }

  try {
    const response = await fetchWithAuth('/api/v1/target-achievement/years');
    const data = await response.json();
    if (response.ok && data.success) {
      const years = data.data.years || [];
      if (summary) {
        summary.innerHTML = years.length
          ? years
              .map(
                (year) =>
                  `<p><strong>${year.year}</strong>: target ₹${Number(year.target).toLocaleString()}</p>`
              )
              .join('')
          : '<p>No fiscal years configured yet. Add one to begin tracking performance.</p>';
      }
      if (yearsList) {
        yearsList.innerHTML = years.length
          ? years
              .map(
                (year) =>
                  `<div class="list-item"><strong>${year.year}</strong> — target ₹${Number(year.target).toLocaleString()}</div>`
              )
              .join('')
          : '<div class="list-item">No configured years found.</div>';
      }
      populateYearSelects(years);
      return;
    }

    throw new Error(data.error || 'Unable to load fiscal years');
  } catch (error) {
    if (summary) {
      summary.innerHTML = '<p>Unable to load fiscal year information.</p>';
    }
    if (yearsList) {
      yearsList.innerHTML = '<div class="list-item">Unable to load configurations.</div>';
    }
    console.warn('Failed to load years:', error);
  }
}

async function connectGoogleDrive() {
  try {
    if (!authState.accessToken) {
      alert('Please login to connect Google Drive.');
      return;
    }

    const popup = window.open('about:blank', '_blank');
    if (!popup) {
      alert('Please disable your popup blocker and try again.');
      return;
    }

    const response = await fetchWithAuth('/api/v1/storage/connect', {
      method: 'POST',
    });
    const data = await response.json();

    if (!response.ok || !data.success) {
      popup.close();
      throw new Error(getApiErrorMessage(data, 'Failed to initiate Google Drive connection'));
    }

    if (data.data && data.data.oauth_url) {
      popup.location = data.data.oauth_url;
      alert('Google Drive connection started. Complete authorization in the new window.');
    } else {
      popup.close();
      alert('Google Drive connection started. Please complete the authorization in the new browser window.');
    }
  } catch (error) {
    alert(error.message || 'Unable to connect Google Drive. Please ensure you are logged in and try again.');
  }
}

window.addEventListener('message', (event) => {
  if (!event.data || typeof event.data !== 'object') {
    return;
  }
  if (event.data.type === 'google_drive_connected') {
    updateStorageStatus();
    alert('Google Drive connected successfully.');
  }
  if (event.data.type === 'google_drive_connection_failed') {
    alert('Google Drive connection failed: ' + (event.data.message || 'Unknown error'));
  }
});

async function syncGoogleDrive() {
  try {
    if (!authState.accessToken) {
      alert('Please login to sync Google Drive.');
      return;
    }

    const response = await fetchWithAuth('/api/v1/storage/sync', {
      method: 'POST',
    });
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || 'Sync failed');
    }

    alert(data.data?.message || 'Google Drive sync started successfully.');
  } catch (error) {
    alert(error.message || 'Google Drive sync failed.');
  }
}

async function openJsonPage(title, url) {
  if (!authState.accessToken) {
    alert('Please login to access this resource.');
    return;
  }

  try {
    const response = await fetchWithAuth(url);
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Unable to load content');
    }

    const win = window.open('', '_blank');
    if (!win) {
      alert('Unable to open new window. Please disable your popup blocker.');
      return;
    }
    win.document.write(`<!doctype html><html><head><title>${title}</title><style>body{font-family:system-ui,Arial;margin:1rem;}pre{white-space:pre-wrap;word-break:break-word;background:#f5f5f5;padding:1rem;border-radius:12px;}</style></head><body><h1>${title}</h1><pre>${JSON.stringify(data, null, 2)}</pre></body></html>`);
    win.document.close();
  } catch (error) {
    alert(error.message || 'Unable to load data.');
  }
}

function openFileLibrary() {
  openJsonPage('Storage File Library', '/api/v1/storage/files');
}

function openPartyMasterSection() {
  document.getElementById('party-master-section')?.classList.remove('hidden');
  openPartyMasterTab('distributor');
  loadDistributors();
  loadRetailers();
  loadDistributorSelect();
  const section = document.getElementById('party-master-section');
  section?.scrollIntoView({ behavior: 'smooth' });
}

function closePartyMasterSection() {
  document.getElementById('party-master-section')?.classList.add('hidden');
}

function openPartyMasterTab(tab) {
  const distributorTab = document.getElementById('distributor-tab-button');
  const retailerTab = document.getElementById('retailer-tab-button');
  const distributorPanel = document.getElementById('distributor-panel');
  const retailerPanel = document.getElementById('retailer-panel');

  if (tab === 'retailer') {
    distributorTab?.classList.remove('active');
    retailerTab?.classList.add('active');
    distributorPanel?.classList.add('hidden');
    retailerPanel?.classList.remove('hidden');
  } else {
    distributorTab?.classList.add('active');
    retailerTab?.classList.remove('active');
    distributorPanel?.classList.remove('hidden');
    retailerPanel?.classList.add('hidden');
  }
}

let partyDetailRecordsCache = [];

const PARTY_DETAIL_LABELS = {
  name: 'Name', firm_name: 'Firm Name', contactPerson: 'Contact Person',
  contact_person: 'Contact Person', distributor: 'Distributor',
  distributor_name: 'Distributor', gst: 'GST Number', gst_no: 'GST Number',
  gst_number: 'GST Number', territory: 'Territory', zone: 'Zone',
  region: 'Region / State', state: 'State', city: 'City', location: 'City',
  pincode: 'Pincode', pin_code: 'Pincode', address: 'Address',
  storeType: 'Store Type', category: 'Category', phone: 'Phone',
  phone_number: 'Phone', phone_number_2: 'Phone 2', email: 'Email',
  creditLimit: 'Credit Limit', credit_limit: 'Credit Limit',
};

function showPartyDetail(record, editFn) {
  const title = document.getElementById('party-detail-title');
  const body = document.getElementById('party-detail-body');
  const editBtn = document.getElementById('party-detail-edit-btn');

  title.textContent = record.name || record.firm_name || 'Details';
  body.innerHTML = Object.entries(record)
    .filter(([key, value]) => {
      if (['actions', 'distributorKey'].includes(key)) return false;
      return value !== null && value !== undefined && value !== '' && value !== '-';
    })
    .map(([key, value]) => {
      const label = PARTY_DETAIL_LABELS[key] || key;
      return `<div><strong>${label}:</strong><br>${value}</div>`;
    })
    .join('');

  if (editFn) {
    editBtn.style.display = 'inline-block';
    editBtn.onclick = () => {
      closeModal('party-detail-modal');
      editFn();
    };
  } else {
    editBtn.style.display = 'none';
  }

  toggleModal('party-detail-modal', true);
}

function renderDynamicTable(theadId, tbodyId, records, columnDefs) {
  const thead = document.getElementById(theadId);
  const tbody = document.getElementById(tbodyId);
  if (!thead || !tbody) return;

  // Only show columns that have at least one non-empty value across
  // all records — "jo feed hai wahi dikhaye, jo nahi feed hai use
  // hide kare".
  const visibleColumns = columnDefs.filter((col) => {
    if (col.alwaysShow) return true;
    return records.some((r) => {
      const v = r[col.key];
      return v !== null && v !== undefined && v !== '' && v !== '-';
    });
  });

  if (!visibleColumns.length || !records.length) {
    thead.innerHTML = '';
    tbody.innerHTML = '<tr><td>No data yet.</td></tr>';
    return;
  }

  thead.innerHTML = `<tr>${visibleColumns.map((c) => `<th>${c.label}</th>`).join('')}</tr>`;
  partyDetailRecordsCache = records;
  tbody.innerHTML = records
    .map((r, index) => {
      const cells = visibleColumns
        .map((c) => {
          if (c.isAction) return `<td>${r[c.key] || ''}</td>`;
          const v = r[c.key];
          return `<td>${v !== null && v !== undefined && v !== '' ? v : '-'}</td>`;
        })
        .join('');
      return `<tr onclick="if(!event.target.closest('button')){showPartyDetail(partyDetailRecordsCache[${index}])}">${cells}</tr>`;
    })
    .join('');
}

async function loadDistributors() {
  try {
    const response = await fetchWithAuth('/api/v1/parties/distributors?limit=200');
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to load distributors');
    }
    partyMasterState.distributors = data.data.results || [];

    let masterDistributors = [];
    try {
      const masterResponse = await fetchWithAuth('/api/v1/masters/distributors?limit=5000');
      const masterData = await masterResponse.json();
      if (masterResponse.ok && masterData.success) {
        masterDistributors = masterData.data;
      }
    } catch (e) {
      console.warn('Failed to load master distributors for combined view:', e);
    }

    const records = [
      ...partyMasterState.distributors.map((d) => ({
        name: d.name,
        contactPerson: d.contact_person,
        gst: d.gst_number,
        territory: d.territory,
        city: d.city,
        state: d.state,
        pincode: d.pin_code,
        address: d.address,
        phone: d.phone,
        creditLimit: d.credit_limit,
        actions: `<button onclick="editDistributor(${d.id})" class="btn btn-secondary">Edit</button> <button onclick="deleteDistributor(${d.id})" class="btn btn-danger">Delete</button>`,
      })),
      ...masterDistributors.map((d) => ({
        name: d.firm_name || d.name,
        buyerCode: d.distributor_id,
        contactPerson: d.name,
        gst: d.gst_no,
        territory: d.zone,
        city: d.location,
        state: d.region,
        pincode: d.pincode,
        address: d.address,
        phone: d.phone_number,
        creditLimit: d.credit_limit,
        actions: `<button onclick="event.stopPropagation(); editMasterDistributor(${d.id})" class="btn btn-secondary">Edit</button> <button onclick="event.stopPropagation(); deleteMasterDistributor(${d.id})" class="btn btn-danger">Delete</button>`,
      })),
    ];

    renderDynamicTable('distributor-thead', 'distributor-tbody', records, [
      { key: 'name', label: 'Name', alwaysShow: true },
      { key: 'buyerCode', label: 'Distributor Code' },
      { key: 'contactPerson', label: 'Contact Person' },
      { key: 'gst', label: 'GST Number' },
      { key: 'territory', label: 'Territory / Zone' },
      { key: 'city', label: 'City' },
      { key: 'state', label: 'State / Region' },
      { key: 'pincode', label: 'Pincode' },
      { key: 'address', label: 'Address' },
      { key: 'phone', label: 'Phone' },
      { key: 'creditLimit', label: 'Credit Limit' },
      { key: 'actions', label: 'Actions', isAction: true, alwaysShow: true },
    ]);
  } catch (error) {
    console.warn('Failed to load distributors:', error);
  }
}

function populateRetailerDistributorFilterOptions(records) {
  const select = document.getElementById('retailer-distributor-filter');
  if (!select) return;
  const currentValue = select.value;
  const uniqueDistributors = [...new Set(records.map((r) => r.distributorKey).filter(Boolean))].sort();
  select.innerHTML = ['<option value="">-- All Distributors --</option>']
    .concat(uniqueDistributors.map((name) => `<option value="${name}">${name}</option>`))
    .join('');
  select.value = currentValue;
}

function filterRetailersByDistributor() {
  const filterValue = document.getElementById('retailer-distributor-filter').value;
  const records = partyMasterState.allRetailerRecords || [];
  const filteredRecords = filterValue
    ? records.filter((r) => r.distributorKey === filterValue)
    : records;

  renderDynamicTable('retailer-thead', 'retailer-tbody', filteredRecords, [
    { key: 'name', label: 'Name', alwaysShow: true },
    { key: 'contactPerson', label: 'Contact Person' },
    { key: 'distributor', label: 'Distributor' },
    { key: 'gst', label: 'GST Number' },
    { key: 'territory', label: 'Territory' },
    { key: 'city', label: 'City' },
    { key: 'state', label: 'State' },
    { key: 'pincode', label: 'Pincode' },
    { key: 'address', label: 'Address' },
    { key: 'storeType', label: 'Store Type' },
    { key: 'phone', label: 'Phone' },
    { key: 'actions', label: 'Actions', isAction: true, alwaysShow: true },
  ]);
}

async function loadRetailers() {
  try {
    const response = await fetchWithAuth('/api/v1/parties/retailers?limit=200');
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to load retailers');
    }
    partyMasterState.retailers = data.data.results || [];

    let masterRetailers = [];
    try {
      const masterResponse = await fetchWithAuth('/api/v1/masters/retailers?limit=5000');
      const masterData = await masterResponse.json();
      if (masterResponse.ok && masterData.success) {
        masterRetailers = masterData.data;
      }
    } catch (e) {
      console.warn('Failed to load master retailers for combined view:', e);
    }

    const records = [
      ...partyMasterState.retailers.map((r) => {
        const distributor = partyMasterState.distributors.find((d) => d.id === r.distributor_id);
        const distributorLabel = distributor ? distributor.name : (r.distributor_id == null ? 'Unassigned' : r.distributor_id);
        return {
          name: r.name,
          contactPerson: r.contact_person,
          distributor: distributorLabel,
          distributorKey: distributorLabel,
          gst: r.gst_number,
          territory: r.territory,
          city: r.city,
          state: r.state,
          pincode: r.pin_code,
          address: r.address,
          storeType: r.store_type,
          phone: r.phone,
          actions: `<button onclick="editRetailer(${r.id})" class="btn btn-secondary">Edit</button> <button onclick="deleteRetailer(${r.id})" class="btn btn-danger">Delete</button>`,
        };
      }),
      ...masterRetailers.map((r) => ({
        name: r.name,
        contactPerson: r.contact_person,
        distributor: r.distributor_name || 'Unassigned',
        distributorKey: r.distributor_name || 'Unassigned',
        gst: r.gst_no,
        territory: r.location,
        city: r.location,
        state: r.state,
        pincode: r.pincode,
        address: r.address,
        storeType: r.category,
        phone: r.phone_number,
        actions: `<button onclick="event.stopPropagation(); editMasterRetailer(${r.id})" class="btn btn-secondary">Edit</button> <button onclick="event.stopPropagation(); deleteMasterRetailer(${r.id})" class="btn btn-danger">Delete</button>`,
      })),
    ];

    partyMasterState.allRetailerRecords = records;
    populateRetailerDistributorFilterOptions(records);

    const filterValue = document.getElementById('retailer-distributor-filter')
      ? document.getElementById('retailer-distributor-filter').value
      : '';
    const filteredRecords = filterValue
      ? records.filter((r) => r.distributorKey === filterValue)
      : records;

    renderDynamicTable('retailer-thead', 'retailer-tbody', filteredRecords, [
      { key: 'name', label: 'Name', alwaysShow: true },
      { key: 'contactPerson', label: 'Contact Person' },
      { key: 'distributor', label: 'Distributor' },
      { key: 'gst', label: 'GST Number' },
      { key: 'territory', label: 'Territory' },
      { key: 'city', label: 'City' },
      { key: 'state', label: 'State' },
      { key: 'pincode', label: 'Pincode' },
      { key: 'address', label: 'Address' },
      { key: 'storeType', label: 'Store Type' },
      { key: 'phone', label: 'Phone' },
      { key: 'actions', label: 'Actions', isAction: true, alwaysShow: true },
    ]);
  } catch (error) {
    console.warn('Failed to load retailers:', error);
  }
}

async function loadDistributorSelect() {
  try {
    if (!partyMasterState.distributors.length) {
      await loadDistributors();
    }
    const select = document.getElementById('retailer-distributor');
    if (!select) return;
    const options = ['<option value="">-- Unassigned --</option>']
      .concat(partyMasterState.distributors.map((d) => `<option value="${d.id}">${d.name}</option>`));
    select.innerHTML = options.join('');
  } catch (error) {
    console.warn('Failed to populate distributor select:', error);
  }
}

function openDistributorForm() {
  document.getElementById('distributor-id').value = '';
  document.getElementById('distributor-form-title').textContent = 'Add Distributor';
  document.getElementById('dist-name').value = '';
  document.getElementById('dist-contact-person').value = '';
  document.getElementById('dist-gst').value = '';
  document.getElementById('dist-territory').value = '';
  document.getElementById('dist-city').value = '';
  document.getElementById('dist-state').value = '';
  document.getElementById('dist-pincode').value = '';
  document.getElementById('dist-phone').value = '';
  document.getElementById('dist-email').value = '';
  document.getElementById('dist-address').value = '';
  document.getElementById('dist-credit-limit').value = '';
  toggleModal('distributor-form-modal', true);
}

function openRetailerForm() {
  document.getElementById('retailer-id').value = '';
  document.getElementById('retailer-form-title').textContent = 'Add Retailer';
  document.getElementById('retailer-name').value = '';
  document.getElementById('retailer-contact-person').value = '';
  document.getElementById('retailer-gst').value = '';
  document.getElementById('retailer-store-type').value = '';
  document.getElementById('retailer-territory').value = '';
  document.getElementById('retailer-city').value = '';
  document.getElementById('retailer-state').value = '';
  document.getElementById('retailer-pincode').value = '';
  document.getElementById('retailer-phone').value = '';
  document.getElementById('retailer-email').value = '';
  document.getElementById('retailer-address').value = '';
  loadDistributorSelect();
  toggleModal('retailer-form-modal', true);
}

async function saveDistributor(event) {
  event.preventDefault();
  const id = document.getElementById('distributor-id').value;
  const body = {
    name: document.getElementById('dist-name').value.trim(),
    contact_person: document.getElementById('dist-contact-person').value.trim() || undefined,
    gst_number: document.getElementById('dist-gst').value.trim() || undefined,
    territory: document.getElementById('dist-territory').value.trim() || undefined,
    city: document.getElementById('dist-city').value.trim() || undefined,
    state: document.getElementById('dist-state').value.trim() || undefined,
    pin_code: document.getElementById('dist-pincode').value.trim() || undefined,
    phone: document.getElementById('dist-phone').value.trim() || undefined,
    email: document.getElementById('dist-email').value.trim() || undefined,
    address: document.getElementById('dist-address').value.trim() || undefined,
    credit_limit: document.getElementById('dist-credit-limit').value.trim()
      ? parseFloat(document.getElementById('dist-credit-limit').value)
      : undefined,
  };

  if (!body.name) {
    alert('Firm name is required.');
    return;
  }

  try {
    const url = id ? `/api/v1/parties/distributors/${id}` : '/api/v1/parties/distributors';
    const method = id ? 'PUT' : 'POST';
    let response = await fetchWithAuth(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    let data = await response.json();

    if (response.status === 409 && data.requires_confirmation) {
      const proceed = confirm(data.message || 'A similar distributor already exists. Save anyway?');
      if (!proceed) {
        return;
      }
      response = await fetchWithAuth(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...body, force_save: true }),
      });
      data = await response.json();
    }

    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to save distributor');
    }
    closeModal('distributor-form-modal');
    loadDistributors();
    loadDistributorSelect();
    alert('Distributor saved successfully.');
  } catch (error) {
    alert(error.message || 'Error saving distributor.');
  }
}

async function editDistributor(id) {
  try {
    const response = await fetchWithAuth(`/api/v1/parties/distributors/${id}`);
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to load distributor');
    }
    const distributor = data.data;
    document.getElementById('distributor-id').value = distributor.id;
    document.getElementById('distributor-form-title').textContent = 'Edit Distributor';
    document.getElementById('dist-name').value = distributor.name || '';
    document.getElementById('dist-contact-person').value = distributor.contact_person || '';
    document.getElementById('dist-gst').value = distributor.gst_number || '';
    document.getElementById('dist-territory').value = distributor.territory || '';
    document.getElementById('dist-city').value = distributor.city || '';
    document.getElementById('dist-state').value = distributor.state || '';
    document.getElementById('dist-pincode').value = distributor.pin_code || '';
    document.getElementById('dist-phone').value = distributor.phone || '';
    document.getElementById('dist-email').value = distributor.email || '';
    document.getElementById('dist-address').value = distributor.address || '';
    document.getElementById('dist-credit-limit').value = distributor.credit_limit || '';
    toggleModal('distributor-form-modal', true);
  } catch (error) {
    alert(error.message || 'Error loading distributor.');
  }
}

async function deleteDistributor(id) {
  if (!confirm('Delete this distributor? This will mark it inactive.')) {
    return;
  }
  try {
    const response = await fetchWithAuth(`/api/v1/parties/distributors/${id}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to delete distributor');
    }
    loadDistributors();
    loadRetailers();
    loadDistributorSelect();
  } catch (error) {
    alert(error.message || 'Error deleting distributor.');
  }
}

async function saveRetailer(event) {
  event.preventDefault();
  const id = document.getElementById('retailer-id').value;
  const distributorRaw = document.getElementById('retailer-distributor').value;
  const body = {
    name: document.getElementById('retailer-name').value.trim(),
    distributor_id: distributorRaw ? parseInt(distributorRaw, 10) : null,
    contact_person: document.getElementById('retailer-contact-person').value.trim() || undefined,
    gst_number: document.getElementById('retailer-gst').value.trim() || undefined,
    store_type: document.getElementById('retailer-store-type').value.trim() || undefined,
    territory: document.getElementById('retailer-territory').value.trim() || undefined,
    city: document.getElementById('retailer-city').value.trim() || undefined,
    state: document.getElementById('retailer-state').value.trim() || undefined,
    pin_code: document.getElementById('retailer-pincode').value.trim() || undefined,
    phone: document.getElementById('retailer-phone').value.trim() || undefined,
    email: document.getElementById('retailer-email').value.trim() || undefined,
    address: document.getElementById('retailer-address').value.trim() || undefined,
  };

  if (!body.name) {
    alert('Firm name is required.');
    return;
  }

  try {
    const url = id ? `/api/v1/parties/retailers/${id}` : '/api/v1/parties/retailers';
    const method = id ? 'PUT' : 'POST';
    let response = await fetchWithAuth(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    let data = await response.json();

    if (response.status === 409 && data.requires_confirmation) {
      const proceed = confirm(data.message || 'A similar retailer already exists. Save anyway?');
      if (!proceed) {
        return;
      }
      response = await fetchWithAuth(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...body, force_save: true }),
      });
      data = await response.json();
    }

    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to save retailer');
    }
    closeModal('retailer-form-modal');
    loadRetailers();
    alert('Retailer saved successfully.');
  } catch (error) {
    alert(error.message || 'Error saving retailer.');
  }
}

async function editRetailer(id) {
  try {
    await loadDistributorSelect();
    const response = await fetchWithAuth(`/api/v1/parties/retailers/${id}`);
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to load retailer');
    }
    const retailer = data.data;
    document.getElementById('retailer-id').value = retailer.id;
    document.getElementById('retailer-form-title').textContent = 'Edit Retailer';
    document.getElementById('retailer-name').value = retailer.name || '';
    document.getElementById('retailer-contact-person').value = retailer.contact_person || '';
    document.getElementById('retailer-gst').value = retailer.gst_number || '';
    document.getElementById('retailer-store-type').value = retailer.store_type || '';
    document.getElementById('retailer-territory').value = retailer.territory || '';
    document.getElementById('retailer-city').value = retailer.city || '';
    document.getElementById('retailer-state').value = retailer.state || '';
    document.getElementById('retailer-pincode').value = retailer.pin_code || '';
    document.getElementById('retailer-phone').value = retailer.phone || '';
    document.getElementById('retailer-email').value = retailer.email || '';
    document.getElementById('retailer-address').value = retailer.address || '';
    document.getElementById('retailer-distributor').value = retailer.distributor_id != null ? retailer.distributor_id : '';
    toggleModal('retailer-form-modal', true);
  } catch (error) {
    alert(error.message || 'Error loading retailer.');
  }
}

async function deleteRetailer(id) {
  if (!confirm('Delete this retailer? This will mark it inactive.')) {
    return;
  }
  try {
    const response = await fetchWithAuth(`/api/v1/parties/retailers/${id}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Unable to delete retailer');
    }
    loadRetailers();
  } catch (error) {
    alert(error.message || 'Error deleting retailer.');
  }
}

function openTargetSummary() {
  window.location.href = '/reports';
}

function openReports() {
  window.location.href = '/reports';
}

function openAnalyticsDashboard() {
  if (!authState.accessToken) {
    const loginModal = document.getElementById('loginModal');
    if (loginModal) {
      loginModal.classList.remove('hidden');
    }
    alert('Please login to access Ask NEXORA.');
    return;
  }
  window.location.href = '/analytics';
}

function openProfileSettings() {
  window.location.href = '/settings/schema?entity=distributor';
}

function openWorkspaceSettings() {
  window.location.href = '/admin/database';
}

function openOrderManagement() {
  openModule('Orders');
}

function openApprovalsPage() {
  openModule('Approvals');
}

function openBankingSection() {
  openModule('Banking');
}

function openFinanceWorkspace() {
  document.getElementById('dashboard')?.classList.add('hidden');
  document.getElementById('sales-workspace')?.classList.add('hidden');
  document.getElementById('purchase-workspace')?.classList.add('hidden');
  document.getElementById('inventory-workspace')?.classList.add('hidden');
  document.getElementById('party-master-section')?.classList.add('hidden');
  document.getElementById('orders-workspace')?.classList.add('hidden');
  document.getElementById('approvals-workspace')?.classList.add('hidden');
  document.getElementById('banking-workspace')?.classList.add('hidden');
  document.getElementById('finance-workspace')?.classList.remove('hidden');
  setActiveSidebarItem('Finance');
  loadFinanceSummary();
}

function openAccountModal() {
  document.getElementById('finance-account-name').value = '';
  document.getElementById('finance-account-type').value = 'asset';
  document.getElementById('finance-account-opening-balance').value = '0';
  document.getElementById('finance-account-notes').value = '';
  toggleModal('finance-account-modal', true);
}

function openNewOrderModal() {
  document.getElementById('order-date').value = new Date().toISOString().slice(0, 10);
  document.getElementById('order-amount').value = '0';
  document.getElementById('order-tax-rate').value = '0';
  loadOrderDistributorsAndRetailers();
  toggleModal('new-order-modal', true);
}

async function loadOrderDistributorsAndRetailers() {
  try {
    await Promise.all([loadDistributors(), loadRetailers()]);
    const distributorSelect = document.getElementById('order-distributor');
    const retailerSelect = document.getElementById('order-retailer');
    if (distributorSelect) {
      distributorSelect.innerHTML = partyMasterState.distributors
        .map((d) => `<option value="${d.id}">${d.name}</option>`)
        .join('');
    }
    if (retailerSelect) {
      retailerSelect.innerHTML = partyMasterState.retailers
        .map((r) => `<option value="${r.id}">${r.name}</option>`)
        .join('');
    }
  } catch (error) {
    console.warn('Unable to load distributors/retailers for order creation:', error);
  }
}

async function saveNewOrder(event) {
  event.preventDefault();
  const distributorId = parseInt(document.getElementById('order-distributor')?.value || '0', 10);
  const retailerId = parseInt(document.getElementById('order-retailer')?.value || '0', 10);
  const orderDate = document.getElementById('order-date')?.value;
  const amount = parseFloat(document.getElementById('order-amount')?.value || '0');
  const taxRate = parseFloat(document.getElementById('order-tax-rate')?.value || '0');

  if (!distributorId || !retailerId || !orderDate || Number.isNaN(amount) || amount <= 0) {
    alert('Please provide distributor, retailer, date and an amount greater than zero.');
    return;
  }

  try {
    const response = await fetchWithAuth('/api/v1/sales-orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        distributor_id: distributorId,
        retailer_id: retailerId,
        order_date: orderDate,
        so_date: orderDate,
        tax_rate: taxRate,
        items: [
          {
            product_code: 'STD-001',
            product_name: 'Standard order item',
            quantity: 1,
            unit_price: amount,
          },
        ],
      }),
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error?.message || data.message || 'Unable to create order');
    }
    closeModal('new-order-modal');
    await loadOrders();
    alert('Order created successfully.');
  } catch (error) {
    alert(error.message || 'Error creating order.');
  }
}

async function openOrdersWorkspace() {
  if (!authState.accessToken) {
    document.getElementById('loginModal')?.classList.remove('hidden');
    alert('Please login to access Orders.');
    return;
  }
  document.getElementById('dashboard')?.classList.add('hidden');
  document.getElementById('sales-workspace')?.classList.add('hidden');
  document.getElementById('purchase-workspace')?.classList.add('hidden');
  document.getElementById('inventory-workspace')?.classList.add('hidden');
  document.getElementById('finance-workspace')?.classList.add('hidden');
  document.getElementById('party-master-section')?.classList.add('hidden');
  document.getElementById('order-sheets-workspace')?.classList.add('hidden');
  document.getElementById('approvals-workspace')?.classList.add('hidden');
  document.getElementById('banking-workspace')?.classList.add('hidden');
  document.getElementById('orders-workspace')?.classList.remove('hidden');
  setActiveSidebarItem('Orders');
  await loadOrders();
}

async function openOrderSheetsWorkspace() {
  if (!authState.accessToken) {
    document.getElementById('loginModal')?.classList.remove('hidden');
    alert('Please login to access Order Sheets.');
    return;
  }
  document.getElementById('dashboard')?.classList.add('hidden');
  document.getElementById('sales-workspace')?.classList.add('hidden');
  document.getElementById('purchase-workspace')?.classList.add('hidden');
  document.getElementById('inventory-workspace')?.classList.add('hidden');
  document.getElementById('finance-workspace')?.classList.add('hidden');
  document.getElementById('party-master-section')?.classList.add('hidden');
  document.getElementById('orders-workspace')?.classList.add('hidden');
  document.getElementById('approvals-workspace')?.classList.add('hidden');
  document.getElementById('banking-workspace')?.classList.add('hidden');
  document.getElementById('order-sheets-workspace')?.classList.remove('hidden');
  setActiveSidebarItem('Order Sheets');
  await loadOrderSheets();
}

function showOrderSheetUpload(stage) {
  const stageLabel = {
    1: 'Stage 1 — Order Sheet',
    2: 'Stage 2 — Customer Placed Order',
    3: 'Stage 3 — Sales Order (SO)',
    4: 'Stage 4 — Commercial Invoice (CI)',
  }[stage] || 'Upload';
  const panel = document.getElementById('order-sheet-upload-panel');
  const label = document.getElementById('order-sheet-upload-stage-label');
  const frame = document.getElementById('order-sheet-upload-frame');

  if (panel && label && frame) {
    label.textContent = stageLabel;
    frame.src = `/legacy?stage=${stage}`;
    panel.classList.remove('hidden');
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function hideOrderSheetUpload() {
  const panel = document.getElementById('order-sheet-upload-panel');
  const frame = document.getElementById('order-sheet-upload-frame');
  if (panel) {
    panel.classList.add('hidden');
  }
  if (frame) {
    frame.src = '';
  }
}

async function openApprovalsWorkspace() {
  if (!authState.accessToken) {
    document.getElementById('loginModal')?.classList.remove('hidden');
    alert('Please login to access Approvals.');
    return;
  }
  document.getElementById('dashboard')?.classList.add('hidden');
  document.getElementById('sales-workspace')?.classList.add('hidden');
  document.getElementById('purchase-workspace')?.classList.add('hidden');
  document.getElementById('inventory-workspace')?.classList.add('hidden');
  document.getElementById('finance-workspace')?.classList.add('hidden');
  document.getElementById('party-master-section')?.classList.add('hidden');
  document.getElementById('orders-workspace')?.classList.add('hidden');
  document.getElementById('banking-workspace')?.classList.add('hidden');
  document.getElementById('approvals-workspace')?.classList.remove('hidden');
  setActiveSidebarItem('Approvals');
  await loadApprovals();
}

async function openBankingWorkspace() {
  if (!authState.accessToken) {
    document.getElementById('loginModal')?.classList.remove('hidden');
    alert('Please login to access Banking.');
    return;
  }
  document.getElementById('dashboard')?.classList.add('hidden');
  document.getElementById('sales-workspace')?.classList.add('hidden');
  document.getElementById('purchase-workspace')?.classList.add('hidden');
  document.getElementById('inventory-workspace')?.classList.add('hidden');
  document.getElementById('finance-workspace')?.classList.add('hidden');
  document.getElementById('party-master-section')?.classList.add('hidden');
  document.getElementById('orders-workspace')?.classList.add('hidden');
  document.getElementById('approvals-workspace')?.classList.add('hidden');
  document.getElementById('banking-workspace')?.classList.remove('hidden');
  setActiveSidebarItem('Banking');
  await loadBankAccounts();
}

async function loadOrders() {
  const list = document.getElementById('orders-list');
  if (!list) return;
  list.textContent = 'Loading order list...';
  try {
    await loadOrderDistributorsAndRetailers();
    const distributorMap = Object.fromEntries(partyMasterState.distributors.map((d) => [d.id, d.name]));
    const retailerMap = Object.fromEntries(partyMasterState.retailers.map((r) => [r.id, r.name]));
    const response = await fetchWithAuth('/api/v1/sales-orders?limit=100');
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error?.message || data.message || 'Unable to load orders');
    }
    const orders = data.data.results || [];
    if (!orders.length) {
      list.innerHTML = '<div class="list-empty">No orders found.</div>';
      return;
    }
    list.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Order #</th>
            <th>Distributor</th>
            <th>Retailer</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${orders
            .map(
              (order) => `
                <tr>
                  <td>${order.so_number || order.id}</td>
                  <td>${distributorMap[order.distributor_id] || order.distributor_id || '-'}</td>
                  <td>${retailerMap[order.retailer_id] || order.retailer_id || '-'}</td>
                  <td>${order.order_date || '-'}</td>
                  <td>₹ ${Number(order.net_amount || 0).toFixed(2)}</td>
                  <td>${order.status || '-'}</td>
                </tr>
              `
            )
            .join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    list.innerHTML = `<div class="error">${error.message || 'Unable to load orders.'}</div>`;
  }
}

async function loadOrderSheets() {
  const list = document.getElementById('order-sheets-list');
  if (!list) return;
  list.textContent = 'Loading order sheets...';
  try {
    const response = await fetchWithAuth('/api/v1/order-sheets?limit=200');
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error?.message || data.message || 'Unable to load order sheets');
    }
    const sheets = data.data || [];
    if (!sheets.length) {
      list.innerHTML = '<div class="list-empty">No order sheets found.</div>';
      return;
    }
    list.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Uploaded</th>
            <th>Status</th>
            <th>File</th>
          </tr>
        </thead>
        <tbody>
          ${sheets
            .map((sheet) => {
              const fileLink = sheet.file_reference
                ? `<a href="${sheet.file_reference}" target="_blank" rel="noopener noreferrer">Open</a>`
                : 'No file';
              return `
                <tr>
                  <td>${sheet.name || '-'}</td>
                  <td>${sheet.category || '-'}</td>
                  <td>${sheet.uploaded_at || '-'}</td>
                  <td>${sheet.is_active ? 'Active' : 'Inactive'}</td>
                  <td>${fileLink}</td>
                </tr>
              `;
            })
            .join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    list.innerHTML = `<div class="error">${error.message || 'Unable to load order sheets.'}</div>`;
  }
}

async function loadApprovals() {
  const list = document.getElementById('approvals-list');
  if (!list) return;
  list.textContent = 'Loading approvals...';
  try {
    await loadOrderDistributorsAndRetailers();
    const distributorMap = Object.fromEntries(partyMasterState.distributors.map((d) => [d.id, d.name]));
    const retailerMap = Object.fromEntries(partyMasterState.retailers.map((r) => [r.id, r.name]));
    const response = await fetchWithAuth('/api/v1/sales-orders?status=draft&limit=100');
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error?.message || data.message || 'Unable to load approvals');
    }
    const orders = data.data.results || [];
    if (!orders.length) {
      list.innerHTML = '<div class="list-empty">No pending approvals.</div>';
      return;
    }
    list.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Order #</th>
            <th>Distributor</th>
            <th>Retailer</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${orders
            .map(
              (order) => `
                <tr>
                  <td>${order.so_number || order.id}</td>
                  <td>${distributorMap[order.distributor_id] || order.distributor_id || '-'}</td>
                  <td>${retailerMap[order.retailer_id] || order.retailer_id || '-'}</td>
                  <td>${order.order_date || '-'}</td>
                  <td>₹ ${Number(order.net_amount || 0).toFixed(2)}</td>
                  <td>
                    <button onclick="updateOrderStatus(${order.id}, 'approved')" class="btn btn-primary">Approve</button>
                    <button onclick="updateOrderStatus(${order.id}, 'cancelled')" class="btn btn-secondary">Reject</button>
                  </td>
                </tr>
              `
            )
            .join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    list.innerHTML = `<div class="error">${error.message || 'Unable to load approvals.'}</div>`;
  }
}

async function updateOrderStatus(orderId, status) {
  try {
    const response = await fetchWithAuth(`/api/v1/sales-orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error?.message || data.message || 'Unable to update order status');
    }
    await loadApprovals();
    await loadOrders();
  } catch (error) {
    alert(error.message || 'Unable to update order status.');
  }
}

async function loadBankAccounts() {
  const list = document.getElementById('bank-accounts-list');
  if (!list) return;
  list.textContent = 'Loading bank accounts...';
  try {
    const response = await fetchWithAuth('/api/v1/finance/accounts');
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error?.message || data.message || 'Unable to load bank accounts');
    }
    const accounts = data.data || [];
    if (!accounts.length) {
      list.innerHTML = '<div class="list-empty">No bank accounts found.</div>';
      return;
    }
    list.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Account</th>
            <th>Type</th>
            <th>Balance</th>
          </tr>
        </thead>
        <tbody>
          ${accounts
            .map(
              (account) => `
                <tr>
                  <td>${account.name}</td>
                  <td>${account.account_type}</td>
                  <td>₹ ${Number(account.opening_balance || 0).toFixed(2)}</td>
                </tr>
              `
            )
            .join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    list.innerHTML = `<div class="error">${error.message || 'Unable to load bank accounts.'}</div>`;
  }
}

function openGSTModal() {
  document.getElementById('finance-gst-period').value = '';
  document.getElementById('finance-gst-sales').value = '0';
  document.getElementById('finance-gst-purchase').value = '0';
  document.getElementById('finance-gst-rate').value = '18';
  document.getElementById('finance-gst-status').value = 'draft';
  document.getElementById('finance-gst-notes').value = '';
  toggleModal('finance-gst-modal', true);
}

function openVATModal() {
  document.getElementById('finance-vat-period').value = '';
  document.getElementById('finance-vat-sales').value = '0';
  document.getElementById('finance-vat-purchase').value = '0';
  document.getElementById('finance-vat-rate').value = '12';
  document.getElementById('finance-vat-status').value = 'draft';
  document.getElementById('finance-vat-notes').value = '';
  toggleModal('finance-vat-modal', true);
}

async function fetchFinanceOverview() {
  const response = await fetchWithAuth('/api/v1/finance/summary');
  return response.json();
}

async function loadFinanceSummary() {
  try {
    const data = await fetchFinanceOverview();
    if (data.success) {
      document.getElementById('finance-accounts-count').textContent = data.data.accounts || 0;
      document.getElementById('finance-gst-due').textContent = `₹ ${Number(data.data.gst_tax_due || 0).toFixed(2)}`;
      document.getElementById('finance-vat-due').textContent = `₹ ${Number(data.data.vat_tax_due || 0).toFixed(2)}`;
    }
    await loadFinanceAccounts();
    await loadFinanceGSTReturns();
    await loadFinanceVATReturns();
  } catch (error) {
    console.warn('Unable to load finance summary:', error);
  }
}

async function loadFinanceAccounts() {
  try {
    const response = await fetchWithAuth('/api/v1/finance/accounts');
    const data = await response.json();
    financeState.accounts = data.success ? data.data : [];
    const list = document.getElementById('finance-accounts-list');
    if (!list) return;
    list.innerHTML = financeState.accounts.map((account) => `<li>${account.name} (${account.account_type}) — ${Number(account.opening_balance || 0).toFixed(2)}</li>`).join('');
  } catch (error) {
    console.warn('Unable to load finance accounts:', error);
  }
}

async function loadFinanceGSTReturns() {
  try {
    const response = await fetchWithAuth('/api/v1/finance/gst');
    const data = await response.json();
    financeState.gstReturns = data.success ? data.data : [];
    const list = document.getElementById('finance-gst-list');
    if (!list) return;
    list.innerHTML = financeState.gstReturns.map((item) => `<li>${item.period} — ${item.filed_status} — ₹ ${Number(item.tax_amount || 0).toFixed(2)}</li>`).join('');
  } catch (error) {
    console.warn('Unable to load GST returns:', error);
  }
}

async function loadFinanceVATReturns() {
  try {
    const response = await fetchWithAuth('/api/v1/finance/vat');
    const data = await response.json();
    financeState.vatReturns = data.success ? data.data : [];
    const list = document.getElementById('finance-vat-list');
    if (!list) return;
    list.innerHTML = financeState.vatReturns.map((item) => `<li>${item.period} — ${item.filed_status} — ₹ ${Number(item.tax_amount || 0).toFixed(2)}</li>`).join('');
  } catch (error) {
    console.warn('Unable to load VAT returns:', error);
  }
}

async function saveAccount(event) {
  event.preventDefault();
  try {
    const response = await fetchWithAuth('/api/v1/finance/accounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: document.getElementById('finance-account-name').value.trim(),
        account_type: document.getElementById('finance-account-type').value,
        opening_balance: parseFloat(document.getElementById('finance-account-opening-balance').value || '0'),
        notes: document.getElementById('finance-account-notes').value.trim(),
      }),
    });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to save account');
    closeModal('finance-account-modal');
    await loadFinanceSummary();
    alert('Account saved successfully.');
  } catch (error) {
    alert(error.message);
  }
}

async function saveGSTReturn(event) {
  event.preventDefault();
  try {
    const response = await fetchWithAuth('/api/v1/finance/gst', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        period: document.getElementById('finance-gst-period').value.trim(),
        sales_amount: parseFloat(document.getElementById('finance-gst-sales').value || '0'),
        purchase_amount: parseFloat(document.getElementById('finance-gst-purchase').value || '0'),
        tax_rate: parseFloat(document.getElementById('finance-gst-rate').value || '0'),
        filed_status: document.getElementById('finance-gst-status').value,
        notes: document.getElementById('finance-gst-notes').value.trim(),
      }),
    });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to save GST return');
    closeModal('finance-gst-modal');
    await loadFinanceSummary();
    alert('GST return saved successfully.');
  } catch (error) {
    alert(error.message);
  }
}

async function saveVATReturn(event) {
  event.preventDefault();
  try {
    const response = await fetchWithAuth('/api/v1/finance/vat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        period: document.getElementById('finance-vat-period').value.trim(),
        sales_amount: parseFloat(document.getElementById('finance-vat-sales').value || '0'),
        purchase_amount: parseFloat(document.getElementById('finance-vat-purchase').value || '0'),
        tax_rate: parseFloat(document.getElementById('finance-vat-rate').value || '0'),
        filed_status: document.getElementById('finance-vat-status').value,
        notes: document.getElementById('finance-vat-notes').value.trim(),
      }),
    });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to save VAT return');
    closeModal('finance-vat-modal');
    await loadFinanceSummary();
    alert('VAT return saved successfully.');
  } catch (error) {
    alert(error.message);
  }
}

async function checkForUpdates(manual = false) {
  try {
    const versionResponse = await fetchWithAuth('/api/v1/app/version');
    const versionData = await versionResponse.json();
    if (!versionResponse.ok || !versionData.success) {
      return;
    }

    const currentVersion = versionData.data.app_version;
    const metadataResponse = await fetchWithAuth('/api/v1/app/update-metadata');
    const metadataData = await metadataResponse.json();
    if (!metadataResponse.ok || !metadataData.success) {
      return;
    }

    const updateMetadata = metadataData.data;
    if (compareVersions(updateMetadata.version, currentVersion) > 0) {
      if (!shouldShowUpdate(updateMetadata.version, manual)) {
        return;
      }
      pendingUpdateMetadata = updateMetadata;
      showUpdateModal(updateMetadata, manual);
    } else if (manual) {
      alert('You are already running the latest version.');
    }
  } catch (error) {
    console.warn('Update check failed:', error);
    if (manual) {
      alert('Unable to check for updates right now. Please try again later.');
    }
  }
}

function showUpdateModal(updateMetadata, manual = false) {
  const promptText = document.getElementById('updatePromptText');
  const releaseNotes = document.getElementById('updateReleaseNotes');

  if (promptText) {
    promptText.textContent =
      `A new version ${updateMetadata.version} is available. Restart now to install it, or choose Later to continue using the current version until the next restart.`;
  }

  if (releaseNotes) {
    releaseNotes.textContent = updateMetadata.release_notes || '';
  }

  const modal = document.getElementById('updateModal');
  if (modal) {
    modal.classList.remove('hidden');
  }
}

function restartToInstallUpdate() {
  if (!pendingUpdateMetadata) {
    return;
  }

  const downloadUrl = pendingUpdateMetadata.download_url;
  closeModal('updateModal');
  localStorage.removeItem('deferredUpdateVersion');
  localStorage.setItem('pendingUpdateVersion', pendingUpdateMetadata.version);

  if (downloadUrl) {
    window.open(downloadUrl, '_blank');
  }

  if (window.pywebview && window.pywebview.api && typeof window.pywebview.api.restartApp === 'function') {
    window.pywebview.api.restartApp();
  } else {
    alert('Update will be installed after restart. The app will now reload.');
    window.location.reload();
  }
}

function deferUpdate() {
  if (pendingUpdateMetadata) {
    localStorage.setItem('deferredUpdateVersion', pendingUpdateMetadata.version);
    localStorage.removeItem('pendingUpdateVersion');
  }

  closeModal('updateModal');
  alert('Update postponed. The app will continue running on the current version until the next restart.');
}

function compareVersions(left, right) {
  const a = String(left).split('.').map(Number);
  const b = String(right).split('.').map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const ai = a[i] || 0;
    const bi = b[i] || 0;
    if (ai > bi) return 1;
    if (ai < bi) return -1;
  }
  return 0;
}

function showAppInfo() {
  alert('Centralized DB System\nVersion check will run automatically on startup.');
}

async function scanDuplicates() {
  if (!authState.accessToken) {
    alert('Please login to scan duplicates.');
    return;
  }
  toggleModal('scanModal', true);
  const status = document.getElementById('scanStatus');
  const progress = document.getElementById('scanProgress');
  if (status) status.textContent = 'Scanning party records...';
  if (progress) progress.style.width = '40%';

  try {
    const response = await fetchWithAuth('/api/v1/party-matching/review-queue');
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error || 'Duplicate scan failed');
    }
    if (progress) progress.style.width = '100%';
    if (status) status.textContent = `Scan complete. ${data.data.pending_reviews.length} pending review items found.`;
  } catch (error) {
    if (status) status.textContent = error.message || 'Scan failed.';
  }
}

function openReviewQueue() {
  openJsonPage('Party Matching Review Queue', '/api/v1/party-matching/review-queue');
}

function openApprovalQueue() {
  openJsonPage('Party Matching Approval Queue', '/api/v1/party-matching/review-queue');
}

async function openAliasLibrary() {
  const query = prompt('Search aliases by name or GST number', '');
  if (!query) return;
  openJsonPage(
    `Alias Search: ${query}`,
    `/api/v1/party-matching/search?query=${encodeURIComponent(query)}`
  );
}

function openConnectedServices() {
  openJsonPage('Connected Storage Services', '/api/v1/storage/account');
}

async function submitAddYear() {
  const year = document.getElementById('fiscalYear')?.value.trim();
  const target = parseFloat(document.getElementById('targetAmount')?.value || '0');
  if (!year || Number.isNaN(target) || target <= 0) {
    alert('Please enter a valid fiscal year and target amount.');
    return;
  }
  try {
    const response = await fetchWithAuth('/api/v1/target-achievement/years', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ year, target }),
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error || 'Unable to add year');
    }
    alert(`Fiscal year ${data.data.year} added successfully.`);
    closeModal('addYearModal');
    loadYears();
  } catch (error) {
    alert(error.message || 'Failed to add year.');
  }
}

async function submitManualEntry() {
  const yearId = document.getElementById('yearSelect')?.value;
  const distributorName = document.getElementById('distributorName')?.value.trim();
  const amount = parseFloat(document.getElementById('achievementAmount')?.value || '0');
  if (!yearId || !distributorName || Number.isNaN(amount) || amount <= 0) {
    alert('Please complete all manual entry fields.');
    return;
  }
  try {
    const response = await fetchWithAuth(`/api/v1/target-achievement/years/${yearId}/upload`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ distributor_name: distributorName, amount, file_name: 'manual-entry' }),
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error || 'Unable to save manual entry');
    }
    alert('Manual achievement data saved successfully.');
    closeModal('manualEntryModal');
  } catch (error) {
    alert(error.message || 'Failed to save manual entry.');
  }
}

async function uploadSalesReport() {
  const yearId = document.getElementById('reportYear')?.value;
  const reportFile = document.getElementById('reportFile')?.files?.[0];
  if (!yearId || !reportFile) {
    alert('Please select a year and a report file.');
    return;
  }
  alert('Sales report upload is not fully supported by the current backend.');
}

async function uploadFile() {
  const uploadFileInput = document.getElementById('fileInput');
  const uploadFile = uploadFileInput?.files?.[0];
  const uploadStatus = document.getElementById('upload-status');
  const masterType = document.getElementById('uploadMasterType')?.value || 'distributors';

  if (!uploadFile) {
    alert('Please select a file to upload.');
    return;
  }

  if (!authState.accessToken) {
    alert('Please login to upload files.');
    return;
  }

  const formData = new FormData();
  formData.append('file', uploadFile);
  formData.append('master_type', masterType);

  if (uploadStatus) {
    uploadStatus.textContent = 'Uploading file...';
    uploadStatus.classList.remove('error', 'success');
  }

  try {
    const response = await fetch('/api/v1/masters/bulk-upload', {
      method: 'POST',
      body: formData,
      credentials: 'same-origin',
      headers: authState.accessToken ? { Authorization: `Bearer ${authState.accessToken}` } : {},
    });
    const responseBody = await response.json().catch(() => null);

    if (!response.ok) {
      const message = responseBody?.error?.message || responseBody?.message || 'Upload failed';
      if (uploadStatus) {
        uploadStatus.textContent = message;
        uploadStatus.classList.add('error');
      }
      return;
    }

    if (uploadStatus) {
      uploadStatus.textContent = responseBody?.message || 'Upload completed successfully.';
      uploadStatus.classList.add('success');
    }
    if (uploadFileInput) {
      uploadFileInput.value = '';
    }
  } catch (error) {
    if (uploadStatus) {
      uploadStatus.textContent = error.message || 'Unable to upload file. Check your connection.';
      uploadStatus.classList.add('error');
    }
  }
}

// Remove legacy upload handler if not used.

function loadAppIconTray() {
  const tray = document.getElementById('appIconTray');
  if (!tray) {
    return;
  }

  const order = getSavedIconOrder();
  tray.innerHTML = order
    .map((key) => {
      const icon = appIconDefinitions.find((item) => item.key === key) || appIconDefinitions[0];
      return `
        <button type="button" class="app-icon" data-key="${icon.key}" aria-label="${icon.title}" title="${icon.title}">
          <div class="app-icon-icon">${icon.icon}</div>
          <div class="app-icon-title">${icon.title}</div>
          <div class="app-icon-description">${icon.description}</div>
        </button>
      `;
    })
    .join('');

  setupIconDragHandlers();
}

function getSavedIconOrder() {
  try {
    const raw = localStorage.getItem('appIconOrder');
    const parsed = raw ? JSON.parse(raw) : null;
    if (Array.isArray(parsed) && parsed.length === appIconDefinitions.length) {
      return parsed;
    }
  } catch (error) {
    console.warn('Unable to load icon order:', error);
  }
  return appIconDefinitions.map((item) => item.key);
}

function saveIconOrder(order) {
  localStorage.setItem('appIconOrder', JSON.stringify(order));
}

let iconPressTimer = null;
let dragSourceKey = null;

function setupIconDragHandlers() {
  const items = document.querySelectorAll('.app-icon');
  items.forEach((item) => {
    item.draggable = false;
    item.classList.remove('dragging', 'drag-ready', 'drag-over');
    item.addEventListener('pointerdown', handleIconPointerDown);
    item.addEventListener('pointerup', handleIconPointerUp);
    item.addEventListener('pointerleave', handleIconPointerCancel);
    item.addEventListener('dragstart', handleIconDragStart);
    item.addEventListener('dragend', handleIconDragEnd);
    item.addEventListener('dragover', handleIconDragOver);
    item.addEventListener('dragleave', handleIconDragLeave);
    item.addEventListener('drop', handleIconDrop);
    item.addEventListener('click', handleAppIconClick);
  });
}

function handleIconPointerDown(event) {
  const item = event.currentTarget;
  iconPressTimer = window.setTimeout(() => {
    item.draggable = true;
    item.classList.add('drag-ready');
    item.setPointerCapture(event.pointerId);
  }, 500);
}

function handleIconPointerUp() {
  if (iconPressTimer) {
    clearTimeout(iconPressTimer);
    iconPressTimer = null;
  }
}

function handleIconPointerCancel() {
  if (iconPressTimer) {
    clearTimeout(iconPressTimer);
    iconPressTimer = null;
  }
}

function handleIconDragStart(event) {
  const item = event.currentTarget;
  dragSourceKey = item.dataset.key;
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', dragSourceKey);
  window.requestAnimationFrame(() => item.classList.add('dragging'));
}

function handleIconDragEnd(event) {
  const item = event.currentTarget;
  item.classList.remove('dragging', 'drag-ready');
  item.draggable = false;
}

function handleIconDragOver(event) {
  event.preventDefault();
  event.currentTarget.classList.add('drag-over');
}

function handleIconDragLeave(event) {
  event.currentTarget.classList.remove('drag-over');
}

function handleIconDrop(event) {
  event.preventDefault();
  const target = event.currentTarget;
  target.classList.remove('drag-over');
  const sourceKey = event.dataTransfer.getData('text/plain') || dragSourceKey;
  const targetKey = target.dataset.key;
  if (!sourceKey || sourceKey === targetKey) {
    return;
  }

  const order = getSavedIconOrder();
  const sourceIndex = order.indexOf(sourceKey);
  const targetIndex = order.indexOf(targetKey);
  if (sourceIndex === -1 || targetIndex === -1) {
    return;
  }

  order.splice(sourceIndex, 1);
  order.splice(targetIndex, 0, sourceKey);
  saveIconOrder(order);
  loadAppIconTray();
}

function handleAppIconClick(event) {
  const item = event.currentTarget;
  const key = item.dataset.key;
  const icon = appIconDefinitions.find((entry) => entry.key === key);
  if (!icon) {
    return;
  }
  const action = window[icon.action];
  if (typeof action === 'function') {
    action();
  }
}

function setActiveSidebarItem(label) {
  const normalized = (label || '').toLowerCase();
  document.querySelectorAll('.sidebar-item, .nav-item').forEach((button) => {
    const isActive = button.textContent.trim().toLowerCase() === normalized;
    button.classList.toggle('active', isActive);
  });
}

function showDashboardWorkspace() {
  document.getElementById('dashboard')?.classList.remove('hidden');
  [
    'sales-workspace',
    'purchase-workspace',
    'inventory-workspace',
    'finance-workspace',
    'party-master-section',
    'orders-workspace',
    'order-sheets-workspace',
    'approvals-workspace',
    'banking-workspace',
  ].forEach((id) => {
    document.getElementById(id)?.classList.add('hidden');
  });
}

function openModule(moduleName) {
  const normalized = (moduleName || '').toLowerCase();

  if (normalized === 'dashboard') {
    showDashboardWorkspace();
    setActiveSidebarItem('Dashboard');
    return;
  }

  if (normalized === 'sales') {
    document.getElementById('dashboard')?.classList.add('hidden');
    document.getElementById('sales-workspace')?.classList.remove('hidden');
    document.getElementById('purchase-workspace')?.classList.add('hidden');
    document.getElementById('inventory-workspace')?.classList.add('hidden');
    setActiveSidebarItem('Sales');
    return;
  }

  if (normalized === 'purchase') {
    document.getElementById('dashboard')?.classList.add('hidden');
    document.getElementById('purchase-workspace')?.classList.remove('hidden');
    document.getElementById('sales-workspace')?.classList.add('hidden');
    document.getElementById('inventory-workspace')?.classList.add('hidden');
    setActiveSidebarItem('Purchase');
    return;
  }

  if (normalized === 'inventory') {
    document.getElementById('dashboard')?.classList.add('hidden');
    document.getElementById('inventory-workspace')?.classList.remove('hidden');
    document.getElementById('sales-workspace')?.classList.add('hidden');
    document.getElementById('purchase-workspace')?.classList.add('hidden');
    setActiveSidebarItem('Inventory');
    return;
  }

  if (normalized === 'parties') {
    openPartyMasterSection();
    return;
  }

  if (normalized === 'reports') {
    openReports();
    return;
  }

  if (normalized === 'analytics') {
    openAnalyticsDashboard();
    return;
  }

  if (normalized === 'google drive') {
    openFileLibrary();
    return;
  }

  if (normalized === 'finance') {
    openFinanceWorkspace();
    return;
  }

  if (normalized === 'orders') {
    openOrdersWorkspace();
    return;
  }

  if (normalized === 'order sheets') {
    openOrderSheetsWorkspace();
    return;
  }

  if (normalized === 'approvals') {
    openApprovalsWorkspace();
    return;
  }

  if (normalized === 'banking') {
    openBankingWorkspace();
    return;
  }

  if (normalized === 'settings') {
    openWorkspaceSettings();
    return;
  }

  console.log('Opening module:', moduleName);
  const moduleAlert = document.getElementById('module-alert');
  if (moduleAlert) {
    moduleAlert.textContent = `Opening ${moduleName} module...`;
  }
  alert(`Opening ${moduleName}`);
}

function updateGreeting() {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
  const greetingText = document.getElementById('greeting-text');
  if (greetingText) {
    greetingText.textContent = `${greeting}, ${authState.username || 'Admin'}!`;
  }
}

function loadRecentActivities() {
  const activities = [
    { icon: '📈', title: 'Target updated for FY 2026-27', meta: 'Updated by system', time: '12m ago' },
    { icon: '📤', title: 'Sales report synced', meta: 'Uploaded via Drive', time: '42m ago' },
    { icon: '💼', title: 'New retailer onboarded', meta: 'Retailer management', time: '1h ago' },
    { icon: '🔍', title: 'Duplicate party scan completed', meta: 'Party matching', time: '2h ago' },
  ];

  const feed = document.getElementById('activity-feed');
  if (!feed) return;

  feed.innerHTML = activities
    .map(
      (activity) => `
        <div class="activity-item">
          <div class="activity-icon">${activity.icon}</div>
          <div class="activity-content">
            <div class="activity-title">${activity.title}</div>
            <div class="activity-meta">${activity.meta}</div>
          </div>
          <div class="activity-time">${activity.time}</div>
        </div>
      `
    )
    .join('');
}

let mastersDistributorCache = [];

async function fetchMasterDistributorsForDropdown() {
  try {
    const response = await fetchWithAuth('/api/v1/masters/distributors?limit=5000');
    const data = await response.json();
    if (response.ok && data.success) {
      mastersDistributorCache = data.data;
    }
  } catch (error) {
    console.warn('Failed to fetch master distributors:', error);
  }
}

function openMastersBulkModal() {
  fetchMasterDistributorsForDropdown().then(() => {
    populateMastersRetailDistributorFilter();
  });
  toggleModal('masters-bulk-modal', true);
}

function populateMasterRetailerDistributorOptions(records) {
  const select = document.getElementById('master-retailer-distributor');
  if (!select) return;
  const options = ['<option value="">-- Unassigned --</option>'];
  const items = Array.isArray(records) ? records : [];
  const markup = options.concat(items.map((d) => `<option value="${d.id}">${d.firm_name || d.name || d.distributor_id || 'Distributor'}</option>`)).join('');
  select.innerHTML = markup;
}

function resetMasterDistributorForm() {
  document.getElementById('master-distributor-id').value = '';
  document.getElementById('master-distributor-form-title').textContent = 'Add Master Distributor';
  ['master-distributor-firm-name','master-distributor-firm-nick-name','master-distributor-name','master-distributor-code','master-distributor-buyer-code','master-distributor-phone','master-distributor-phone-2','master-distributor-email','master-distributor-address','master-distributor-location','master-distributor-region','master-distributor-pincode','master-distributor-gst','master-distributor-zone','master-distributor-payment-terms','master-distributor-credit-limit','master-distributor-birthday','master-distributor-anniversary','master-distributor-secondary-name','master-distributor-secondary-phone','master-distributor-secondary-birthday','master-distributor-secondary-anniversary','master-distributor-sales-name','master-distributor-sales-phone','master-distributor-sales-email','master-distributor-sales-birthday','master-distributor-sales-anniversary'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
}

function resetMasterRetailerForm() {
  document.getElementById('master-retailer-id').value = '';
  document.getElementById('master-retailer-form-title').textContent = 'Add Master Retailer';
  ['master-retailer-name','master-retailer-contact-person','master-retailer-phone','master-retailer-phone-2','master-retailer-email','master-retailer-address','master-retailer-location','master-retailer-state','master-retailer-pincode','master-retailer-gst','master-retailer-category','master-retailer-birthday','master-retailer-anniversary','master-retailer-secondary-name','master-retailer-secondary-phone','master-retailer-secondary-birthday','master-retailer-secondary-anniversary','master-retailer-sales-name','master-retailer-sales-phone','master-retailer-sales-email','master-retailer-sales-birthday','master-retailer-sales-anniversary'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const select = document.getElementById('master-retailer-distributor');
  if (select) select.value = '';
}

function openMasterDistributorForm() {
  resetMasterDistributorForm();
  toggleModal('master-distributor-form-modal', true);
}

function openMasterRetailerForm() {
  resetMasterRetailerForm();
  fetchWithAuth('/api/v1/masters/distributors?limit=5000').then(async (response) => {
    const data = await response.json();
    if (response.ok && data.success) {
      populateMasterRetailerDistributorOptions(data.data || []);
    }
  });
  toggleModal('master-retailer-form-modal', true);
}

async function saveMasterDistributor(event) {
  event.preventDefault();
  const id = document.getElementById('master-distributor-id').value;
  const body = {
    name: document.getElementById('master-distributor-name').value.trim(),
    firm_name: document.getElementById('master-distributor-firm-name').value.trim() || undefined,
    firm_nick_name: document.getElementById('master-distributor-firm-nick-name').value.trim() || undefined,
    distributor_code: document.getElementById('master-distributor-code').value.trim() || undefined,
    buyer_code: document.getElementById('master-distributor-buyer-code').value.trim() || undefined,
    phone_number: document.getElementById('master-distributor-phone').value.trim() || undefined,
    phone_number_2: document.getElementById('master-distributor-phone-2').value.trim() || undefined,
    email: document.getElementById('master-distributor-email').value.trim() || undefined,
    address: document.getElementById('master-distributor-address').value.trim() || undefined,
    location: document.getElementById('master-distributor-location').value.trim() || undefined,
    region: document.getElementById('master-distributor-region').value.trim() || undefined,
    pincode: document.getElementById('master-distributor-pincode').value.trim() || undefined,
    gst_no: document.getElementById('master-distributor-gst').value.trim() || undefined,
    zone: document.getElementById('master-distributor-zone').value.trim() || undefined,
    payment_terms: document.getElementById('master-distributor-payment-terms').value.trim() || undefined,
    credit_limit: document.getElementById('master-distributor-credit-limit').value.trim() ? parseFloat(document.getElementById('master-distributor-credit-limit').value) : undefined,
    birthday: document.getElementById('master-distributor-birthday').value.trim() || undefined,
    anniversary: document.getElementById('master-distributor-anniversary').value.trim() || undefined,
    secondary_distributor_name: document.getElementById('master-distributor-secondary-name').value.trim() || undefined,
    secondary_distributor_phone_number: document.getElementById('master-distributor-secondary-phone').value.trim() || undefined,
    secondary_distributor_birthday: document.getElementById('master-distributor-secondary-birthday').value.trim() || undefined,
    secondary_distributor_anniversary: document.getElementById('master-distributor-secondary-anniversary').value.trim() || undefined,
    sales_executive_name: document.getElementById('master-distributor-sales-name').value.trim() || undefined,
    sales_executive_phone_number: document.getElementById('master-distributor-sales-phone').value.trim() || undefined,
    sales_executive_email: document.getElementById('master-distributor-sales-email').value.trim() || undefined,
    sales_executive_birthday: document.getElementById('master-distributor-sales-birthday').value.trim() || undefined,
    sales_executive_anniversary: document.getElementById('master-distributor-sales-anniversary').value.trim() || undefined,
  };
  if (!body.name) {
    alert('Contact person / name is required.');
    return;
  }
  try {
    const url = id ? `/api/v1/masters/distributors/${id}` : '/api/v1/masters/distributors';
    const method = id ? 'PUT' : 'POST';
    const response = await fetchWithAuth(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to save distributor');
    closeModal('master-distributor-form-modal');
    openMastersGrid('distributors');
    alert('Master distributor saved successfully.');
  } catch (error) {
    alert(error.message || 'Error saving distributor.');
  }
}

async function editMasterDistributor(id) {
  try {
    const response = await fetchWithAuth(`/api/v1/masters/distributors/${id}`);
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to load distributor');
    const record = data.data;
    document.getElementById('master-distributor-id').value = record.id;
    document.getElementById('master-distributor-form-title').textContent = 'Edit Master Distributor';
    document.getElementById('master-distributor-firm-name').value = record.firm_name || '';
    document.getElementById('master-distributor-firm-nick-name').value = record.firm_nick_name || '';
    document.getElementById('master-distributor-name').value = record.name || '';
    document.getElementById('master-distributor-code').value = record.distributor_code || '';
    document.getElementById('master-distributor-buyer-code').value = record.buyer_code || '';
    document.getElementById('master-distributor-phone').value = record.phone_number || '';
    document.getElementById('master-distributor-phone-2').value = record.phone_number_2 || '';
    document.getElementById('master-distributor-email').value = record.email || '';
    document.getElementById('master-distributor-address').value = record.address || '';
    document.getElementById('master-distributor-location').value = record.location || '';
    document.getElementById('master-distributor-region').value = record.region || '';
    document.getElementById('master-distributor-pincode').value = record.pincode || '';
    document.getElementById('master-distributor-gst').value = record.gst_no || '';
    document.getElementById('master-distributor-zone').value = record.zone || '';
    document.getElementById('master-distributor-payment-terms').value = record.payment_terms || '';
    document.getElementById('master-distributor-credit-limit').value = record.credit_limit || '';
    document.getElementById('master-distributor-birthday').value = record.birthday || '';
    document.getElementById('master-distributor-anniversary').value = record.anniversary || '';
    document.getElementById('master-distributor-secondary-name').value = record.secondary_distributor_name || '';
    document.getElementById('master-distributor-secondary-phone').value = record.secondary_distributor_phone_number || '';
    document.getElementById('master-distributor-secondary-birthday').value = record.secondary_distributor_birthday || '';
    document.getElementById('master-distributor-secondary-anniversary').value = record.secondary_distributor_anniversary || '';
    document.getElementById('master-distributor-sales-name').value = record.sales_executive_name || '';
    document.getElementById('master-distributor-sales-phone').value = record.sales_executive_phone_number || '';
    document.getElementById('master-distributor-sales-email').value = record.sales_executive_email || '';
    document.getElementById('master-distributor-sales-birthday').value = record.sales_executive_birthday || '';
    document.getElementById('master-distributor-sales-anniversary').value = record.sales_executive_anniversary || '';
    toggleModal('master-distributor-form-modal', true);
  } catch (error) {
    alert(error.message || 'Error loading distributor.');
  }
}

async function deleteMasterDistributor(id) {
  if (!confirm('Delete this master distributor? This will mark it inactive.')) return;
  try {
    const response = await fetchWithAuth(`/api/v1/masters/distributors/${id}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to delete distributor');
    openMastersGrid('distributors');
  } catch (error) {
    alert(error.message || 'Error deleting distributor.');
  }
}

async function saveMasterRetailer(event) {
  event.preventDefault();
  const id = document.getElementById('master-retailer-id').value;
  const body = {
    name: document.getElementById('master-retailer-name').value.trim(),
    distributor_id: document.getElementById('master-retailer-distributor').value ? parseInt(document.getElementById('master-retailer-distributor').value, 10) : null,
    contact_person: document.getElementById('master-retailer-contact-person').value.trim() || undefined,
    phone_number: document.getElementById('master-retailer-phone').value.trim() || undefined,
    phone_number_2: document.getElementById('master-retailer-phone-2').value.trim() || undefined,
    email: document.getElementById('master-retailer-email').value.trim() || undefined,
    address: document.getElementById('master-retailer-address').value.trim() || undefined,
    location: document.getElementById('master-retailer-location').value.trim() || undefined,
    state: document.getElementById('master-retailer-state').value.trim() || undefined,
    pincode: document.getElementById('master-retailer-pincode').value.trim() || undefined,
    gst_no: document.getElementById('master-retailer-gst').value.trim() || undefined,
    category: document.getElementById('master-retailer-category').value.trim() || undefined,
    birthday: document.getElementById('master-retailer-birthday').value.trim() || undefined,
    anniversary: document.getElementById('master-retailer-anniversary').value.trim() || undefined,
    secondary_retailer_name: document.getElementById('master-retailer-secondary-name').value.trim() || undefined,
    secondary_retailer_phone_number: document.getElementById('master-retailer-secondary-phone').value.trim() || undefined,
    secondary_retailer_birthday: document.getElementById('master-retailer-secondary-birthday').value.trim() || undefined,
    secondary_retailer_anniversary: document.getElementById('master-retailer-secondary-anniversary').value.trim() || undefined,
    sales_executive_name: document.getElementById('master-retailer-sales-name').value.trim() || undefined,
    sales_executive_phone_number: document.getElementById('master-retailer-sales-phone').value.trim() || undefined,
    sales_executive_email: document.getElementById('master-retailer-sales-email').value.trim() || undefined,
    sales_executive_birthday: document.getElementById('master-retailer-sales-birthday').value.trim() || undefined,
    sales_executive_anniversary: document.getElementById('master-retailer-sales-anniversary').value.trim() || undefined,
  };
  if (!body.name) { alert('Shop name is required.'); return; }
  try {
    const url = id ? `/api/v1/masters/retailers/${id}` : '/api/v1/masters/retailers';
    const method = id ? 'PUT' : 'POST';
    const response = await fetchWithAuth(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to save retailer');
    closeModal('master-retailer-form-modal');
    openMastersGrid('retailers');
    alert('Master retailer saved successfully.');
  } catch (error) {
    alert(error.message || 'Error saving retailer.');
  }
}

async function editMasterRetailer(id) {
  try {
    await fetchWithAuth('/api/v1/masters/distributors?limit=5000').then(async (response) => {
      const data = await response.json();
      if (response.ok && data.success) {
        populateMasterRetailerDistributorOptions(data.data || []);
      }
    });
    const response = await fetchWithAuth(`/api/v1/masters/retailers/${id}`);
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to load retailer');
    const record = data.data;
    document.getElementById('master-retailer-id').value = record.id;
    document.getElementById('master-retailer-form-title').textContent = 'Edit Master Retailer';
    document.getElementById('master-retailer-name').value = record.name || '';
    document.getElementById('master-retailer-contact-person').value = record.contact_person || '';
    document.getElementById('master-retailer-phone').value = record.phone_number || '';
    document.getElementById('master-retailer-phone-2').value = record.phone_number_2 || '';
    document.getElementById('master-retailer-email').value = record.email || '';
    document.getElementById('master-retailer-address').value = record.address || '';
    document.getElementById('master-retailer-location').value = record.location || '';
    document.getElementById('master-retailer-state').value = record.state || '';
    document.getElementById('master-retailer-pincode').value = record.pincode || '';
    document.getElementById('master-retailer-gst').value = record.gst_no || '';
    document.getElementById('master-retailer-category').value = record.category || '';
    document.getElementById('master-retailer-birthday').value = record.birthday || '';
    document.getElementById('master-retailer-anniversary').value = record.anniversary || '';
    document.getElementById('master-retailer-secondary-name').value = record.secondary_retailer_name || '';
    document.getElementById('master-retailer-secondary-phone').value = record.secondary_retailer_phone_number || '';
    document.getElementById('master-retailer-secondary-birthday').value = record.secondary_retailer_birthday || '';
    document.getElementById('master-retailer-secondary-anniversary').value = record.secondary_retailer_anniversary || '';
    document.getElementById('master-retailer-sales-name').value = record.sales_executive_name || '';
    document.getElementById('master-retailer-sales-phone').value = record.sales_executive_phone_number || '';
    document.getElementById('master-retailer-sales-email').value = record.sales_executive_email || '';
    document.getElementById('master-retailer-sales-birthday').value = record.sales_executive_birthday || '';
    document.getElementById('master-retailer-sales-anniversary').value = record.sales_executive_anniversary || '';
    document.getElementById('master-retailer-distributor').value = record.distributor_id != null ? String(record.distributor_id) : '';
    toggleModal('master-retailer-form-modal', true);
  } catch (error) {
    alert(error.message || 'Error loading retailer.');
  }
}

async function deleteMasterRetailer(id) {
  if (!confirm('Delete this master retailer? This will mark it inactive.')) return;
  try {
    const response = await fetchWithAuth(`/api/v1/masters/retailers/${id}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error?.message || 'Unable to delete retailer');
    openMastersGrid('retailers');
  } catch (error) {
    alert(error.message || 'Error deleting retailer.');
  }
}

function openMastersBulkTab(which) {
  const distTab = document.getElementById('masters-bulk-dist-tab');
  const retailTab = document.getElementById('masters-bulk-retail-tab');
  const distPanel = document.getElementById('masters-bulk-distributors-panel');
  const retailPanel = document.getElementById('masters-bulk-retailers-panel');
  if (which === 'retailers') {
    distTab.classList.remove('active');
    retailTab.classList.add('active');
    distPanel.classList.add('hidden');
    retailPanel.classList.remove('hidden');
  } else {
    retailTab.classList.remove('active');
    distTab.classList.add('active');
    retailPanel.classList.add('hidden');
    distPanel.classList.remove('hidden');
  }
}

function toggleMastersRetailDistributorFilter() {
  const scope = document.getElementById('masters-retail-export-scope').value;
  const group = document.getElementById('masters-retail-distributor-filter-group');
  if (scope === 'distributor') {
    group.classList.remove('hidden');
  } else {
    group.classList.add('hidden');
  }
}

function populateMastersRetailDistributorFilter() {
  const select = document.getElementById('masters-retail-export-distributor');
  if (!select) return;
  select.innerHTML = mastersDistributorCache
    .map((d) => `<option value="${d.id}">${d.firm_name || d.name}</option>`)
    .join('');
}

async function openMastersGrid(masterType) {
  const title = document.getElementById('masters-grid-title');
  const loading = document.getElementById('masters-grid-loading');
  const thead = document.getElementById('masters-grid-thead');
  const tbody = document.getElementById('masters-grid-tbody');

  title.textContent = masterType === 'distributors' ? 'All Distributors (Master Data)' : 'All Retailers (Master Data)';
  loading.classList.remove('hidden');
  thead.innerHTML = '';
  tbody.innerHTML = '';
  toggleModal('masters-grid-modal', true);

  // Curated, sensible column order — a raw dump of every DB column
  // (including internal ids and workspace_id) would be clutter, not
  // a usable "Excel-like" view for a real person to read.
  const columnsByType = {
    distributors: [
      ['distributor_id', 'Distributor Code'],
      ['firm_name', 'Firm Name'],
      ['firm_nick_name', 'Nickname'],
      ['name', 'Contact Person'],
      ['phone_number', 'Phone'],
      ['phone_number_2', 'Phone 2'],
      ['email', 'Email'],
      ['location', 'City'],
      ['zone', 'Zone'],
      ['region', 'Region'],
      ['address', 'Address'],
      ['pincode', 'Pincode'],
      ['gst_no', 'GST No'],
      ['payment_terms', 'Payment Terms'],
      ['credit_limit', 'Credit Limit'],
      ['birthday', 'Birthday'],
      ['anniversary', 'Anniversary'],
      ['secondary_distributor_name', 'Secondary Partner'],
      ['secondary_distributor_phone_number', 'Secondary Partner Phone'],
      ['sales_executive_name', 'Sales Executive'],
      ['sales_executive_phone_number', 'Sales Executive Phone'],
      ['status', 'Status'],
    ],
    retailers: [
      ['name', 'Shop Name'],
      ['contact_person', 'Contact Person'],
      ['distributor_name', 'Distributor'],
      ['phone_number', 'Phone'],
      ['phone_number_2', 'Phone 2'],
      ['email', 'Email'],
      ['location', 'City'],
      ['state', 'State'],
      ['pincode', 'Pincode'],
      ['address', 'Address'],
      ['gst_no', 'GST No'],
      ['category', 'Category'],
      ['birthday', 'Birthday'],
      ['anniversary', 'Anniversary'],
      ['secondary_retailer_name', 'Secondary Retailer'],
      ['secondary_retailer_phone_number', 'Secondary Retailer Phone'],
      ['sales_executive_name', 'Sales Executive'],
      ['status', 'Status'],
    ],
  };
  const columns = masterType === 'distributors'
    ? [...columnsByType.distributors, ['actions', 'Actions']]
    : [...columnsByType.retailers, ['actions', 'Actions']];

  try {
    const response = await fetchWithAuth(`/api/v1/masters/${masterType}?limit=5000`);
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error((data.error && data.error.message) || 'Failed to load data');
    }
    const rows = data.data;

    thead.innerHTML = `<tr>${columns.map(([, label]) => `<th>${label}</th>`).join('')}</tr>`;

    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="${columns.length}">No records yet.</td></tr>`;
    } else {
      tbody.innerHTML = rows
        .map((row) => {
          const actions = masterType === 'distributors'
            ? `<button class="btn btn-secondary" onclick="event.stopPropagation(); editMasterDistributor(${row.id})">Edit</button> <button class="btn btn-danger" onclick="event.stopPropagation(); deleteMasterDistributor(${row.id})">Delete</button>`
            : `<button class="btn btn-secondary" onclick="event.stopPropagation(); editMasterRetailer(${row.id})">Edit</button> <button class="btn btn-danger" onclick="event.stopPropagation(); deleteMasterRetailer(${row.id})">Delete</button>`;
          const cells = columns
            .map(([key]) => `<td>${row[key] != null && row[key] !== '' ? row[key] : '-'}</td>`)
            .join('');
          return `<tr>${cells}<td>${actions}</td></tr>`;
        })
        .join('');
    }
  } catch (error) {
    tbody.innerHTML = `<tr><td colspan="${columns.length}">Error: ${error.message}</td></tr>`;
  } finally {
    loading.classList.add('hidden');
  }
}

async function bulkUploadMasters(masterType) {
  const fileInputId = masterType === 'distributors' ? 'masters-dist-upload-file' : 'masters-retail-upload-file';
  const resultId = masterType === 'distributors' ? 'masters-dist-upload-result' : 'masters-retail-upload-result';
  const fileInput = document.getElementById(fileInputId);
  const resultBox = document.getElementById(resultId);
  const file = fileInput.files[0];

  if (!file) {
    alert('Please choose a file first.');
    return;
  }

  resultBox.textContent = 'Uploading and processing — this may take a few seconds for large files...';

  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetchWithAuth(`/api/v1/masters/${masterType}/bulk-upload`, {
      method: 'POST',
      body: formData,
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error((data.error && data.error.message) || 'Bulk upload failed');
    }
    const r = data.data;
    let summary = `Processed ${r.rows_processed} rows — Inserted: ${r.inserted}, Updated: ${r.updated}, Skipped: ${r.skipped}`;
    if (masterType === 'retailers') {
      summary += `, Unassigned (no distributor match): ${r.unassigned}`;
      if (r.ambiguous_distributor_matches && r.ambiguous_distributor_matches.length) {
        summary += `\n${r.ambiguous_distributor_matches.length} row(s) had an ambiguous distributor match — please review and link manually.`;
      }
    }
    if (r.errors && r.errors.length) {
      summary += `\nErrors: ${r.errors.length} (see console for details)`;
      console.warn('Bulk upload errors:', r.errors);
    }
    resultBox.textContent = summary;
    fileInput.value = '';
    fetchMasterDistributorsForDropdown();
  } catch (error) {
    resultBox.textContent = `Error: ${error.message || 'Bulk upload failed'}`;
  }
}

function sanitizeFilenamePart(text) {
  return (text || '').replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_+|_+$/g, '') || 'unknown';
}

async function downloadMastersDistributors() {
  const format = document.getElementById('masters-dist-export-format').value;
  await triggerMastersDownload(`/api/v1/masters/distributors/export?format=${format}`, `all_distributors.${format}`);
}

async function downloadMastersRetailers() {
  const format = document.getElementById('masters-retail-export-format').value;
  const scope = document.getElementById('masters-retail-export-scope').value;
  let url = `/api/v1/masters/retailers/export?format=${format}`;
  let filename = `all_retailers.${format}`;
  if (scope === 'distributor') {
    const distributorSelect = document.getElementById('masters-retail-export-distributor');
    const distributorId = distributorSelect.value;
    if (!distributorId) {
      alert('Please choose a distributor first.');
      return;
    }
    const distributorName = distributorSelect.options[distributorSelect.selectedIndex].text;
    url += `&distributor_id=${distributorId}`;
    filename = `retailers-${sanitizeFilenamePart(distributorName)}.${format}`;
  }
  await triggerMastersDownload(url, filename);
}

async function triggerMastersDownload(url, filename) {
  try {
    const response = await fetchWithAuth(url);
    if (!response.ok) {
      throw new Error('Download failed');
    }
    const blob = await response.blob();
    const downloadUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(downloadUrl);
  } catch (error) {
    alert(error.message || 'Download failed.');
  }
}

let globalSearchState = { results: {}, activeCategory: null };

const GLOBAL_SEARCH_CATEGORY_LABELS = {
  distributors: 'Distributors',
  retailers: 'Retailers',
  orders: 'Sales Orders / CI',
  stock: 'Stock',
  verifications: 'Verifications',
  visit_logs: 'Visit Logs',
  analytics: 'Analytics',
};

let globalSearchDebounceTimer = null;

function scheduleGlobalSearch() {
  const input = document.getElementById('global-search-input');
  clearTimeout(globalSearchDebounceTimer);
  if (!input.value.trim()) {
    // Cleared the box — close the results if they were open.
    const modal = document.getElementById('global-search-modal');
    if (modal && !modal.classList.contains('hidden')) {
      closeModal('global-search-modal');
    }
    return;
  }
  // Small debounce so we search live "as you type" without firing a
  // request on every single keystroke immediately.
  globalSearchDebounceTimer = setTimeout(runGlobalSearch, 300);
}

let globalSearchRequestToken = 0;

async function runGlobalSearch() {
  const input = document.getElementById('global-search-input');
  const query = (input.value || '').trim();
  if (!query) {
    return;
  }

  const thisRequestToken = ++globalSearchRequestToken;

  document.getElementById('global-search-query-label').textContent = query;
  document.getElementById('global-search-loading').classList.remove('hidden');
  document.getElementById('global-search-tabs').innerHTML = '';
  document.getElementById('global-search-thead').innerHTML = '';
  document.getElementById('global-search-tbody').innerHTML = '';
  toggleModal('global-search-modal', true);

  try {
    const response = await fetchWithAuth(`/search?q=${encodeURIComponent(query)}`);
    const data = await response.json();

    // An OLDER, slower keystroke's response can arrive AFTER a newer
    // one — without this check, it would overwrite the newer,
    // correct results with stale ones (this is what made live search
    // feel "very slow"/wrong while typing quickly).
    if (thisRequestToken !== globalSearchRequestToken) {
      return;
    }

    globalSearchState.results = data.results || {};

    const tabsContainer = document.getElementById('global-search-tabs');
    const categoriesWithResults = Object.keys(globalSearchState.results)
      .filter((cat) => globalSearchState.results[cat].length > 0);

    if (!categoriesWithResults.length) {
      tabsContainer.innerHTML = '';
      document.getElementById('global-search-tbody').innerHTML = '<tr><td>No results found.</td></tr>';
    } else {
      tabsContainer.innerHTML = categoriesWithResults
        .map((cat, index) => {
          const label = GLOBAL_SEARCH_CATEGORY_LABELS[cat] || cat;
          const count = globalSearchState.results[cat].length;
          const activeClass = index === 0 ? 'active' : '';
          return `<button class="tab-button ${activeClass}" onclick="renderGlobalSearchTab('${cat}')">${label} (${count})</button>`;
        })
        .join('');
      renderGlobalSearchTab(categoriesWithResults[0]);
    }
  } catch (error) {
    if (thisRequestToken === globalSearchRequestToken) {
      document.getElementById('global-search-tbody').innerHTML = `<tr><td>Error: ${error.message}</td></tr>`;
    }
  } finally {
    if (thisRequestToken === globalSearchRequestToken) {
      document.getElementById('global-search-loading').classList.add('hidden');
    }
  }
}

const GLOBAL_SEARCH_COLUMNS = {
  distributors: [
    ['firm_name', 'Firm Name'],
    ['buyer_code', 'Distributor Code'],
    ['contact_person', 'Contact Person'],
    ['phone_number', 'Phone'],
    ['city', 'City'],
    ['gst_no', 'GST No'],
    ['zone', 'Zone'],
    ['region', 'Region'],
    ['address', 'Address'],
  ],
  retailers: [
    ['name', 'Shop Name'],
    ['distributor_name', 'Distributor'],
    ['phone_number', 'Phone'],
    ['city', 'City'],
    ['gst_no', 'GST No'],
    ['address', 'Address'],
  ],
  orders: [
    ['order_ref_no', 'Order Ref No'],
    ['distributor_name', 'Distributor'],
    ['transit_status', 'Transit Status'],
    ['payment_status', 'Payment Status'],
  ],
  stock: [
    ['brand', 'Brand'],
    ['product', 'Product'],
    ['colors', 'Colors'],
    ['size', 'Size'],
  ],
};

function renderGlobalSearchTab(category) {
  globalSearchState.activeCategory = category;
  document.querySelectorAll('#global-search-tabs .tab-button').forEach((btn) => {
    btn.classList.toggle('active', btn.textContent.startsWith(GLOBAL_SEARCH_CATEGORY_LABELS[category] || category));
  });

  const rows = globalSearchState.results[category] || [];
  const thead = document.getElementById('global-search-thead');
  const tbody = document.getElementById('global-search-tbody');
  const columns = GLOBAL_SEARCH_COLUMNS[category];

  if (columns) {
    thead.innerHTML = `<tr>${columns.map(([, label]) => `<th>${label}</th>`).join('')}</tr>`;
    partyDetailRecordsCache = rows;
    tbody.innerHTML = rows.length
      ? rows
          .map(
            (r, index) =>
              `<tr onclick="showPartyDetail(partyDetailRecordsCache[${index}])">${columns
                .map(([key]) => `<td>${r[key] != null && r[key] !== '' ? r[key] : '-'}</td>`)
                .join('')}</tr>`
          )
          .join('')
      : `<tr><td colspan="${columns.length}">No results in this category.</td></tr>`;
  } else {
    // Fallback for categories that still use the simpler content-string shape
    thead.innerHTML = '<tr><th>Result</th></tr>';
    tbody.innerHTML = rows.length
      ? rows.map((r) => `<tr><td>${r.content}</td></tr>`).join('')
      : '<tr><td>No results in this category.</td></tr>';
  }
}

document.addEventListener('DOMContentLoaded', initApp);

