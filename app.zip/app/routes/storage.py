from flask import Blueprint, request, jsonify, render_template_string
import json
import sqlite3

from app.routes.auth import require_jwt_auth, get_workspace_id
from app.storage.oauth import GoogleDriveOAuth
from centralized_db_system.db import CentralizedDB

# Create blueprint
storage_bp = Blueprint('storage', __name__, url_prefix='/api/v1/storage')


# ==================== ROUTES ====================

def _get_request_user():
    raw_user = getattr(request, 'user', None)
    if isinstance(raw_user, dict) and 'user_id' in raw_user and 'workspace_id' in raw_user:
        return raw_user
    raise RuntimeError("User context not available; authentication required.")

@storage_bp.route('/connect', methods=['POST'])
@require_jwt_auth
def connect_storage():
    """Initiate Google Drive OAuth connection"""
    try:
        user = _get_request_user()
        user_id = user['user_id']
        workspace_id = get_workspace_id()

        oauth_url, state = GoogleDriveOAuth.get_auth_url(request.host_url)
        return jsonify({
            'success': True,
            'data': {
                'oauth_url': oauth_url,
                'message': 'Redirect user to this URL to authorize',
                'state': state,
            }
        }), 200
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    except RuntimeError as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@storage_bp.route('/account', methods=['GET'])
@require_jwt_auth
def get_account():
    """Get connected storage account info"""
    try:
        user = _get_request_user()
        user_id = user['user_id']
        workspace_id = get_workspace_id()

        db = CentralizedDB()
        account = db.get_storage_account(user_id=user_id, workspace_id=workspace_id)
        return jsonify({'success': True, 'data': {'connected': bool(account), 'account': account}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@storage_bp.route('/oauth-callback', methods=['GET'])
def oauth_callback():
    """Handle OAuth callback from Google."""
    try:
        code = request.args.get('code')
        if not code:
            return render_template_string(
                '<h1>Google Drive Connect Failed</h1><p>No authorization code was returned.</p>'
            ), 400

        try:
            token_data = GoogleDriveOAuth.exchange_code_for_token(
                auth_code=code,
                host_url=request.host_url,
            )
        except ValueError as exc:
            return render_template_string(
                '<h1>Google Drive Connect Failed</h1><p>{{ message }}</p>',
                message=str(exc),
            ), 400
        except RuntimeError as exc:
            return render_template_string(
                '<h1>Google Drive Connect Failed</h1><p>{{ message }}</p>',
                message=str(exc),
            ), 500

        user = _get_request_user()
        user_id = user['user_id']
        workspace_id = get_workspace_id()

        db = CentralizedDB()
        db.ensure_storage_tables()
        db.save_storage_account(
            user_id=user_id,
            workspace_id=workspace_id,
            provider_type='google_drive',
            oauth_token=token_data,
            sync_status='connected',
        )

        return render_template_string(
            '<!doctype html>'
            '<html><head><meta charset="utf-8"><title>Google Drive Connected</title></head>'
            '<body>'
            '<h1>Google Drive Connected</h1>'
            '<p>Your Google Drive account has been connected successfully.</p>'
            '<p>You may now close this window and return to the application.</p>'
            '<script>'
            'if (window.opener) {'
            '  window.opener.postMessage({ type: "google_drive_connected" }, "*");'
            '  setTimeout(function() { window.close(); }, 1500);'
            '}'
            '</script>'
            '</body></html>'
        ), 200
    except Exception as e:
        return render_template_string(
            '<!doctype html>'
            '<html><head><meta charset="utf-8"><title>Google Drive Connect Failed</title></head>'
            '<body>'
            '<h1>Google Drive Connect Failed</h1>'
            '<p>{{ message }}</p>'
            '<script>'
            'const errorMessage = {{ message|tojson }};'
            'if (window.opener) {'
            '  window.opener.postMessage({ type: "google_drive_connection_failed", message: errorMessage }, "*");'
            '}'
            '</script>'
            '</body></html>',
            message=str(e),
        ), 500

@storage_bp.route('/disconnect', methods=['POST'])
@require_jwt_auth
def disconnect_storage():
    """Disconnect Google Drive storage"""
    try:
        user = _get_request_user()
        user_id = user['user_id']
        workspace_id = get_workspace_id()

        db = CentralizedDB()
        disconnected = db.disconnect_storage_account(
            user_id=user_id,
            workspace_id=workspace_id,
            provider_type='google_drive',
        )
        if not disconnected:
            return jsonify({'success': False, 'error': 'No connected Google Drive account found.'}), 404
        return jsonify({'success': True, 'data': {'message': 'Disconnected successfully'}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@storage_bp.route('/dashboard', methods=['GET'])
@require_jwt_auth
def get_dashboard():
    """Get storage dashboard with statistics"""
    try:
        user = _get_request_user()
        user_id = user['user_id']
        workspace_id = get_workspace_id()

        db = CentralizedDB()
        account = db.get_storage_account(user_id=user_id, workspace_id=workspace_id)

        if not account:
            return jsonify({'success': True, 'data': {'connected': False, 'storage_info': {}, 'user_id': user_id}}), 200

        conn = sqlite3.connect(db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('''
            SELECT COUNT(*) as file_count,
                   SUM(COALESCE(fi.file_size_bytes, fi.file_size, 0)) as total_size
            FROM file_index fi
            JOIN storage_accounts sa ON fi.storage_account_id = sa.id
            WHERE sa.user_id = ? AND sa.workspace_id = ?
        ''', (user_id, workspace_id))

        stats = dict(cursor.fetchone() or {})
        conn.close()

        return jsonify({'success': True, 'data': {'connected': True, 'storage_info': {'file_count': stats.get('file_count', 0), 'total_size': stats.get('total_size', 0), 'quota': 107374182400}, 'user_id': user_id}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@storage_bp.route('/files', methods=['GET'])
@require_jwt_auth
def get_files():
    """Get list of indexed files"""
    try:
        user = _get_request_user()
        user_id = user['user_id']
        workspace_id = get_workspace_id()

        db = CentralizedDB()
        conn = sqlite3.connect(db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('''
            SELECT fi.*
            FROM file_index fi
            JOIN storage_accounts sa ON fi.storage_account_id = sa.id
            WHERE sa.user_id = ? AND sa.workspace_id = ?
            ORDER BY fi.created_at DESC
            LIMIT 100
        ''', (user_id, workspace_id))

        files = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return jsonify({'success': True, 'data': {'files': files}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@storage_bp.route('/sync', methods=['POST'])
@require_jwt_auth
def sync_files():
    """Sync files from Google Drive"""
    try:
        workspace_id = get_workspace_id()
        # In real app, call Google Drive API to sync for this workspace
        return jsonify({'success': True, 'data': {'message': 'Sync started', 'files_synced': 0, 'workspace_id': workspace_id}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@storage_bp.route('/search', methods=['GET'])
@require_jwt_auth
def search_files():
    """Search indexed files"""
    try:
        user = _get_request_user()
        user_id = user['user_id']
        workspace_id = get_workspace_id()
        query = request.args.get('query', '').lower()

        if not query:
            return jsonify({'success': False, 'error': 'Query required'}), 400

        db = CentralizedDB()
        conn = sqlite3.connect(db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute('''
            SELECT fi.*
            FROM file_index fi
            JOIN storage_accounts sa ON fi.storage_account_id = sa.id
            WHERE sa.user_id = ? AND sa.workspace_id = ?
              AND (
                LOWER(fi.file_name) LIKE ? OR
                LOWER(fi.file_type) LIKE ? OR
                LOWER(fi.tags) LIKE ?
              )
            ORDER BY fi.created_at DESC
            LIMIT 50
        ''', (user_id, workspace_id, f'%{query}%', f'%{query}%', f'%{query}%'))

        files = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return jsonify({'success': True, 'data': {'results': files}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
