from flask import Blueprint, current_app, jsonify, request
import sqlite3
from datetime import datetime
import json

from app.routes.auth import require_jwt_auth, get_workspace_id

# Create blueprint
target_achievement_bp = Blueprint('target_achievement', __name__, url_prefix='/api/v1/target-achievement')

def get_db():
    conn = sqlite3.connect(current_app.config['DATABASE_PATH'])
    conn.row_factory = sqlite3.Row
    return conn

# ==================== ROUTES ====================

@target_achievement_bp.route('/years', methods=['GET'])
@require_jwt_auth
def get_years():
    """Get all fiscal years for the current workspace"""
    try:
        workspace_id = get_workspace_id()
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM target_achievement_years WHERE workspace_id = ? ORDER BY COALESCE(financial_year, year) DESC', (workspace_id,))
        years = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return jsonify({'success': True, 'data': {'years': years}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@target_achievement_bp.route('/years', methods=['POST'])
@require_jwt_auth
def create_year():
    """Create new fiscal year for the current workspace"""
    try:
        data = request.get_json()
        year = data.get('year')
        target = data.get('target')

        if not year or target is None:
            return jsonify({'success': False, 'error': 'Year and target required'}), 400

        workspace_id = get_workspace_id()
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO target_achievement_years (workspace_id, year, target, created_at)
            VALUES (?, ?, ?, ?)
        ''', (workspace_id, year, target, datetime.now().isoformat()))
        conn.commit()
        year_id = cursor.lastrowid
        conn.close()

        return jsonify({'success': True, 'data': {'year_id': year_id, 'year': year, 'target': target}}), 201
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@target_achievement_bp.route('/years/<int:year_id>', methods=['PUT'])
@require_jwt_auth
def update_year(year_id):
    """Update fiscal year target (workspace-scoped)"""
    try:
        data = request.get_json()
        target = data.get('target')

        if target is None:
            return jsonify({'success': False, 'error': 'Target required'}), 400

        workspace_id = get_workspace_id()
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE target_achievement_years 
            SET target = ?, updated_at = ?
            WHERE id = ? AND workspace_id = ?
        ''', (target, datetime.now().isoformat(), year_id, workspace_id))
        conn.commit()
        conn.close()

        return jsonify({'success': True, 'data': {'year_id': year_id, 'target': target}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@target_achievement_bp.route('/years/<int:year_id>/summary', methods=['GET'])
@require_jwt_auth
def get_summary(year_id):
    """Get target vs achievement summary (workspace-scoped)"""
    try:
        workspace_id = get_workspace_id()
        conn = get_db()
        cursor = conn.cursor()

        # Get year (workspace enforced)
        cursor.execute('SELECT * FROM target_achievement_years WHERE id = ? AND workspace_id = ?', (year_id, workspace_id))
        year = dict(cursor.fetchone() or {})

        if not year:
            return jsonify({'success': False, 'error': 'Year not found'}), 404

        # Get total achievement (prefer calculated_total or amount)
        cursor.execute('''
            SELECT SUM(COALESCE(calculated_total, amount, 0)) as total
            FROM target_achievement_uploads
            WHERE financial_year_id = ? AND workspace_id = ?
        ''', (year_id, workspace_id))
        result = cursor.fetchone()
        achievement = (result['total'] if result and result['total'] is not None else 0)

        conn.close()

        target = year.get('target', 0) or 0
        percentage = (achievement / target * 100) if target > 0 else 0

        return jsonify({'success': True, 'data': {'year_id': year_id, 'target': target, 'achievement': achievement, 'percentage': round(percentage, 2)}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@target_achievement_bp.route('/years/<int:year_id>/breakup', methods=['GET'])
@require_jwt_auth
def get_breakup(year_id):
    """Get distributor-wise breakup (workspace-scoped)"""
    try:
        workspace_id = get_workspace_id()
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT distributor_name, SUM(COALESCE(calculated_total, amount, 0)) as achievement, COUNT(*) as count
            FROM target_achievement_uploads
            WHERE financial_year_id = ? AND workspace_id = ?
            GROUP BY distributor_name
            ORDER BY achievement DESC
        ''', (year_id, workspace_id))

        breakup = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return jsonify({'success': True, 'data': {'breakup': breakup}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@target_achievement_bp.route('/years/<int:year_id>/upload', methods=['POST'])
@require_jwt_auth
def upload_achievement(year_id):
    """Upload achievement file (workspace-scoped)"""
    try:
        data = request.get_json()
        distributor = data.get('distributor_name')
        amount = data.get('amount')
        file_name = data.get('file_name')

        if not all([distributor, amount is not None, file_name]):
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400

        workspace_id = get_workspace_id()
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO target_achievement_uploads (workspace_id, financial_year_id, distributor_name, calculated_total, file_name, uploaded_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (workspace_id, year_id, distributor, amount, file_name, datetime.now().isoformat()))
        conn.commit()
        upload_id = cursor.lastrowid
        conn.close()

        return jsonify({'success': True, 'data': {'upload_id': upload_id}}), 201
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@target_achievement_bp.route('/summary', methods=['GET'])
@require_jwt_auth
def get_overall_summary():
    """Get overall summary across all years for the workspace"""
    try:
        workspace_id = get_workspace_id()
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT SUM(target_amount) as total_target,
                   SUM(COALESCE((SELECT SUM(calculated_total) FROM target_achievement_uploads WHERE financial_year_id = target_achievement_years.id AND workspace_id = ?), 0)) as total_achievement
            FROM target_achievement_years
            WHERE workspace_id = ?
        ''', (workspace_id, workspace_id))

        result = dict(cursor.fetchone() or {})
        conn.close()

        target = result.get('total_target', 0) or 0
        achievement = result.get('total_achievement', 0) or 0
        percentage = (achievement / target * 100) if target > 0 else 0

        return jsonify({'success': True, 'data': {'total_target': target, 'total_achievement': achievement, 'percentage': round(percentage, 2)}}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
