import sqlite3
from functools import wraps

from flask import (
    Blueprint,
    Response,
    current_app,
    jsonify,
    redirect,
    render_template,
    render_template_string,
    request,
    session,
    url_for,
)

from centralized_db_system.db import CentralizedDB
from app.jwt_service import JWTService
from app.utils import auth_enabled

auth_blueprint = Blueprint("auth", __name__)

LOGIN_TEMPLATE = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>NEXORA |Sign In</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 2rem; }
    form { max-width: 320px; display: grid; gap: 0.75rem; }
    input { padding: 0.6rem; }
    button { padding: 0.6rem 1rem; }
    .error { color: #b91c1c; }
  </style>
</head>
<body>
  <h1>Sign in</h1>
  <form method="post">
    <input name="username" placeholder="Username" required />
    <input name="password" type="password" placeholder="Password" required />
    <button type="submit">Sign In</button>
  </form>
  {% if error %}<p class="error">{{ error }}</p>{% endif %}
</body>
</html>
"""


def register_auth_hooks(app) -> None:
    app.before_request(enforce_auth)
    app.before_request(ensure_default_admin)


def get_jwt_service() -> JWTService:
    service = current_app.extensions.get("jwt_service")
    if service is None:
        secret_key = current_app.config.get("SECRET_KEY")
        if not secret_key:
            raise RuntimeError(
                "SECRET_KEY must be configured in app configuration before JWT service initialization."
            )
        service = JWTService(secret_key=secret_key)
        current_app.extensions["jwt_service"] = service
    return service


def require_jwt_auth(fn):
    @wraps(fn)
    def decorated(*args, **kwargs):
        if not auth_enabled():
            return fn(*args, **kwargs)

        # An explicit Authorization header always takes precedence —
        # this is a genuine token-based caller (mobile app, external
        # API client, etc.) and must be verified as a real JWT.
        if request.headers.get("Authorization"):
            return get_jwt_service().require_auth(fn)(*args, **kwargs)

        # CRITICAL FIX: a valid browser session (from the HTML /login
        # form) is just as trustworthy as a JWT for THIS SAME browser's
        # own requests — including calls to /api/* endpoints. Before
        # this fix, the /api/ path check below ran FIRST and ALWAYS
        # demanded a JWT for any /api/* route, even when the caller
        # already had a valid, authenticated session — meaning every
        # fetch() call made by the frontend's own JavaScript (app.js)
        # against /api/* routes (e.g. /api/v1/target-achievement/years,
        # /api/v1/storage/account) failed with 401, because nothing in
        # the browser-form login flow ever issues/stores a JWT Bearer
        # token for app.js to attach — it only sets a session cookie.
        # This silently broke entire dashboard sections (e.g. the
        # "Customers" tab, which fetches its data this way) for every
        # real browser user, while all our JWT-based automated tests
        # kept passing.
        if session.get("authenticated"):
            request.user = {
                "user_id": session.get("user_id"),
                "username": session.get("username"),
                "role": session.get("role", "unassigned"),
                "workspace_id": session.get("workspace_id", "default"),
            }
            return fn(*args, **kwargs)

        # No session, no Authorization header — genuine API-style
        # requests must supply a valid JWT; browser page routes get
        # redirected to the login form instead.
        if request.path.startswith("/api/") or request.is_json:
            return get_jwt_service().require_auth(fn)(*args, **kwargs)

        return redirect(url_for("auth.login"))

    return decorated


def require_role(*allowed_roles):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            user = getattr(request, "user", None)
            if not isinstance(user, dict) or user.get("role") not in allowed_roles:
                return (
                    jsonify(
                        {
                            "success": False,
                            "error": {
                                "code": "FORBIDDEN",
                                "message": "Insufficient permissions",
                            },
                        }
                    ),
                    403,
                )
            return fn(*args, **kwargs)

        return wrapped

    return decorator


def enforce_auth() -> Response | None:
    if not auth_enabled():
        return None

    if request.path in {
        "/login",
        "/logout",
        "/api/v1/auth/login",
        "/api/v1/auth/refresh",
        "/api/v1/auth/logout",
    }:
        return None
    if request.path.startswith("/api/"):
        return None
    if request.headers.get("Authorization") or request.is_json:
        return None
    if request.path.startswith("/static/"):
        return None
    if request.path in {
        "/manifest.json",
        "/service-worker.js",
        "/icon-192.svg",
        "/icon-512.svg",
    }:
        return None

    if session.get("authenticated"):
        return None

    return redirect(url_for("auth.login"))


def _get_auth_db() -> CentralizedDB:
    configured_db_path = current_app.config.get("DATABASE_PATH")
    if configured_db_path:
        return CentralizedDB(str(configured_db_path))
    return CentralizedDB()


def ensure_default_admin() -> None:
    if not auth_enabled():
        return
    _get_auth_db().ensure_default_admin_user()


def get_workspace_id() -> str:
    user = getattr(request, 'user', None)
    if isinstance(user, dict) and 'workspace_id' in user:
        return user['workspace_id']

    if not auth_enabled():
        return "default"

    raise RuntimeError(
        "Workspace ID cannot be determined from request parameters; authentication is required."
    )


def get_user_row(username: str) -> dict[str, object] | None:
    db = _get_auth_db()
    conn = sqlite3.connect(str(db.db_path))
    conn.row_factory = sqlite3.Row
    try:
        columns = {
            row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()
        }
        select_columns = ["id", "username", "password_hash"]
        if "role" in columns:
            select_columns.append("role")
        if "workspace_id" in columns:
            select_columns.append("workspace_id")
        query = f"SELECT {', '.join(select_columns)} FROM users WHERE username = ?"
        row = conn.execute(query, (username,)).fetchone()
        data = dict(row) if row is not None else None
        if data is not None and "role" not in data:
            data["role"] = "unassigned"
        if data is not None and "workspace_id" not in data:
            data["workspace_id"] = "default"
        return data
    finally:
        conn.close()


@auth_blueprint.route("/api/v1/auth/login", methods=["POST"], endpoint="api_login")
def api_login() -> tuple[Response, int]:
    data = request.get_json(silent=True) or request.form or {}
    username = (data.get("username") if isinstance(data, dict) else "").strip()
    password = data.get("password") if isinstance(data, dict) else ""

    if not username or not password:
        return (
            jsonify(
                {
                    "success": False,
                    "error": {
                        "code": "MISSING_CREDENTIALS",
                        "message": "Username and password required",
                    },
                }
            ),
            400,
        )

    db = _get_auth_db()
    user_row = get_user_row(username)
    if not user_row or not db.authenticate_user(username, password):
        return (
            jsonify(
                {
                    "success": False,
                    "error": {
                        "code": "INVALID_CREDENTIALS",
                        "message": "Invalid username or password",
                    },
                }
            ),
            401,
        )

    service = get_jwt_service()
    access_token, refresh_token = service.create_tokens(
        user_id=user_row.get("id", 1),
        username=user_row.get("username", username),
        role=user_row.get("role", "unassigned"),
        workspace_id=user_row.get("workspace_id", "default"),
    )
    return (
        jsonify(
            {
                "success": True,
                "data": {
                    "access_token": access_token,
                    "refresh_token": refresh_token,
                    "expires_in": service.access_token_expiry,
                    "token_type": "Bearer",
                    "user": {
                        "id": user_row.get("id", 1),
                        "username": user_row.get("username", username),
                        "role": user_row.get("role", "unassigned"),
                        "workspace_id": user_row.get("workspace_id", "default"),
                    },
                },
            }
        ),
        200,
    )


@auth_blueprint.route("/api/v1/auth/refresh", methods=["POST"], endpoint="api_refresh")
def api_refresh() -> tuple[Response, int]:
    data = request.get_json(silent=True) or {}
    refresh_token = data.get("refresh_token")
    if not refresh_token:
        return (
            jsonify(
                {
                    "success": False,
                    "error": {
                        "code": "NO_REFRESH_TOKEN",
                        "message": "Refresh token required",
                    },
                }
            ),
            400,
        )

    payload = get_jwt_service().verify_token(refresh_token)
    if "error" in payload:
        return (
            jsonify(
                {
                    "success": False,
                    "error": {
                        "code": "INVALID_REFRESH_TOKEN",
                        "message": payload["error"],
                    },
                }
            ),
            401,
        )

    if payload.get("type") != "refresh":
        return (
            jsonify(
                {
                    "success": False,
                    "error": {
                        "code": "INVALID_TOKEN_TYPE",
                        "message": "Not a refresh token",
                    },
                }
            ),
            401,
        )

    access_token, _ = get_jwt_service().create_tokens(
        user_id=payload.get("user_id", 1),
        username=payload.get("username", "admin"),
        role=payload.get("role", "unassigned"),
        workspace_id=payload.get("workspace_id", "default"),
    )
    return (
        jsonify(
            {
                "success": True,
                "data": {
                    "access_token": access_token,
                    "expires_in": get_jwt_service().access_token_expiry,
                    "token_type": "Bearer",
                },
            }
        ),
        200,
    )


@auth_blueprint.route("/api/v1/auth/logout", methods=["POST"], endpoint="api_logout")
def api_logout() -> tuple[Response, int]:
    return (
        jsonify({"success": True, "data": {"message": "Logged out successfully"}}),
        200,
    )


@auth_blueprint.route("/login", methods=["GET", "POST"], endpoint="login")
def login() -> str | Response:
    if not auth_enabled():
        session["authenticated"] = True
        return redirect("/")

    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        # Use _get_auth_db() (Flask-config based) instead of a bare
        # CentralizedDB() (env-var based) — these two can resolve to
        # DIFFERENT database files depending on how DATABASE_PATH is
        # configured, which is exactly the kind of inconsistency that
        # caused this session-based login to silently authenticate
        # against the wrong database in testing.
        if _get_auth_db().authenticate_user(username, password):
            user_row = get_user_row(username)
            session["authenticated"] = True
            session["username"] = username
            # CRITICAL: without storing role/workspace_id here, every
            # route that relies on get_workspace_id() will crash with
            # "Workspace ID cannot be determined..." for anyone who logs
            # in through this browser form (as opposed to the JSON API
            # login) — that gap only surfaced during real-world browser
            # testing, since all our automated tests used the JWT/API
            # login path, which sets request.user correctly.
            session["user_id"] = user_row.get("id") if user_row else None
            session["role"] = user_row.get("role", "unassigned") if user_row else "unassigned"
            session["workspace_id"] = user_row.get("workspace_id", "default") if user_row else "default"
            return redirect(request.args.get("next") or "/")
        error = "Invalid username or password"

    return render_template("index.html", error=error)


@auth_blueprint.route("/logout", endpoint="logout")
def logout() -> Response:
    session.clear()
    return redirect(url_for("auth.login"))
