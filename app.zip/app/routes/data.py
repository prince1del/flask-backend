import csv
import hashlib
import io
import json
import os
import re
import sqlite3
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from flask import (
    Blueprint,
    Response,
    jsonify,
    redirect,
    render_template_string,
    request,
    session,
    url_for,
)

from centralized_db_system.bale_to_pieces import calculate_bale_to_pieces
from centralized_db_system.db import CentralizedDB
from centralized_db_system.drive_storage import GoogleDriveStorage
from app.routes.auth import get_workspace_id, require_jwt_auth
from app.three_step_verification import (
    _extract_pdf_text,
    _parse_pdf_table_like_text,
    compare_step1,
    compare_step2,
    compare_step3,
    parse_step2_sales_order_pdf,
    run_full_verification,
)
from app.utils import (
    detect_upload_file_type,
    expected_upload_format,
    infer_ai_intent,
    infer_distributor_name,
    stage_label_for_key,
)
from app.verification import (
    parse_distributor_fields_from_text,
    parse_retailer_fields_from_text,
)


data_blueprint = Blueprint("data", __name__)

HTML_TEMPLATE = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
    <title>NEXORA |Order-to-Invoice Workflow</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 2rem; }
    form { margin-bottom: 2rem; }
    input[type=file] { margin-bottom: 1rem; display: block; }
    pre { background: #f5f5f5; padding: 1rem; border-radius: 6px; white-space: pre-wrap; }
    .card { border: 1px solid #ddd; padding: 1rem; margin-bottom: 1rem; border-radius: 8px; }
    .step-list { padding-left: 1.2rem; }
  </style>
</head>
<body>
    <h1>Order-to-Invoice Workflow</h1>
    <p>Common order sheet first aayegi, phir distributor-wise filled Excel, phir sales order PDF, aur last me commercial invoice PDF match hogi.</p>
    <p><strong>File rules:</strong> Order sheet aur distributor order hamesha Excel honge. Sales order aur commercial invoice hamesha PDF honge.</p>
        {% if locked_rules_summary %}
        <div class="card">
            <h2>Locked Business Rules</h2>
            <pre>{{ locked_rules_summary|safe }}</pre>
        </div>
        {% endif %}
    <div class="card">
        <h2>Workflow Stages</h2>
        <ol class="step-list">
            <li>Stage 1: Common order sheet upload and attach to all distributors (Excel)</li>
            <li>Stage 2: Distributor-wise filled order capture (Excel)</li>
            <li>Stage 3: Sales order match check (PDF)</li>
            <li>Stage 4: Commercial invoice match check (PDF)</li>
        </ol>
    </div>
    {% if stage_hint %}
    <div class="card" style="background: #eff6ff; border-color: #93c5fd;">
      <strong>Selected upload step:</strong> {{ stage_hint }}
    </div>
    {% endif %}
  {% if progress_summary %}
    <div class="card">
      <h2>Verification Progress</h2>
      <pre>{{ progress_summary|safe }}</pre>
    </div>
  {% endif %}
  <form method="post" enctype="multipart/form-data" id="verification-form">
      <label>Distributor name (optional, for distributor-wise tracking)</label>
      <input type="text" name="distributor_name" placeholder="e.g. Alpha Traders" style="margin-bottom: 1rem; display: block; width: 100%; max-width: 420px; padding: 0.4rem;" />
        <label>Order Sheet Name</label>
        <input type="text" name="order_sheet_name" placeholder="e.g. AW26 Bedsheet" style="margin-bottom: 1rem; display: block; width: 100%; max-width: 420px; padding: 0.4rem;" />
        <label>Order Sheet Category</label>
        <input type="text" name="order_sheet_category" placeholder="e.g. Bedsheet" style="margin-bottom: 1rem; display: block; width: 100%; max-width: 420px; padding: 0.4rem;" />
        <label>Order Sheet Active</label>
        <select name="order_sheet_is_active" style="margin-bottom: 1rem; display: block; width: 100%; max-width: 420px; padding: 0.4rem;">
            <option value="1" selected>Active</option>
            <option value="0">Inactive</option>
        </select>
        <label>Stage 1 - Common order sheet (Excel)</label>
        <input type="file" name="order_file" accept=".xlsx,.xls,.xlsm,.xlsb,.csv" onchange="updateFileLabel(this, 'order-label')">
    <div id="order-label">No file chosen</div>
        <label>Stage 2 - Distributor filled order (Excel)</label>
        <input type="file" name="filled_file" accept=".xlsx,.xls,.xlsm,.xlsb,.csv" onchange="updateFileLabel(this, 'filled-label')">
    <div id="filled-label">No file chosen</div>
        <label>Distributor for filled order</label>
        <select name="filled_file_distributor_id" style="margin-bottom: 1rem; display: block; width: 100%; max-width: 420px; padding: 0.4rem;">
            <option value="">Select distributor (recommended for Stage 2)</option>
            {% for distributor in distributor_options %}
                <option value="{{ distributor.id }}" {% if selected_filled_distributor_id == distributor.id|string %}selected{% endif %}>{{ distributor.firm_nick_name or distributor.name }} ({{ distributor.name }})</option>
            {% endfor %}
        </select>
        {% if suggested_filled_distributor_name %}
            <div class="card" style="background: #f8fafc; border-color: #93c5fd;">
                <strong>Suggested distributor:</strong> {{ suggested_filled_distributor_name }}
                {% if suggested_filled_distributor_name != selected_filled_distributor_name %}
                <div>Please confirm the distributor selection for this filled order.</div>
                {% endif %}
            </div>
        {% endif %}
        <label>Stage 3 - Sales order (PDF)</label>
        <input type="file" name="sales_order_file" accept=".pdf" onchange="updateFileLabel(this, 'sales-label')">
    <div id="sales-label">No file chosen</div>
        <label>Distributor for sales order</label>
        <select name="sales_order_distributor_id" style="margin-bottom: 1rem; display: block; width: 100%; max-width: 420px; padding: 0.4rem;">
            <option value="">Select distributor (recommended for Stage 3)</option>
            {% for distributor in distributor_options %}
                <option value="{{ distributor.id }}" {% if selected_sales_order_distributor_id == distributor.id|string %}selected{% endif %}>{{ distributor.firm_nick_name or distributor.name }} ({{ distributor.name }})</option>
            {% endfor %}
        </select>
        {% if sales_order_linking_summary %}
            <div class="card" style="background: #f8fafc; border-color: #93c5fd;">
                <strong>Sales Order Linking:</strong> {{ sales_order_linking_summary }}
            </div>
        {% endif %}
        <label>Stage 4 - Commercial invoice (PDF)</label>
        <input type="file" name="invoice_file" accept=".pdf" onchange="updateFileLabel(this, 'invoice-label')">
    <div id="invoice-label">No file chosen</div>
        <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
            <button type="submit" name="workflow_action" value="stage1">Save Stage 1</button>
            <button type="submit" name="workflow_action" value="stage2">Check Stage 2</button>
            <button type="submit" name="workflow_action" value="stage3">Check Stage 3</button>
            <button type="submit" name="workflow_action" value="stage4">Check Stage 4</button>
            <button type="submit" name="workflow_action" value="run_all">Run Full Verification</button>
        </div>
  </form>
  <script>
    function updateFileLabel(input, targetId) {
      const target = document.getElementById(targetId);
      target.textContent = input.files && input.files.length ? input.files[0].name : 'No file chosen';
    }
  </script>

  {% if report %}
    <h2>Verification Report</h2>
    <pre>{{ report|safe }}</pre>
  {% endif %}
    {% if report_data and report_data.get('step1') and report_data.get('step1').get('input_summary') %}
        <div class="card">
            <h2>Step 1 Inferred Mapping</h2>
            {% for name, summary in report_data.get('step1').get('input_summary').items() %}
                <h3>{{ name|capitalize }} Excel</h3>
                <p><strong>Columns:</strong> {{ summary.get('columns') }}</p>
                <p><strong>Inferred:</strong></p>
                <pre>{{ summary.get('inferred_columns') }}</pre>
            {% endfor %}
        </div>
    {% endif %}

    {% if report_data and report_data.get('uploaded_documents') %}
        <div class="card">
            <h2>Recognized Uploads</h2>
            <pre>{{ report_data.get('uploaded_documents') }}</pre>
        </div>
    {% endif %}

  <div class="card">
    <h2>Global Search</h2>
    <form method="get" action="/">
      <input name="q" value="{{ search_query }}" placeholder="Search masters, visits, verification outputs, analytics" style="width: 100%; padding: 0.5rem;" />
      <button type="submit">Search</button>
    </form>
    {% if search_results %}
      <pre>{{ search_results|safe }}</pre>
    {% endif %}
  </div>
  <div class="card">
    <h2>Performance Analytics</h2>
    <p><a href="/analytics">Open analytics dashboard</a></p>
    {% if report %}
      <p><a href="/download/report">Download verification report</a></p>
    {% endif %}
  </div>
  <div class="card">
    <h2>Sync Status</h2>
    <pre>{{ sync_status|safe }}</pre>
  </div>
</body>
</html>
"""


def _db_path() -> str:
    try:
        from flask import current_app

        configured_path = current_app.config.get("DATABASE_PATH")
        if configured_path:
            return str(configured_path)
    except Exception:
        configured_path = None

    env_path = os.getenv("DATABASE_PATH")
    if env_path:
        return str(env_path)

    database_url = os.getenv("DATABASE_URL")
    if database_url and database_url.startswith("sqlite://"):
        sqlite_path = database_url.removeprefix("sqlite://")
        if sqlite_path.startswith("/") and len(sqlite_path) >= 3 and sqlite_path[2] == ":":
            sqlite_path = sqlite_path[1:]
        return sqlite_path

    return "centralized_db.sqlite3"


def _fingerprint_file(path: str | Path | None) -> str | None:
    if not path:
        return None
    target_path = Path(path)
    if not target_path.exists() or not target_path.is_file():
        return None

    digest = hashlib.sha256()
    try:
        with target_path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except Exception:
        return None


def _get_verification_upload_dir() -> Path:
    upload_root = (
        Path("app/instance/verification_uploads")
        if Path("app/instance/verification_uploads").exists()
        else Path("instance/verification_uploads")
    )
    upload_root.mkdir(parents=True, exist_ok=True)
    session_id = session.get("verification_session_id") or str(uuid.uuid4())
    session["verification_session_id"] = session_id
    session_dir = upload_root / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    return session_dir


def _normalize_text(value: Any) -> str:
    return str(value or "").strip().lower()


def _names_match(a: str | None, b: str | None) -> bool:
    if not a or not b:
        return False
    a_norm = _normalize_text(a)
    b_norm = _normalize_text(b)
    return a_norm == b_norm or a_norm in b_norm or b_norm in a_norm


def _build_sales_order_match_summary(
    match_distributor_name: str | None,
    suggested_distributor_name: str | None,
    buyer_name: str | None,
    selected_distributor_name: str | None,
) -> str | None:
    if match_distributor_name and selected_distributor_name:
        if _names_match(match_distributor_name, selected_distributor_name):
            return (
                f"Buyer Code and selected distributor both match {selected_distributor_name}."
            )
        return (
            f"Buyer Code suggests {match_distributor_name}, but selected distributor is {selected_distributor_name}."
        )
    if match_distributor_name and not selected_distributor_name:
        if buyer_name:
            return (
                f"Buyer Code suggests {match_distributor_name}, buyer name text is {buyer_name}. Please confirm manually."
            )
        return (
            f"Buyer Code suggests {match_distributor_name}. Please confirm the distributor manually."
        )
    if not match_distributor_name and selected_distributor_name:
        return (
            f"No distributor found from Buyer Code. Using selected distributor {selected_distributor_name}."
        )
    return None


def _normalize_upload_filename(filename: str) -> str:
    return " ".join(
        word.strip()
        for word in Path(filename).stem.replace("_", " ").replace("-", " ").split()
        if word.strip()
    ).lower()


def _suggest_filled_order_distributor(
    filename: str, workspace_id: str
) -> dict[str, Any] | None:
    if not filename or not workspace_id:
        return None
    stem = _normalize_upload_filename(filename)
    if not stem:
        return None

    db = CentralizedDB(_db_path())
    distributors = db.list_master_distributors(limit=200, workspace_id=workspace_id)
    for distributor in distributors:
        nick = (distributor.get("firm_nick_name") or "").strip().lower()
        if nick and nick in stem:
            return distributor

    # Fallback: suggest on exact distributor name token match
    for distributor in distributors:
        name = (distributor.get("name") or "").strip().lower()
        if name and name in stem:
            return distributor

    return None


GSTIN_PATTERN = re.compile(r"\b\d{2}[A-Z]{5}\d{4}[A-Z]\d[A-Z][A-Z0-9]\b")


def _extract_all_gstins(text: str) -> list[str]:
    """
    Finds every GSTIN-format token in the document text (there are
    typically two: the SELLER's own GSTIN, which appears on every
    document regardless of buyer, and the BUYER's GSTIN, which is what
    we actually want). Returns unique values in the order first seen.
    The caller is responsible for excluding the workspace's own known
    company GST (via Company Profile) to isolate the buyer's GST —
    this function stays workspace-agnostic and purely textual.
    """
    matches = GSTIN_PATTERN.findall((text or "").upper())
    seen: list[str] = []
    for m in matches:
        if m not in seen:
            seen.append(m)
    return seen


def _parse_sales_order_header_fields(text: str) -> dict[str, str]:
    parsed: dict[str, str] = {}
    normalized_text = re.sub(r"\(cid:\d+\)", "\n", text or "")
    normalized_text = re.sub(r"[\r\f\v]+", "\n", normalized_text)
    lines = [line.strip() for line in normalized_text.splitlines() if line.strip()]
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        normalized_key = _normalize_text(key).replace(" ", "_")
        cleaned_value = value.strip()
        if not cleaned_value:
            continue
        if normalized_key in {"buyer_code", "buyer_id", "buyer"}:
            parsed["buyer_code"] = cleaned_value
        elif normalized_key in {
            "order_ref",
            "order_ref_no",
            "order_reference",
            "so_number",
            "so_no",
            "sales_order_number",
            "contract_no",
            "contract_number",
        }:
            parsed["order_ref_no"] = cleaned_value
        elif normalized_key in {
            "buyer_name",
            "client_name",
            "customer_name",
            "distributor_name",
            "party_name",
            "bill_to",
            "ship_to",
            "buyer",
            "distributor",
            # "Name (of the customer):" — the label used in the
            # founder's real Commercial Invoice documents. The
            # trailing "(of the customer)" gets folded into
            # underscores by the normalize+replace step above, so the
            # normalized key looks like "name_(of_the_customer)" — we
            # match it as a substring check below instead of an exact
            # set-membership, since parentheses don't normalize
            # predictably across all PDF-extraction libraries.
        }:
            parsed["buyer_name"] = cleaned_value
        elif "name" in normalized_key and "customer" in normalized_key:
            parsed["buyer_name"] = cleaned_value

    if "buyer_code" not in parsed:
        match = re.search(
            r"\b(?:buyer\s*code|buyer\s*id|party\s*code|retailer\s*code|distributor\s*code|customer\s*code)\b[:\s]*([A-Za-z0-9\-/]+)",
            text,
            re.I,
        )
        if match:
            parsed["buyer_code"] = match.group(1).strip()

    if "order_ref_no" not in parsed:
        match = re.search(
            r"\b(?:order\s*ref(?:erence)?|so(?:\s*no|\s*number)?|sales\s*order\s*(?:no|number)?|contract\s*(?:no|number)?)\b[:\s]*([A-Za-z0-9\-/]+)",
            text,
            re.I,
        )
        if match:
            parsed["order_ref_no"] = match.group(1).strip()

    if "buyer_name" not in parsed:
        match = re.search(
            r"\b(?:buyer\s*name|distributor\s*name|party\s*name|client\s*name|customer\s*name|bill\s*to|ship\s*to)\b[:\s]*(.+?)(?:\r?$|\n)",
            text,
            re.I | re.M,
        )
        if match:
            parsed["buyer_name"] = match.group(1).strip()

    # GST numbers — ALL found in the document. The caller excludes
    # the workspace's own known company GST (via Company Profile) to
    # determine which remaining one is the buyer's. Deliberately does
    # NOT guess/exclude here, since this function has no workspace
    # context of its own.
    parsed_gst_list = _extract_all_gstins(text)
    if parsed_gst_list:
        parsed["all_gst_numbers"] = ",".join(parsed_gst_list)

    return parsed


def _identify_buyer_gst(all_gst_numbers: list[str], own_company_gst: str | None) -> str | None:
    """
    Given every GSTIN found in a document, returns the one that is
    genuinely the BUYER's — i.e. everything EXCEPT the workspace's own
    known company GST (from Company Profile). If there isn't exactly
    one remaining candidate (none left, or more than one — e.g. the
    document also lists a transporter's GST), returns None rather than
    guessing, so the caller can fall back to Buyer Code / fuzzy-name
    matching instead.
    """
    if not all_gst_numbers:
        return None
    own_normalized = (own_company_gst or "").strip().upper()
    candidates = [g for g in all_gst_numbers if g != own_normalized]
    if len(candidates) == 1:
        return candidates[0]
    return None


def _build_sales_order_link_summary(
    selected_name: str | None,
    matched_name: str | None,
    buyer_name: str | None,
) -> str:
    if matched_name and selected_name:
        if selected_name.lower().strip() == matched_name.lower().strip():
            return (
                f"Is this SO for {selected_name}? Buyer Code and selected distributor both matched."
            )
        return (
            f"Buyer Code suggests {matched_name}, but selected distributor is {selected_name}. Please confirm manually."
        )
    if matched_name and not selected_name:
        if buyer_name:
            return (
                f"Buyer Code suggests {matched_name}, buyer name text is {buyer_name}. Please confirm manually."
            )
        return f"Buyer Code suggests {matched_name}. Please confirm manually."
    if not matched_name and selected_name:
        return f"Selected distributor is {selected_name}. Buyer Code could not be matched automatically."
    return "Sales order distributor could not be linked automatically. Please confirm manually."


DASHBOARD_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "dashboard_config.json"
DEFAULT_DASHBOARD_CONFIG = {
    "brand_name": "NEXORA",
    "app_name": "Jarvis Business Platform",
    "dashboard_title": "Jarvis PWA Dashboard",
    "short_name": "Jarvis",
    "theme_color": "#020617",
    "background_color": "#020617",
    "enabled_modules": [
        "dashboard",
        "verification",
        "analytics",
        "masters",
        "sales",
        "inventory",
        "reports",
        "file_library",
        "party_match",
    ],
    "api_endpoints": {
        "dashboard_summary": "/api/v1/dashboard/summary",
        "manifest": "/manifest.json",
    },
}


def _dashboard_config_path() -> Path:
    try:
        from flask import current_app

        config_path = current_app.config.get("DASHBOARD_CONFIG_PATH")
        if config_path:
            return Path(config_path)
    except Exception:
        pass
    return DASHBOARD_CONFIG_PATH


def _ensure_dashboard_config_exists() -> None:
    config_path = _dashboard_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    if not config_path.exists():
        config_path.write_text(
            json.dumps(DEFAULT_DASHBOARD_CONFIG, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def load_dashboard_config() -> dict[str, Any]:
    config_path = _dashboard_config_path()
    _ensure_dashboard_config_exists()
    try:
        return json.loads(config_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        config_path.write_text(
            json.dumps(DEFAULT_DASHBOARD_CONFIG, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return dict(DEFAULT_DASHBOARD_CONFIG)


def save_dashboard_config(update_data: dict[str, Any]) -> dict[str, Any]:
    config = load_dashboard_config()
    config.update(update_data)
    config_path = _dashboard_config_path()
    config_path.write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return config


@data_blueprint.route("/api/v1/masters/bulk-upload", methods=["GET", "POST"])
@require_jwt_auth
def bulk_upload() -> tuple[Response, int] | str:
    if request.method == "GET":
        return """
        <!doctype html>
        <html>
        <head><meta charset=\"utf-8\"><title>NEXORA |Bulk Upload Masters</title></head>
        <body style=\"font-family: Arial, sans-serif; margin: 2rem;\">
          <h1>Bulk Upload Masters</h1>
                        <p>
                          Download templates:
                          <a href=\"/api/v1/masters/template/distributors\">Distributor Excel</a> |
                          <a href=\"/api/v1/masters/template/distributors?format=csv\">Distributor CSV</a> |
                          <a href=\"/api/v1/masters/template/retailers\">Retailer Excel</a> |
                          <a href=\"/api/v1/masters/template/retailers?format=csv\">Retailer CSV</a> |
                          <a href=\"/api/v1/masters/template/articles\">Article Excel</a> |
                          <a href=\"/api/v1/masters/template/articles?format=csv\">Article CSV</a>
                        </p>
          <form method=\"post\" enctype=\"multipart/form-data\">
            <p><label>File <input type=\"file\" name=\"file\" required /></label></p>
            <p><label>Master Type
              <select name=\"master_type\">
                <option value=\"distributors\">Distributors</option>
                <option value=\"retailers\">Retailers</option>
              </select>
            </label></p>
            <p><button type=\"submit\">Upload</button></p>
          </form>
        </body>
        </html>
        """

    uploaded_file = request.files.get("file")
    if uploaded_file is None or uploaded_file.filename == "":
        return (
            jsonify({"status": "error", "message": "No file part in the request"}),
            400,
        )

    filename = uploaded_file.filename or ""
    master_type = (request.form.get("master_type") or "distributors").strip().lower()
    if master_type not in {"distributors", "retailers"}:
        return jsonify({"status": "error", "message": "Unsupported master type"}), 400

    suffix = Path(filename).suffix.lower()
    content_type = (uploaded_file.mimetype or "").lower()
    supported_suffixes = {".csv", ".xlsx", ".xls", ".xlsm", ".xlsb", ".pdf"}
    supported_content_types = {
        "text/csv",
        "application/csv",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/pdf",
        "application/octet-stream",
        "application/x-download",
        "application/x-unknown",
        "binary/octet-stream",
        "multipart/form-data",
        "text/plain",
        "application/xml",
    }

    try:
        content = uploaded_file.read()
        if not content:
            return (
                jsonify({"status": "error", "message": "Uploaded file is empty"}),
                400,
            )

        if suffix in supported_suffixes:
            temp_suffix = suffix or ".xlsx"
        elif "excel" in content_type or "spreadsheet" in content_type:
            temp_suffix = ".xlsx"
        elif "pdf" in content_type:
            temp_suffix = ".pdf"
        elif content_type in supported_content_types or suffix in supported_suffixes:
            temp_suffix = ".csv"
        else:
            temp_suffix = ".bin"

        with tempfile.NamedTemporaryFile(suffix=temp_suffix, delete=False) as handle:
            handle.write(content)
            temp_path = handle.name

        # On Windows the temporary file must be closed before other libraries read it.
        if temp_suffix == ".pdf":
            try:
                extracted_text = _extract_pdf_text(temp_path)
                parsed_data = _parse_pdf_table_like_text(extracted_text)
                parsed_payload = {
                    "file_type": "pdf",
                    "text_preview": extracted_text[:1000],
                    "parsed_fields": parsed_data,
                }
                if master_type == "distributors":
                    distributor_fields = parse_distributor_fields_from_text(
                        extracted_text
                    )
                    if distributor_fields.get("name"):
                        workspace_id = get_workspace_id()
                        db = CentralizedDB(_db_path())
                        inserted_id = db.add_master_distributor(
                            name=distributor_fields["name"],
                            distributor_code=distributor_fields.get("distributor_code"),
                            buyer_code=distributor_fields.get("buyer_code"),
                            firm_name=distributor_fields.get("firm_name"),
                            firm_nick_name=distributor_fields.get("firm_nick_name"),
                            gst_no=distributor_fields.get("gst_no"),
                            zone=distributor_fields.get("zone"),
                            region=distributor_fields.get("region"),
                            credit_limit=distributor_fields.get("credit_limit")
                            if isinstance(
                                distributor_fields.get("credit_limit"), (int, float)
                            )
                            else None,
                            workspace_id=workspace_id,
                        )
                        connection = sqlite3.connect(db.db_path)
                        try:
                            connection.execute(
                                "UPDATE master_distributors SET name = ?, firm_name = ?, firm_nick_name = ?, gst_no = ?, buyer_code = ?, zone = ?, region = ?, credit_limit = ?, phone_number = ?, email = ?, address = ? WHERE id = ?",
                                (
                                    distributor_fields.get("name"),
                                    distributor_fields.get("firm_name"),
                                    distributor_fields.get("firm_nick_name"),
                                    distributor_fields.get("gst_no"),
                                    distributor_fields.get("buyer_code"),
                                    distributor_fields.get("zone"),
                                    distributor_fields.get("region"),
                                    distributor_fields.get("credit_limit")
                                    if isinstance(
                                        distributor_fields.get("credit_limit"),
                                        (int, float),
                                    )
                                    else None,
                                    distributor_fields.get("phone_number"),
                                    distributor_fields.get("email"),
                                    distributor_fields.get("address"),
                                    inserted_id,
                                ),
                            )
                            connection.commit()
                        finally:
                            connection.close()
                        parsed_payload["persisted_distributor_id"] = inserted_id
                elif master_type == "retailers":
                    retailer_fields = parse_retailer_fields_from_text(extracted_text)
                    if retailer_fields.get("name"):
                        workspace_id = get_workspace_id()
                        db = CentralizedDB(_db_path())
                        distributor = None
                        reference = retailer_fields.get("distributor_reference")
                        if reference:
                            distributor = db.get_master_distributor_by_name(
                                reference, workspace_id=workspace_id
                            )
                            if distributor is None:
                                distributor = (
                                    db._find_master_distributor_by_gst_or_name(
                                        reference,
                                        workspace_id=workspace_id,
                                    )
                                )
                        if distributor is None and reference:
                            distributor = db._find_or_create_distributor_from_reference(
                                reference,
                                workspace_id=workspace_id,
                            )
                        if distributor is None:
                            distributor = db._find_or_create_distributor_from_reference(
                                retailer_fields.get("name", ""),
                                workspace_id=workspace_id,
                            )
                        if distributor is not None:
                            inserted_id = db.add_master_retailer(
                                name=retailer_fields["name"],
                                distributor_id=distributor["id"],
                                location=retailer_fields.get("location"),
                                workspace_id=workspace_id,
                                conn=None,
                            )
                            connection = sqlite3.connect(db.db_path)
                            try:
                                connection.execute(
                                    "UPDATE master_retailers SET name = ?, location = ?, phone_number = ?, email = ?, address = ?, gst_no = ? WHERE id = ?",
                                    (
                                        retailer_fields.get("name"),
                                        retailer_fields.get("location"),
                                        retailer_fields.get("phone_number"),
                                        retailer_fields.get("email"),
                                        retailer_fields.get("address"),
                                        retailer_fields.get("gst_no"),
                                        inserted_id,
                                    ),
                                )
                                connection.commit()
                            finally:
                                connection.close()
                            parsed_payload["persisted_retailer_id"] = inserted_id
            except Exception:
                parsed_payload = {
                    "file_type": "pdf",
                    "text_preview": "",
                    "parsed_fields": {},
                }

            if os.path.exists(temp_path):
                os.remove(temp_path)
            return (
                jsonify(
                    {
                        "status": "success",
                        "message": f"Received PDF file {filename}; PDF uploads are accepted and queued for future processing",
                        "rows": 0,
                        "inserted": 1
                        if (
                            (
                                master_type == "distributors"
                                and parsed_payload.get("persisted_distributor_id")
                            )
                            or (
                                master_type == "retailers"
                                and parsed_payload.get("persisted_retailer_id")
                            )
                        )
                        else 0,
                        "updated": 0,
                        "skipped": 0,
                        "errors": [],
                        "file_type": "pdf",
                        "parsed_data": parsed_payload,
                    }
                ),
                200,
            )

        if temp_suffix in {".bin", ".txt", ".json", ".xml"}:
            if os.path.exists(temp_path):
                os.remove(temp_path)
            return (
                jsonify(
                    {
                        "status": "success",
                        "message": f"Received file {filename}; upload accepted for future processing",
                        "rows": 0,
                        "inserted": 0,
                        "updated": 0,
                        "skipped": 0,
                        "errors": [],
                        "file_type": suffix.lstrip(".") or "unknown",
                    }
                ),
                200,
            )

        try:
            result = CentralizedDB(_db_path()).bulk_upload_masters(
                master_type, temp_path
            )
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

        return (
            jsonify(
                {
                    "status": "success",
                    "message": f"Successfully processed {result['rows_processed']} rows from {filename}",
                    "rows": int(result["rows_processed"]),
                    "inserted": int(result["inserted"]),
                    "updated": int(result.get("updated", 0)),
                    "skipped": int(result["skipped"]),
                    "errors": result.get("errors", []),
                    "file_type": suffix.lstrip(".") if suffix else "unknown",
                }
            ),
            200,
        )
    except Exception as exc:
        return jsonify({"status": "error", "message": str(exc)}), 500


@data_blueprint.route("/api/v1/contacts/import-export", methods=["GET"])
@require_jwt_auth
def contacts_import_export() -> str:
    return """
    <!doctype html>
    <html>
    <head><meta charset=\"utf-8\"><title>NEXORA |Contacts Import Export</title></head>
    <body style=\"font-family: Arial, sans-serif; margin: 2rem;\">
                <h1>Contacts Import/Export</h1>
                <p>Use blank template download, fill contact details, and upload for insert/update for both distributors and retailers.</p>
      <p><strong>Allowed formats:</strong> CSV and Excel only (no PDF).</p>
                <h2>Blank Template Download</h2>
      <p>
                    Distributor:
                    <a href=\"/api/v1/masters/template/distributors\">Excel</a> |
                    <a href=\"/api/v1/masters/template/distributors?format=csv\">CSV</a>
                </p>
                <p>
                    Retailer:
                    <a href=\"/api/v1/masters/template/retailers\">Excel</a> |
                    <a href=\"/api/v1/masters/template/retailers?format=csv\">CSV</a>
      </p>
      <h2>Current Data Export</h2>
      <p>
                    Distributor:
                    <a href=\"/download/distributors/excel\">Excel</a> |
                    <a href=\"/download/distributors\">CSV</a>
                </p>
                <p>
                    Retailer:
                    <a href=\"/download/retailers/excel\">Excel</a> |
                    <a href=\"/download/retailers\">CSV</a>
      </p>
      <h2>Upload Filled Sheet</h2>
      <form method=\"post\" action=\"/api/v1/contacts/import\" enctype=\"multipart/form-data\">
                    <p>
                        <label>Contact Type
                            <select name=\"master_type\">
                                <option value=\"distributors\">Distributors</option>
                                <option value=\"retailers\">Retailers</option>
                            </select>
                        </label>
                    </p>
        <p><label>File <input type=\"file\" name=\"file\" accept=\".csv,.xlsx,.xls,.xlsm,.xlsb\" required /></label></p>
        <p><button type=\"submit\">Upload and Update Contacts</button></p>
      </form>
      <p><a href=\"/analytics\">Back to analytics</a></p>
    </body>
    </html>
    """


@data_blueprint.route("/api/v1/contacts/import", methods=["POST"])
@require_jwt_auth
def import_contacts() -> tuple[Response, int]:
    uploaded_file = request.files.get("file")
    if uploaded_file is None or uploaded_file.filename == "":
        return (
            jsonify({"status": "error", "message": "No file part in the request"}),
            400,
        )

    master_type = (request.form.get("master_type") or "distributors").strip().lower()
    if master_type not in {"distributors", "retailers"}:
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "Unsupported contact type. Use distributors or retailers.",
                }
            ),
            400,
        )

    filename = uploaded_file.filename or ""
    suffix = Path(filename).suffix.lower()
    content_type = (uploaded_file.mimetype or "").lower()
    allowed_suffixes = {".csv", ".xlsx", ".xls", ".xlsm", ".xlsb"}
    excel_csv_content_types = {
        "text/csv",
        "application/csv",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/octet-stream",
        "application/x-download",
        "application/x-unknown",
        "binary/octet-stream",
        "multipart/form-data",
        "text/plain",
        "application/xml",
    }

    if suffix == ".pdf" or "pdf" in content_type:
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "PDF is not allowed. Please upload CSV or Excel file.",
                }
            ),
            400,
        )

    if suffix not in allowed_suffixes and content_type not in excel_csv_content_types:
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "Unsupported file format. Please upload CSV or Excel file.",
                }
            ),
            400,
        )

    try:
        content = uploaded_file.read()
        if not content:
            return (
                jsonify({"status": "error", "message": "Uploaded file is empty"}),
                400,
            )

        temp_suffix = suffix if suffix in allowed_suffixes else ".xlsx"
        with tempfile.NamedTemporaryFile(suffix=temp_suffix, delete=False) as handle:
            handle.write(content)
            temp_path = handle.name

        try:
            result = CentralizedDB(_db_path()).bulk_upload_masters(
                master_type, temp_path
            )
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

        return (
            jsonify(
                {
                    "status": "success",
                    "message": f"Successfully processed {result['rows_processed']} rows from {filename} for {master_type}",
                    "master_type": master_type,
                    "rows": int(result["rows_processed"]),
                    "inserted": int(result.get("inserted", 0)),
                    "updated": int(result.get("updated", 0)),
                    "skipped": int(result.get("skipped", 0)),
                    "errors": result.get("errors", []),
                    "file_type": suffix.lstrip(".") if suffix else "unknown",
                }
            ),
            200,
        )
    except Exception as exc:
        return jsonify({"status": "error", "message": str(exc)}), 500


@data_blueprint.route("/api/v1/masters/template/<master_type>")
@require_jwt_auth
def download_master_template(master_type: str) -> Response:
    file_format = (request.args.get("format") or "excel").strip().lower()
    if file_format not in {"excel", "csv"}:
        return jsonify({"status": "error", "message": "Unsupported format"}), 400

    try:
        payload = CentralizedDB(_db_path()).generate_master_template(
            master_type, file_format=file_format
        )
    except ValueError as exc:
        return jsonify({"status": "error", "message": str(exc)}), 400

    if file_format == "csv":
        mimetype = "text/csv"
        extension = "csv"
    else:
        mimetype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        extension = "xlsx"

    response = Response(payload, mimetype=mimetype)
    response.headers[
        "Content-Disposition"
    ] = f"attachment; filename={master_type}_template.{extension}"
    return response


@data_blueprint.route("/legacy", methods=["GET", "POST"], endpoint="index")
@require_jwt_auth
def index() -> str:
    report = None
    progress_summary = None
    selected_stage = ""
    stage_hint = None
    if request.method == "GET":
        stage_param = (request.args.get("stage") or "").strip().lower()
        if stage_param in {"1", "stage1"}:
            selected_stage = "stage1"
            stage_hint = "Upload only the common order sheet (Stage 1)."
        elif stage_param in {"2", "stage2"}:
            selected_stage = "stage2"
            stage_hint = "Upload the customer placed order file together with the related order sheet (Stage 2)."
        elif stage_param in {"3", "stage3"}:
            selected_stage = "stage3"
            stage_hint = "Upload the sales order PDF against the order sheet (Stage 3)."
        elif stage_param in {"4", "stage4"}:
            selected_stage = "stage4"
            stage_hint = "Upload the commercial invoice PDF against the sales order (Stage 4)."
    search_query = request.args.get("q", "") if request.method == "GET" else ""
    search_results = None
    db = CentralizedDB(_db_path())
    locked_rules_summary = json.dumps(
        db.list_business_rules(locked_only=True), indent=2
    )
    distributor_options = db.list_master_distributors(
        limit=200, workspace_id=get_workspace_id()
    )
    suggested_filled_distributor_name = None
    selected_filled_distributor_name = None
    selected_filled_distributor_id = ""
    selected_sales_order_distributor_id = ""
    selected_sales_order_distributor_name = None
    sales_order_linking_summary = None
    filled_file_distributor = None
    if request.method == "POST":
        workflow_action = (
            (request.form.get("workflow_action") or "run_all").strip().lower()
        )
        distributor_name = (request.form.get("distributor_name") or "").strip()
        order_sheet_name = (request.form.get("order_sheet_name") or "").strip()
        order_sheet_category = (request.form.get("order_sheet_category") or "").strip()
        order_sheet_is_active = str(
            request.form.get("order_sheet_is_active", "1") or "1"
        ).strip().lower()
        order_sheet_is_active = 0 if order_sheet_is_active in {"0", "false", "no", "off", ""} else 1
        selected_filled_distributor_id = (
            request.form.get("filled_file_distributor_id") or ""
        ).strip()
        filled_file_distributor = None
        if selected_filled_distributor_id.isdigit():
            filled_file_distributor = db.get_master_distributor(
                int(selected_filled_distributor_id),
                workspace_id=get_workspace_id(),
            )
            if filled_file_distributor is not None:
                selected_filled_distributor_name = filled_file_distributor["name"]

        selected_sales_order_distributor_id = (
            request.form.get("sales_order_distributor_id") or ""
        ).strip()
        sales_order_distributor = None
        if selected_sales_order_distributor_id.isdigit():
            sales_order_distributor = db.get_master_distributor(
                int(selected_sales_order_distributor_id),
                workspace_id=get_workspace_id(),
            )
            if sales_order_distributor is not None:
                selected_sales_order_distributor_name = sales_order_distributor["name"]

        order_sheet_distributor = distributor_name
        order_sheet_distributor_id = None
        files = {
            "order_file": request.files.get("order_file"),
            "filled_file": request.files.get("filled_file"),
            "sales_order_file": request.files.get("sales_order_file"),
            "invoice_file": request.files.get("invoice_file"),
        }
        upload_dir = _get_verification_upload_dir()
        stored_files = {}
        stored_metadata = dict(session.get("verification_file_metadata", {}))
        for key, stored_path in session.get("verification_files", {}).items():
            if stored_path and os.path.exists(stored_path):
                stored_files[key] = stored_path

        if files.get("order_file") and files["order_file"].filename:
            stored_files = {}
            stored_metadata = {}

        stage_upload_map = {
            "stage1": {"order_file"},
            "stage2": {"order_file", "filled_file"},
            "stage3": {"filled_file", "sales_order_file"},
            "stage4": {"sales_order_file", "invoice_file"},
            "run_all": {
                "order_file",
                "filled_file",
                "sales_order_file",
                "invoice_file",
            },
        }
        permitted_keys = stage_upload_map.get(
            workflow_action, stage_upload_map["run_all"]
        )
        persisted_upload_ids: list[int] = []
        persisted_order_sheet_ids: list[int] = []

        for key, uploaded_file in files.items():
            if key not in permitted_keys:
                continue
            if not uploaded_file or not uploaded_file.filename:
                continue

            suffix = Path(uploaded_file.filename).suffix.lower()
            content_type = (uploaded_file.mimetype or "").lower()
            detected_file_type = detect_upload_file_type(
                uploaded_file.filename, content_type
            )
            expected_format = expected_upload_format(key)
            if (
                expected_format["extensions"]
                and suffix not in expected_format["extensions"]
                and content_type not in expected_format["content_types"]
            ):
                report = json.dumps(
                    {
                        "status": "error",
                        "message": f"{key} must be uploaded in the expected file format",
                        "expected_extensions": sorted(expected_format["extensions"]),
                        "received_extension": suffix,
                        "received_content_type": content_type,
                    },
                    indent=2,
                )
                progress_summary = "Upload rejected because the file type does not match the required format."
                return render_template_string(
                    HTML_TEMPLATE,
                    report=report,
                    report_data=json.loads(report),
                    progress_summary=progress_summary,
                    locked_rules_summary=locked_rules_summary,
                    sync_status=json.dumps({}, indent=2),
                    search_query=search_query,
                    search_results=search_results,
                    distributor_options=distributor_options,
                    suggested_filled_distributor_name=suggested_filled_distributor_name,
                    selected_filled_distributor_name=selected_filled_distributor_name,
                    selected_filled_distributor_id=selected_filled_distributor_id,
                    selected_sales_order_distributor_id=selected_sales_order_distributor_id,
                    selected_sales_order_distributor_name=selected_sales_order_distributor_name,
                    sales_order_linking_summary=sales_order_linking_summary,
                )

            safe_name = Path(uploaded_file.filename).name
            target_path = upload_dir / f"{key}_{safe_name}"
            uploaded_file.save(target_path)
            stored_files[key] = str(target_path)
            inferred_distributor_name = infer_distributor_name(
                key, safe_name, explicit_name=distributor_name
            )
            if key == "filled_file" and filled_file_distributor is not None:
                inferred_distributor_name = filled_file_distributor["name"]
            stored_metadata[key] = {
                "stage": stage_label_for_key(key),
                "file_type": detected_file_type,
                "filename": safe_name,
                "distributor_name": inferred_distributor_name,
                "uploaded_at": datetime.now(timezone.utc).isoformat(),
            }
            if key == "filled_file":
                if filled_file_distributor is not None:
                    stored_metadata[key]["distributor_id"] = (
                        filled_file_distributor["id"]
                    )
                else:
                    suggested = _suggest_filled_order_distributor(
                        safe_name, get_workspace_id()
                    )
                    if suggested is not None:
                        suggested_filled_distributor_name = suggested["name"]
                        stored_metadata[key]["suggested_distributor_name"] = (
                            suggested["name"]
                        )
                        stored_metadata[key]["suggested_firm_nick_name"] = (
                            suggested["firm_nick_name"]
                        )
                        stored_metadata[key]["suggested_distributor_id"] = (
                            suggested["id"]
                        )
            if key == "sales_order_file":
                extracted_text = ""
                try:
                    extracted_text = _extract_pdf_text(target_path)
                except Exception:
                    extracted_text = ""
                sales_header = _parse_sales_order_header_fields(extracted_text)
                stored_metadata[key]["sales_order_text"] = (
                    extracted_text[:500] if extracted_text else ""
                )
                stored_metadata[key]["sales_order_header"] = sales_header
                sales_order_buyer_code = sales_header.get("buyer_code")
                sales_order_ref = sales_header.get("order_ref_no")
                sales_order_buyer_name = sales_header.get("buyer_name")
                stored_metadata[key]["order_ref_no"] = sales_order_ref
                stored_metadata[key]["buyer_code"] = sales_order_buyer_code
                stored_metadata[key]["buyer_name"] = sales_order_buyer_name

                # Second signal: the BUYER's GST (excluding our own
                # company's GST, from Company Profile) — cross-checked
                # against the Buyer Code match below. GST is a more
                # reliable signal than free-text buyer name, since it's
                # a legally standardized, unique-per-firm identifier.
                all_gst_numbers = (sales_header.get("all_gst_numbers") or "").split(",")
                all_gst_numbers = [g for g in all_gst_numbers if g]
                own_company_profile = db.get_company_profile(get_workspace_id())
                own_company_gst = (
                    own_company_profile.get("gst_number") if own_company_profile else None
                )
                buyer_gst = _identify_buyer_gst(all_gst_numbers, own_company_gst)
                stored_metadata[key]["buyer_gst"] = buyer_gst

                parsed_sales_order = parse_step2_sales_order_pdf(target_path)
                stored_metadata[key]["parsed_sales_order"] = parsed_sales_order

                matched_by_buyer_code = None
                if sales_order_buyer_code:
                    matched_by_buyer_code = db.get_master_distributor_by_buyer_code(
                        sales_order_buyer_code, workspace_id=get_workspace_id()
                    )
                matched_by_gst = None
                if buyer_gst:
                    matched_by_gst = db.get_master_distributor_by_gst(
                        buyer_gst, workspace_id=get_workspace_id()
                    )

                # Combine both signals: if they AGREE, this is a
                # confident match. If they DISAGREE, flag it clearly
                # rather than silently trusting one over the other —
                # a human still confirms either way (below), but the
                # summary text must be honest about the disagreement.
                signal_agreement = None
                if matched_by_buyer_code and matched_by_gst:
                    signal_agreement = (
                        matched_by_buyer_code["id"] == matched_by_gst["id"]
                    )
                matched_distributor = matched_by_buyer_code or matched_by_gst
                stored_metadata[key]["matched_by_buyer_code"] = (
                    matched_by_buyer_code["name"] if matched_by_buyer_code else None
                )
                stored_metadata[key]["matched_by_gst"] = (
                    matched_by_gst["name"] if matched_by_gst else None
                )
                stored_metadata[key]["signals_agree"] = signal_agreement

                if matched_distributor is not None:
                    stored_metadata[key]["matched_distributor_id"] = (
                        matched_distributor["id"]
                    )
                    stored_metadata[key]["matched_distributor_name"] = (
                        matched_distributor["name"]
                    )
                if sales_order_distributor is not None:
                    stored_metadata[key]["distributor_id"] = (
                        sales_order_distributor["id"]
                    )
                    stored_metadata[key]["distributor_name"] = (
                        sales_order_distributor["name"]
                    )
                elif matched_distributor is not None:
                    stored_metadata[key]["suggested_distributor_id"] = (
                        matched_distributor["id"]
                    )
                    stored_metadata[key]["suggested_distributor_name"] = (
                        matched_distributor["name"]
                    )

                if sales_order_ref and sales_order_distributor is not None:
                    try:
                        tracking_id = db.link_sales_order_to_order_lifecycle(
                            order_ref_no=sales_order_ref,
                            distributor_id=sales_order_distributor["id"],
                            sales_order_file_reference=str(target_path),
                            sales_order_parsed=parsed_sales_order,
                            workspace_id=get_workspace_id(),
                        )
                        stored_metadata[key][
                            "order_lifecycle_tracking_id"
                        ] = tracking_id
                        stored_metadata[key][
                            "linked_sales_order_distributor_id"
                        ] = sales_order_distributor["id"]
                    except Exception as exc:
                        stored_metadata[key][
                            "order_lifecycle_link_error"
                        ] = str(exc)

                if signal_agreement is False:
                    sales_order_linking_summary = (
                        f"Warning: Buyer Code suggests "
                        f"'{matched_by_buyer_code['name']}', but the buyer's GST "
                        f"number suggests '{matched_by_gst['name']}' — these "
                        f"disagree. Please confirm the correct distributor "
                        f"manually before proceeding."
                    )
                elif signal_agreement is True:
                    sales_order_linking_summary = (
                        f"Is this SO for {matched_by_buyer_code['name']}? "
                        f"Both Buyer Code and GST number matched — please confirm."
                    )
                else:
                    sales_order_linking_summary = _build_sales_order_link_summary(
                        selected_sales_order_distributor_name,
                        matched_distributor["name"] if matched_distributor else None,
                        sales_order_buyer_name,
                    )
                stored_metadata[key]["sales_order_linking_summary"] = (
                    sales_order_linking_summary
                )
            if key == "invoice_file":
                extracted_text = ""
                try:
                    extracted_text = _extract_pdf_text(target_path)
                except Exception:
                    extracted_text = ""
                invoice_header = _parse_sales_order_header_fields(extracted_text)
                stored_metadata[key]["commercial_invoice_text"] = (
                    extracted_text[:500] if extracted_text else ""
                )
                stored_metadata[key]["invoice_order_ref_no"] = invoice_header.get(
                    "order_ref_no"
                )
                stored_metadata[key]["invoice_buyer_code"] = invoice_header.get(
                    "buyer_code"
                )
                stored_metadata[key]["invoice_buyer_name"] = invoice_header.get(
                    "buyer_name"
                )
                parsed_invoice = parse_step3_invoice_pdf(target_path)
                stored_metadata[key]["parsed_commercial_invoice"] = parsed_invoice
            if key == "order_file":
                if not order_sheet_name or not order_sheet_category:
                    report = json.dumps(
                        {
                            "status": "error",
                            "message": "Order sheet name and category are required for stage 1 uploads.",
                        },
                        indent=2,
                    )
                    progress_summary = (
                        "Order sheet name and category are required for stage 1 uploads."
                    )
                    return render_template_string(
                        HTML_TEMPLATE,
                        report=report,
                        report_data=json.loads(report),
                        progress_summary=progress_summary,
                        locked_rules_summary=locked_rules_summary,
                        sync_status=json.dumps({}, indent=2),
                        search_query=search_query,
                        search_results=search_results,
                        distributor_options=distributor_options,
                        suggested_filled_distributor_name=suggested_filled_distributor_name,
                        selected_filled_distributor_name=selected_filled_distributor_name,
                        selected_filled_distributor_id=selected_filled_distributor_id,
                        selected_sales_order_distributor_id=selected_sales_order_distributor_id,
                        selected_sales_order_distributor_name=selected_sales_order_distributor_name,
                        sales_order_linking_summary=sales_order_linking_summary,
                    )
                try:
                    order_sheet_fingerprint = _fingerprint_file(target_path)
                    order_sheet_id = db.add_order_sheet(
                        name=order_sheet_name,
                        category=order_sheet_category,
                        file_reference=str(target_path),
                        workspace_id=get_workspace_id(),
                        is_active=order_sheet_is_active,
                        content_fingerprint=order_sheet_fingerprint,
                    )
                    stored_metadata[key]["order_sheet_id"] = order_sheet_id
                    session["verification_order_sheet_id"] = order_sheet_id
                    persisted_order_sheet_ids.append(order_sheet_id)
                except Exception as exc:
                    stored_metadata[key]["order_sheet_error"] = str(exc)
            try:
                upload_record_id = db.save_distributor_order_upload(
                    verification_session_id=session.get("verification_session_id")
                    or "",
                    distributor_name=inferred_distributor_name,
                    stage_key=key,
                    file_type=detected_file_type,
                    filename=safe_name,
                    file_path=str(target_path),
                    metadata=stored_metadata[key],
                )
                stored_metadata[key]["upload_record_id"] = upload_record_id
                persisted_upload_ids.append(upload_record_id)
            except Exception as exc:
                stored_metadata[key]["persistence_error"] = str(exc)

        session["verification_files"] = stored_files
        session["verification_file_metadata"] = stored_metadata
        session.modified = True

        uploaded_count = sum(
            1
            for key in ["order_file", "filled_file", "sales_order_file", "invoice_file"]
            if stored_files.get(key)
        )
        progress_lines = [
            f"Captured files ({uploaded_count}/4): {', '.join(sorted([key for key in stored_files if stored_files.get(key)])) if stored_files else 'none'}"
        ]
        step_labels = {
            "order_file": "Order sheet",
            "filled_file": "Order filled",
            "sales_order_file": "Sales order",
            "invoice_file": "Commercial invoice",
        }
        next_step = None
        for key in ["order_file", "filled_file", "sales_order_file", "invoice_file"]:
            if not stored_files.get(key):
                next_step = step_labels.get(key)
                break
        if next_step:
            progress_lines.append(f"Next step: upload {next_step}")
        else:
            progress_lines.append(
                "All four files are captured. Verification can now run."
            )
        if stored_metadata:
            readable_metadata = "; ".join(
                f"{key} -> {meta.get('stage')} [{meta.get('file_type')}] {meta.get('filename')} ({meta.get('distributor_name') or 'unassigned'})"
                for key, meta in sorted(stored_metadata.items())
            )
            progress_lines.append(f"Recognized uploads: {readable_metadata}")
        if persisted_upload_ids:
            progress_lines.append(f"Persisted upload records: {persisted_upload_ids}")
        progress_summary = "\n".join(progress_lines)

        current_status = "idle"
        current_msg = "No files uploaded"
        if workflow_action == "stage1":
            current_status = "stage-1-saved"
            current_msg = (
                "Common order sheet saved. Distributor files can be attached next."
            )
            report_payload = {
                "status": current_status,
                "message": current_msg,
                "uploaded_files": sorted(
                    [key for key in stored_files if stored_files.get(key)]
                ),
                "uploaded_documents": stored_metadata,
                "next_step": next_step,
            }
            if stored_files.get("order_file"):
                report_payload["step1"] = {
                    "status": "saved",
                    "reason": "common_order_sheet_attached",
                }
            report = json.dumps(report_payload, indent=2)
        elif workflow_action == "stage2":
            if stored_files.get("order_file") and stored_files.get("filled_file"):
                try:
                    step1_result = compare_step1(
                        stored_files.get("order_file"), stored_files.get("filled_file")
                    )
                except Exception as exc:
                    step1_result = {"status": "error", "error": str(exc)}
                current_status = "stage-2-checked"
                current_msg = (
                    "Distributor filled order checked against the common order sheet."
                )
                report = json.dumps(
                    {
                        "status": current_status,
                        "message": current_msg,
                        "step1": step1_result,
                        "uploaded_files": sorted(
                            [key for key in stored_files if stored_files.get(key)]
                        ),
                        "uploaded_documents": stored_metadata,
                        "next_step": next_step,
                    },
                    indent=2,
                )
            else:
                current_status = "error"
                current_msg = "Stage 2 requires both order_file and filled_file"
                report = json.dumps(
                    {
                        "status": current_status,
                        "message": current_msg,
                        "uploaded_files": sorted(
                            [key for key in stored_files if stored_files.get(key)]
                        ),
                        "uploaded_documents": stored_metadata,
                    },
                    indent=2,
                )
        elif workflow_action == "stage3":
            if stored_files.get("filled_file") and stored_files.get("sales_order_file"):
                try:
                    step2_result = compare_step2(
                        stored_files.get("filled_file"),
                        stored_files.get("sales_order_file"),
                    )
                except Exception as exc:
                    step2_result = {"status": "error", "error": str(exc)}
                current_status = "stage-3-checked"
                current_msg = (
                    "Sales order checked against distributor-wise filled order."
                )
                report = json.dumps(
                    {
                        "status": current_status,
                        "message": current_msg,
                        "step2": step2_result,
                        "uploaded_files": sorted(
                            [key for key in stored_files if stored_files.get(key)]
                        ),
                        "uploaded_documents": stored_metadata,
                        "next_step": next_step,
                    },
                    indent=2,
                )
            else:
                current_status = "error"
                current_msg = "Stage 3 requires filled_file and sales_order_file"
                report = json.dumps(
                    {
                        "status": current_status,
                        "message": current_msg,
                        "uploaded_files": sorted(
                            [key for key in stored_files if stored_files.get(key)]
                        ),
                        "uploaded_documents": stored_metadata,
                    },
                    indent=2,
                )
        elif workflow_action == "stage4":
            if stored_files.get("sales_order_file") and stored_files.get(
                "invoice_file"
            ):
                try:
                    step3_result = compare_step3(
                        stored_files.get("sales_order_file"),
                        stored_files.get("invoice_file"),
                    )
                except Exception as exc:
                    step3_result = {"status": "error", "error": str(exc)}

                # Check whether a matching SO exists and prepare a
                # confirmation summary — this NEVER auto-links. The
                # founder was explicit that CI-to-SO linking (which
                # drives achievement/revenue figures) must always be a
                # human-confirmed action, never silent, even when the
                # verification comparison and reference number both
                # look clean.
                invoice_ref = stored_metadata.get("invoice_file", {}).get(
                    "invoice_order_ref_no"
                )
                linked_invoice = False
                invoice_link_error = None
                requires_confirmation = False
                confirmation_summary = None

                if step3_result.get("status") == "ok" and invoice_ref:
                    matching_so = db.get_order_lifecycle_by_order_ref_no(
                        invoice_ref, workspace_id=get_workspace_id()
                    )
                    if matching_so:
                        requires_confirmation = True
                        confirmation_summary = (
                            f"This Commercial Invoice's Sales Order Number "
                            f"('{invoice_ref}') matches an existing Sales Order "
                            f"on file (tracking #{matching_so['tracking_id']}). "
                            f"Confirm to link this CI and record the achievement — "
                            f"nothing is saved automatically."
                        )
                        stored_metadata["invoice_file"]["pending_link"] = {
                            "order_ref_no": invoice_ref,
                            "tracking_id": matching_so["tracking_id"],
                            "commercial_invoice_file_reference": str(
                                stored_files.get("invoice_file")
                            ),
                            "commercial_invoice_parsed": stored_metadata.get(
                                "invoice_file", {}
                            ).get("parsed_commercial_invoice", {}),
                        }
                    else:
                        invoice_link_error = (
                            f"No existing Sales Order found on file matching "
                            f"reference '{invoice_ref}'. Please verify the Sales "
                            f"Order was uploaded first, or link manually."
                        )
                        stored_metadata["invoice_file"][
                            "commercial_invoice_link_error"
                        ] = invoice_link_error
                elif step3_result.get("status") == "ok" and not invoice_ref:
                    invoice_link_error = "Commercial invoice order reference number could not be extracted from the PDF"
                    stored_metadata["invoice_file"][
                        "commercial_invoice_link_error"
                    ] = invoice_link_error
                else:
                    if invoice_ref:
                        stored_metadata["invoice_file"][
                            "commercial_invoice_link_error"
                        ] = (
                            "Commercial invoice comparison did not verify cleanly. "
                            "Manual review is required before linking."
                        )

                current_status = "stage-4-checked"
                current_msg = "Commercial invoice checked against sales order."
                report_payload = {
                    "status": current_status,
                    "message": current_msg,
                    "step3": step3_result,
                    "uploaded_files": sorted(
                        [key for key in stored_files if stored_files.get(key)]
                    ),
                    "uploaded_documents": stored_metadata,
                    "next_step": next_step,
                }
                if requires_confirmation:
                    report_payload["requires_confirmation"] = True
                    report_payload["confirmation_summary"] = confirmation_summary
                    report_payload["pending_link"] = stored_metadata["invoice_file"].get(
                        "pending_link"
                    )
                if invoice_link_error:
                    report_payload["commercial_invoice_link_error"] = (
                        invoice_link_error
                    )
                report = json.dumps(report_payload, indent=2)
            else:
                current_status = "error"
                current_msg = "Stage 4 requires sales_order_file and invoice_file"
                report = json.dumps(
                    {
                        "status": current_status,
                        "message": current_msg,
                        "uploaded_files": sorted(
                            [key for key in stored_files if stored_files.get(key)]
                        ),
                        "uploaded_documents": stored_metadata,
                    },
                    indent=2,
                )
        elif uploaded_count == 0:
            report = json.dumps(
                {"status": "idle", "message": "No files uploaded"}, indent=2
            )
        elif uploaded_count < 4:
            step1_result = None
            if stored_files.get("order_file") and stored_files.get("filled_file"):
                try:
                    step1_result = compare_step1(
                        stored_files.get("order_file"), stored_files.get("filled_file")
                    )
                except Exception as exc:
                    step1_result = {"status": "error", "error": str(exc)}
            current_status = "partial-verification"
            current_msg = "Captured step-by-step. Partial verification. Please upload all four files for a full report."
            report = json.dumps(
                {
                    "status": current_status,
                    "message": current_msg,
                    "uploaded_files": sorted(
                        [key for key in stored_files if stored_files.get(key)]
                    ),
                    "uploaded_documents": stored_metadata,
                    "next_step": next_step,
                    "step1": step1_result
                    or {"status": "skipped", "reason": "missing_excel_inputs"},
                },
                indent=2,
            )
        else:
            try:
                verified_data = run_full_verification(
                    stored_files["order_file"],
                    stored_files["filled_file"],
                    stored_files["sales_order_file"],
                    stored_files["invoice_file"],
                )
                current_status = verified_data.get("status", "completed")
                current_msg = verified_data.get(
                    "message", "Full verification completed successfully"
                )
                report = json.dumps(verified_data, indent=2)
            except Exception as exc:
                current_status = "error"
                current_msg = str(exc)
                report = json.dumps(
                    {"status": "error", "message": current_msg}, indent=2
                )

    report_data = None
    if report:
        try:
            report_data = json.loads(report)
        except Exception:
            report_data = None

    if search_query:
        search_results = json.dumps(
            CentralizedDB(_db_path()).global_search(search_query),
            indent=2,
        )

    sync_status = json.dumps({}, indent=2)
    return render_template_string(
        HTML_TEMPLATE,
        report=report,
        report_data=report_data,
        progress_summary=progress_summary,
        locked_rules_summary=locked_rules_summary,
        sync_status=sync_status,
        search_query=search_query,
        search_results=search_results,
        distributor_options=distributor_options,
        suggested_filled_distributor_name=suggested_filled_distributor_name,
        selected_filled_distributor_name=selected_filled_distributor_name,
        selected_filled_distributor_id=selected_filled_distributor_id,
        selected_sales_order_distributor_id=selected_sales_order_distributor_id,
        selected_sales_order_distributor_name=selected_sales_order_distributor_name,
        sales_order_linking_summary=sales_order_linking_summary,
    )


@data_blueprint.route("/bale-calculator", methods=["GET", "POST"])
@require_jwt_auth
def bale_calculator() -> str:
    calculator_result = None
    if request.method == "POST":
        payload = {
            "total_bales": request.form.get("total_bales", type=float),
            "packs_per_bale": request.form.get("packs_per_bale", type=float),
            "pcs_per_pack": request.form.get("pcs_per_pack", type=float),
            "number_of_designs": request.form.get("number_of_designs", type=float),
            "number_of_colors": request.form.get("number_of_colors", type=float),
        }
        calculator_result = json.dumps(calculate_bale_to_pieces(**payload), indent=2)
    return Response(calculator_result or "", mimetype="application/json")


@data_blueprint.route("/search")
@require_jwt_auth
def search() -> Response:
    query = request.args.get("q", "")
    # SECURITY: workspace_id must be passed through — without it this
    # searches and returns results mixed across EVERY workspace, the
    # same class of cross-tenant leak already found and fixed for
    # bulk_upload_masters/export functions earlier in this project.
    results = CentralizedDB(_db_path()).global_search(query, workspace_id=get_workspace_id())
    return Response(json.dumps(results, indent=2), mimetype="application/json")


@data_blueprint.route("/api/v1/order-fulfillment/confirm-ci-link", methods=["POST"])
@require_jwt_auth
def confirm_ci_so_link() -> Response:
    """
    The ONLY place a Commercial Invoice actually gets linked to a
    Sales Order — deliberately requires an explicit person-initiated
    call (never triggered automatically from the stage4 upload
    handler). On a confirmed link, this ALSO creates the achievement
    record right away — "auto-achievement generation" is satisfied by
    doing it immediately after the one point where a human has
    genuinely confirmed the link is correct, not by silently guessing
    at upload time.
    """
    payload = request.get_json(silent=True) or {}
    order_ref_no = (payload.get("order_ref_no") or "").strip()
    commercial_invoice_file_reference = payload.get("commercial_invoice_file_reference")
    commercial_invoice_parsed = payload.get("commercial_invoice_parsed") or {}
    amount = payload.get("amount")
    notes = payload.get("notes")

    if not order_ref_no:
        return Response(
            json.dumps({"success": False, "error": {"message": "order_ref_no is required"}}),
            mimetype="application/json",
            status=400,
        )

    db = CentralizedDB(_db_path())
    workspace_id = get_workspace_id()

    try:
        tracking_id = db.link_commercial_invoice_to_order_lifecycle(
            order_ref_no=order_ref_no,
            commercial_invoice_file_reference=commercial_invoice_file_reference,
            commercial_invoice_parsed=commercial_invoice_parsed,
            commercial_invoice_date=None,
            workspace_id=workspace_id,
        )
    except ValueError as exc:
        return Response(
            json.dumps({"success": False, "error": {"message": str(exc)}}),
            mimetype="application/json",
            status=404,
        )

    achievement_id = None
    if amount is not None:
        try:
            current_user = getattr(request, "user", None)
            created_by = current_user.get("user_id") if isinstance(current_user, dict) else None
            achievement_id = db.create_achievement(
                order_lifecycle_tracking_id=tracking_id,
                amount=float(amount),
                currency="INR",
                source="ci",
                created_by=created_by,
                workspace_id=workspace_id,
                notes=notes,
            )
        except Exception as exc:
            # The link itself succeeded — achievement-creation failing
            # (e.g. a bad amount value) should not roll that back, but
            # must be visible to the caller.
            return Response(
                json.dumps({
                    "success": True,
                    "data": {
                        "tracking_id": tracking_id,
                        "achievement_id": None,
                        "achievement_error": str(exc),
                    },
                }),
                mimetype="application/json",
            )

    return Response(
        json.dumps({
            "success": True,
            "data": {"tracking_id": tracking_id, "achievement_id": achievement_id},
        }),
        mimetype="application/json",
    )


@data_blueprint.route("/articles")
@require_jwt_auth
def articles() -> str:
    db = CentralizedDB(_db_path())
    articles = json.dumps(db.list_articles_by_category(workspace_id=get_workspace_id()), indent=2)
    return render_template_string(
        '<h1>Article Master</h1><pre>{{ articles }}</pre><p><a href="/">Back</a></p>',
        articles=articles,
    )


@data_blueprint.route("/api/v1/ai-assistant/query", methods=["GET", "POST"])
@require_jwt_auth
def ai_assistant_query() -> Response:
    payload = request.get_json(silent=True) or {}
    query = str(
        payload.get("query")
        or payload.get("queryText")
        or request.args.get("queryText")
        or request.args.get("query")
        or ""
    ).strip()
    if not query:
        return Response(
            json.dumps({"error": "Missing query"}),
            status=400,
            mimetype="application/json",
        )

    query = query.replace("ask jarvis", "").replace("talk to jarvis", "").strip()
    db = CentralizedDB(_db_path())
    intent = infer_ai_intent(query)
    answer = "Jarvis at your service, Boss. No matching information found."

    if intent == "last_visit":
        entity = (
            query.split("to", 1)[-1].strip().rstrip("?") if "to" in query else query
        )
        distributor = db.get_master_distributor_by_name(
            entity, workspace_id=get_workspace_id()
        )
        if distributor:
            last_visit = db.get_last_visit_date("distributor", distributor["id"])
            answer = f"Jarvis at your service, Boss. Last visit to {distributor['name']} was on {last_visit or 'no recorded visit'}."
        else:
            answer = f"Jarvis at your service, Boss. I could not find a distributor named {entity}."
    elif intent == "alerts":
        alerts = db.list_data_entry_alerts()
        answer = (
            f"Jarvis at your service, Boss. You have {len(alerts)} active alerts."
            if alerts
            else "Jarvis at your service, Boss. No active alerts found."
        )
    elif intent == "pjp":
        suggestions = db.get_morning_suggestion_list("2026-06-26")
        answer = (
            f"Jarvis at your service, Boss. There are {len(suggestions)} retailer visits suggested today."
            if suggestions
            else "Jarvis at your service, Boss. No PJP suggestions found."
        )
    elif intent == "purchase_trends":
        distributor = db.get_master_distributor_by_name(
            query, workspace_id=get_workspace_id()
        )
        if distributor:
            logs = db.build_distributor_purchase_behavior_logs(distributor["id"])
            answer = f"Jarvis at your service, Boss. Top behavior log for {distributor['name']}: {logs[0]['category_name'] if logs else 'no data'}."
        else:
            answer = "Jarvis at your service, Boss. I couldn't identify the distributor for purchase trend analysis."
    else:
        search_results = db.global_search(query)
        answer = f"Jarvis at your service, Boss. {json.dumps(search_results, ensure_ascii=False)}"

    return Response(
        json.dumps(
            {"intent": intent, "query": query, "answer": answer}, ensure_ascii=False
        ),
        mimetype="application/json",
    )


@data_blueprint.route("/alerts")
@require_jwt_auth
def alerts() -> str:
    db = CentralizedDB(_db_path())
    rows = db.list_data_entry_alerts(workspace_id=get_workspace_id())
    return render_template_string(
        '<h1>Data Entry Alerts</h1><pre>{{ rows }}</pre><p><a href="/">Back</a></p>',
        rows=json.dumps(rows, indent=2),
    )


@data_blueprint.route("/credit-policy", methods=["GET", "POST"])
@require_jwt_auth
def credit_policy() -> str:
    db = CentralizedDB(_db_path())
    workspace_id = get_workspace_id()
    message = None
    if request.method == "POST":
        distributor_id = request.form.get("distributor_id", type=int)
        max_credit_limit = request.form.get("max_credit_limit", type=float)
        credit_days_allowed = request.form.get("credit_days_allowed", type=int)
        account_status = request.form.get("account_status", "ACTIVE")
        if distributor_id is not None:
            try:
                db.upsert_credit_control(
                    distributor_id,
                    max_credit_limit=max_credit_limit,
                    credit_days_allowed=credit_days_allowed,
                    account_status=account_status,
                    workspace_id=workspace_id,
                )
                message = "Credit policy saved"
            except ValueError:
                message = "Distributor not found in your workspace"
    policy_rows = db.list_credit_control(workspace_id=workspace_id)
    return render_template_string(
        """
        <h1>Credit Policy</h1>
        <form method=\"post\">
          <label>Distributor</label><input name=\"distributor_id\" type=\"number\" />
          <label>Max Credit Limit</label><input name=\"max_credit_limit\" type=\"number\" step=\"0.01\" />
          <label>Credit Days Allowed</label><input name=\"credit_days_allowed\" type=\"number\" />
          <label>Account Status</label><input name=\"account_status\" value=\"ACTIVE\" />
          <button type=\"submit\">Save</button>
        </form>
        {% if message %}<p>{{ message }}</p>{% endif %}
        <pre>{{ policy_rows }}</pre><p><a href=\"/\">Back</a></p>
        """,
        message=message,
        policy_rows=json.dumps(policy_rows, indent=2),
    )


@data_blueprint.route("/purchase-behavior")
@require_jwt_auth
def purchase_behavior() -> str:
    db = CentralizedDB(_db_path())
    workspace_id = get_workspace_id()
    distributor_id = request.args.get("distributor_id", type=int)
    if distributor_id is None:
        return jsonify({
            "success": False,
            "error": "distributor_id is required",
        }), 400

    # This table is keyed by distributor_id, not workspace_id directly —
    # verify the requested distributor actually belongs to this workspace
    # before building/returning its behavior logs. Without this check,
    # any authenticated user could view any workspace's distributor
    # purchase behavior just by guessing a distributor_id.
    with sqlite3.connect(_db_path()) as conn:
        owner = conn.execute(
            "SELECT id FROM master_distributors WHERE id = ? AND workspace_id = ?",
            (distributor_id, workspace_id),
        ).fetchone()
    if not owner:
        return jsonify({"success": False, "error": "Distributor not found"}), 404

    logs = db.build_distributor_purchase_behavior_logs(distributor_id)
    return render_template_string(
        '<h1>Distributor Purchase Behavior</h1><pre>{{ logs }}</pre><p><a href="/">Back</a></p>',
        logs=json.dumps(logs, indent=2),
    )


@data_blueprint.route("/pwa-dashboard")
def pwa_dashboard() -> Response:
    return Response(
        """
        <!doctype html>
        <html>
        <head>
          <meta charset=\"utf-8\"> 
          <title>Jarvis PWA Dashboard</title>
          <link rel=\"manifest\" href=\"/manifest.json\">
          <meta name=\"theme-color\" content=\"#0f172a\">
        </head>
        <body style=\"font-family: system-ui, sans-serif; background: #020617; color: #eef2ff; margin: 2rem;\">
          <h1>Jarvis PWA Dashboard</h1>
          <p>Progressive web app shell is available.</p>
          <p><a href=\"/manifest.json\" style=\"color: #facc15\">View manifest</a></p>
        </body>
        </html>
        """,
        mimetype="text/html",
    )


@data_blueprint.route("/api/v1/dashboard/summary")
@require_jwt_auth
def dashboard_summary() -> Response:
    workspace_id = get_workspace_id()
    db = CentralizedDB(_db_path())
    alerts = db.list_data_entry_alerts(workspace_id=workspace_id)
    tasks = db.list_workflow_todos_for_party(
        party_id=1, party_type="distributor", workspace_id=workspace_id
    )
    dashboard_payload = db.get_dashboard_payload(workspace_id=workspace_id)
    payload = {
        "overview": {
            "distributors": dashboard_payload["masters"]["distributors"],
            "retailers": dashboard_payload["masters"]["retailers"],
            "alerts": len(alerts),
            "tasks": len(tasks),
        },
        "suggestions": db.get_morning_suggestion_list("2026-06-26")[:3],
    }
    return Response(
        json.dumps(payload, ensure_ascii=False), mimetype="application/json"
    )


@data_blueprint.route("/api/ui/dashboard-config", methods=["GET", "PUT"])
@require_jwt_auth
def dashboard_config() -> Response:
    if request.method == "GET":
        return Response(
            json.dumps(load_dashboard_config(), ensure_ascii=False),
            mimetype="application/json",
        )

    request_data = request.get_json(silent=True)
    if not isinstance(request_data, dict):
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "Request body must be a valid JSON object",
                }
            ),
            400,
        )

    allowed_keys = {
        "brand_name",
        "app_name",
        "dashboard_title",
        "short_name",
        "theme_color",
        "background_color",
        "enabled_modules",
    }
    update_data: dict[str, Any] = {
        key: value
        for key, value in request_data.items()
        if key in allowed_keys
    }

    if "enabled_modules" in update_data and not isinstance(
        update_data["enabled_modules"], list
    ):
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "enabled_modules must be a list",
                }
            ),
            400,
        )

    if not update_data:
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "No valid config fields provided",
                }
            ),
            400,
        )

    new_config = save_dashboard_config(update_data)
    return Response(
        json.dumps(new_config, ensure_ascii=False), mimetype="application/json"
    )


@data_blueprint.route("/manifest.json")
def manifest() -> Response:
    config = load_dashboard_config()
    return Response(
        json.dumps(
            {
                "name": config.get("app_name", "Jarvis Business Platform"),
                "short_name": config.get("short_name", "Jarvis"),
                "start_url": "/pwa-dashboard",
                "display": "standalone",
                "background_color": config.get("background_color", "#020617"),
                "theme_color": config.get("theme_color", "#020617"),
                "icons": [
                    {
                        "src": "/icon-192.svg",
                        "sizes": "192x192",
                        "type": "image/svg+xml",
                    },
                    {
                        "src": "/icon-512.svg",
                        "sizes": "512x512",
                        "type": "image/svg+xml",
                    },
                ],
            }
        ),
        mimetype="application/json",
    )


@data_blueprint.route("/service-worker.js")
def service_worker() -> Response:
    return Response(
        (Path(__file__).resolve().parent.parent / "service-worker.js").read_text(
            encoding="utf-8"
        ),
        mimetype="application/javascript",
    )


@data_blueprint.route("/icon-192.svg")
def icon_192() -> Response:
    return Response(
        (Path(__file__).resolve().parent.parent / "icon-192.svg").read_text(
            encoding="utf-8"
        ),
        mimetype="image/svg+xml",
    )


@data_blueprint.route("/icon-512.svg")
def icon_512() -> Response:
    return Response(
        (Path(__file__).resolve().parent.parent / "icon-512.svg").read_text(
            encoding="utf-8"
        ),
        mimetype="image/svg+xml",
    )


@data_blueprint.route("/workflow-gps")
@require_jwt_auth
def workflow_gps() -> str:
    db = CentralizedDB(_db_path())
    workspace_id = get_workspace_id()
    party_id = request.args.get("party_id", type=int) or 1
    party_type = request.args.get("party_type", "distributor") or "distributor"
    tasks = db.list_workflow_todos_for_party(
        party_id=party_id, party_type=party_type, workspace_id=workspace_id
    )
    gps_logs = []
    with sqlite3.connect(db.db_path) as conn:
        rows = conn.execute(
            "SELECT log_id, visit_log_id, captured_latitude, captured_longitude, geofenced_status, device_timestamp, created_at FROM gps_visit_verification_logs WHERE workspace_id = ? ORDER BY log_id DESC LIMIT 20",
            (workspace_id,),
        ).fetchall()
        gps_logs = [
            {
                "log_id": row[0],
                "visit_log_id": row[1],
                "captured_latitude": row[2],
                "captured_longitude": row[3],
                "geofenced_status": row[4],
                "device_timestamp": row[5],
                "created_at": row[6],
            }
            for row in rows
        ]
    return render_template_string(
        """
        <h1>Workflow & GPS Monitor</h1>
        <form method="get">
          <label>Party ID</label><input name="party_id" type="number" value="{{ party_id }}" />
          <label>Party Type</label><input name="party_type" value="{{ party_type }}" />
          <button type="submit">Load</button>
        </form>
        <h2>Checklist</h2>
        <pre>{{ tasks }}</pre>
        <h2>GPS Verification History</h2>
        <pre>{{ gps_logs }}</pre>
        <p><a href="/">Back</a></p>
        """,
        party_id=party_id,
        party_type=party_type,
        tasks=json.dumps(tasks, indent=2),
        gps_logs=json.dumps(gps_logs, indent=2),
    )


@data_blueprint.route("/article-master")
@require_jwt_auth
def article_master_search() -> str:
    db_path = _db_path()
    workspace_id = get_workspace_id()
    query = request.args.get("q", "").strip()
    size_filter = request.args.get("size", "").strip()
    articles = []
    if query or size_filter:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            sql = "SELECT * FROM article_master_v2 WHERE workspace_id = ?"
            params = [workspace_id]
            if query:
                sql += " AND (brand LIKE ? OR product LIKE ? OR print_style LIKE ?)"
                params += [f"%{query}%", f"%{query}%", f"%{query}%"]
            if size_filter:
                sql += " AND size = ?"
                params.append(size_filter)
            sql += " ORDER BY brand, size"
            articles = [dict(r) for r in conn.execute(sql, params).fetchall()]
    return render_template_string(
        """
        <!doctype html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>NEXORA |Article Master</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 2rem; }
            .card { border: 1px solid #ddd; padding: 1rem; margin-bottom: 1rem; border-radius: 8px; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 0.9rem; }
            th { background: #f0f0f0; }
            .search-box { display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; }
            .search-box input, .search-box select { padding: 0.5rem; font-size: 1rem; }
            .search-box button { padding: 0.5rem 1.5rem; background: #0d6efd; color: white; border: none; border-radius: 4px; cursor: pointer; }
            .badge { background: #e9ecef; padding: 2px 8px; border-radius: 4px; font-size: 0.8rem; }
          </style>
        </head>
        <body>
          <h1>📦 Article Master</h1>
          <div class="card">
            <form method="get" action="/article-master">
              <div class="search-box">
                <input type="text" name="q" value="{{ query }}" placeholder="Brand search karo... (e.g. Cardinal, Epigram)" style="width: 300px;" />
                <select name="size">
                  <option value="">-- All Sizes --</option>
                  {% for s in ['SB BS','DB BS','KS BS','KB FS','DB FS','DBL BS','DB Comf'] %}
                  <option value="{{ s }}" {% if size_filter == s %}selected{% endif %}>{{ s }}</option>
                  {% endfor %}
                </select>
                <button type="submit">🔍 Search</button>
                <a href="/article-master" style="padding: 0.5rem;">Clear</a>
              </div>
            </form>
          </div>
          {% if articles %}
          <div class="card">
            <p><strong>{{ articles|length }} articles मिले</strong></p>
            <div style="overflow-x:auto;">
              <table>
                <thead>
                  <tr>
                    <th>Brand</th><th>TC</th><th>Size</th><th>BS Size</th>
                    <th>Product</th><th>Print Style</th><th>Bale</th><th>Colors</th>
                    <th>MRP (₹)</th><th>Selling Price (₹)</th><th>PTR (₹)</th>
                    <th>Retailer Margin</th><th>Ex-Mill (₹)</th>
                  </tr>
                </thead>
                <tbody>
                  {% for a in articles %}
                  <tr>
                    <td><strong>{{ a.brand }}</strong></td>
                    <td><span class="badge">{{ a.tc }}</span></td>
                    <td><span class="badge">{{ a.size }}</span></td>
                    <td>{{ a.bs_size }}</td>
                    <td>{{ a.product }}</td>
                    <td>{{ a.print_style }}</td>
                    <td>{{ a.bale_size }}</td>
                    <td>{{ a.colors }}</td>
                    <td><strong>₹{{ "%.0f"|format(a.mrp) }}</strong></td>
                    <td>₹{{ "%.0f"|format(a.selling_price) }}</td>
                    <td>₹{{ "%.0f"|format(a.ptr) }}</td>
                    <td>{{ "%.0f"|format(a.retailer_margin * 100) }}%</td>
                    <td>₹{{ "%.0f"|format(a.exmill_price) }}</td>
                  </tr>
                  {% endfor %}
                </tbody>
              </table>
            </div>
          </div>
          {% elif query or size_filter %}
          <div class="card"><p>कोई article नहीं मिला।</p></div>
          {% else %}
          <div class="card"><p>Brand name या size search करो। उदाहरण: "Cardinal", "KS BS"</p></div>
          {% endif %}
          <p><a href="/">← Back</a> | <a href="/analytics">Analytics</a> | <a href="/reports">Reports</a></p>
        </body>
        </html>
        """,
        query=query,
        size_filter=size_filter,
        articles=articles,
    )


@data_blueprint.route("/retailer-download")
@require_jwt_auth
def retailer_download_page():
    db_path = _db_path()
    workspace_id = get_workspace_id()
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        distributors = [
            dict(r)
            for r in conn.execute(
                "SELECT id, firm_name, firm_nick_name FROM master_distributors WHERE workspace_id = ? ORDER BY firm_name",
                (workspace_id,),
            ).fetchall()
        ]
    return render_template_string(
        """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>NEXORA |Retailer Download</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 2rem; }
    .card { border: 1px solid #ddd; padding: 1rem; margin-bottom: 1rem; border-radius: 8px; }
    .btn { display: inline-block; padding: 0.5rem 1.2rem; border-radius: 4px; text-decoration: none; margin: 0.3rem; font-size: 0.9rem; }
    .btn-excel { background: #1d6f42; color: white; }
    .btn-csv { background: #0d6efd; color: white; }
    table { border-collapse: collapse; width: 100%; margin-top: 1rem; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background: #f0f0f0; }
  </style>
</head>
<body>
  <h1>📥 Retailer Download</h1>

  <div class="card">
    <h2>All Retailers Download</h2>
    <p>Total 750 retailers — sabhi distributors ke saath</p>
    <a href="/retailer-download/excel?dist_id=all" class="btn btn-excel">📊 Excel Download (All)</a>
    <a href="/retailer-download/csv?dist_id=all" class="btn btn-csv">📄 CSV Download (All)</a>
  </div>

  <div class="card">
    <h2>Distributor Wise Download</h2>
    <table>
      <thead>
        <tr><th>Distributor</th><th>Nick Name</th><th>Excel</th><th>CSV</th></tr>
      </thead>
      <tbody>
        {% for d in distributors %}
        <tr>
          <td>{{ d.firm_name }}</td>
          <td>{{ d.firm_nick_name }}</td>
          <td><a href="/retailer-download/excel?dist_id={{ d.id }}" class="btn btn-excel">📊 Excel</a></td>
          <td><a href="/retailer-download/csv?dist_id={{ d.id }}" class="btn btn-csv">📄 CSV</a></td>
        </tr>
        {% endfor %}
      </tbody>
    </table>
  </div>

  <p><a href="/">← Back</a> | <a href="/analytics">Analytics</a></p>
</body>
</html>
""",
        distributors=distributors,
    )


@data_blueprint.route("/retailer-download/excel")
@require_jwt_auth
def retailer_download_excel():
    db_path = _db_path()
    workspace_id = get_workspace_id()
    dist_id = request.args.get("dist_id", "all")
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        if dist_id == "all":
            rows = conn.execute(
                """
                SELECT r.id, r.retailer_code, r.name as retailer_name, r.owner_name,
                d.firm_name as distributor_name, d.firm_nick_name,
                r.location, r.phone_number, r.email, r.address, r.gst_no
                FROM master_retailers r
                LEFT JOIN master_distributors d ON r.distributor_id = d.id
                WHERE r.workspace_id = ? AND (d.workspace_id = ? OR d.workspace_id IS NULL)
                ORDER BY d.firm_name, r.name
            """,
                (workspace_id, workspace_id),
            ).fetchall()
            filename = "all_retailers.xlsx"
        else:
            # Verify the requested distributor actually belongs to this workspace
            # before returning ANY retailer rows for it — prevents a caller from
            # pulling another workspace's retailers by guessing a dist_id.
            owner_check = conn.execute(
                "SELECT id FROM master_distributors WHERE id = ? AND workspace_id = ?",
                (dist_id, workspace_id),
            ).fetchone()
            if not owner_check:
                return jsonify({"success": False, "error": "Distributor not found"}), 404

            rows = conn.execute(
                """
                SELECT r.id, r.retailer_code, r.name as retailer_name, r.owner_name,
                d.firm_name as distributor_name, d.firm_nick_name,
                r.location, r.phone_number, r.email, r.address, r.gst_no
                FROM master_retailers r
                LEFT JOIN master_distributors d ON r.distributor_id = d.id
                WHERE r.distributor_id = ? AND r.workspace_id = ?
                ORDER BY r.name
            """,
                (dist_id, workspace_id),
            ).fetchall()
            dist_name = rows[0]["firm_nick_name"] if rows else str(dist_id)
            filename = f"{dist_name}_retailers.xlsx"
    import pandas as _pd

    df = _pd.DataFrame([dict(r) for r in rows])
    output = io.BytesIO()
    with _pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Retailers")
    output.seek(0)
    return Response(
        output.read(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@data_blueprint.route("/retailer-download/csv")
@require_jwt_auth
def retailer_download_csv():
    import csv as _csv
    from io import StringIO as _StringIO

    db_path = _db_path()
    workspace_id = get_workspace_id()
    dist_id = request.args.get("dist_id", "all")
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        if dist_id == "all":
            rows = conn.execute(
                """
                SELECT r.id, r.retailer_code, r.name as retailer_name, r.owner_name,
                d.firm_name as distributor_name, d.firm_nick_name,
                r.location, r.phone_number, r.email, r.address, r.gst_no
                FROM master_retailers r
                LEFT JOIN master_distributors d ON r.distributor_id = d.id
                WHERE r.workspace_id = ? AND (d.workspace_id = ? OR d.workspace_id IS NULL)
                ORDER BY d.firm_name, r.name
            """,
                (workspace_id, workspace_id),
            ).fetchall()
            filename = "all_retailers.csv"
        else:
            # Verify the requested distributor actually belongs to this workspace
            # before returning ANY retailer rows for it.
            owner_check = conn.execute(
                "SELECT id FROM master_distributors WHERE id = ? AND workspace_id = ?",
                (dist_id, workspace_id),
            ).fetchone()
            if not owner_check:
                return jsonify({"success": False, "error": "Distributor not found"}), 404

            rows = conn.execute(
                """
                SELECT r.id, r.retailer_code, r.name as retailer_name, r.owner_name,
                d.firm_name as distributor_name, d.firm_nick_name,
                r.location, r.phone_number, r.email, r.address, r.gst_no
                FROM master_retailers r
                LEFT JOIN master_distributors d ON r.distributor_id = d.id
                WHERE r.distributor_id = ? AND r.workspace_id = ?
                ORDER BY r.name
            """,
                (dist_id, workspace_id),
            ).fetchall()
            dist_name = rows[0]["firm_nick_name"] if rows else str(dist_id)
            filename = f"{dist_name}_retailers.csv"
    output = _StringIO()
    if rows:
        writer = _csv.DictWriter(output, fieldnames=list(dict(rows[0]).keys()))
        writer.writeheader()
        writer.writerows([dict(r) for r in rows])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
