import base64
import logging
import os
from datetime import datetime
from pathlib import Path

from flask import Blueprint, jsonify, redirect, request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

from app.db import db
from app.encryption import CredentialEncryption
from app.models import User
from app.business_platform import EventEngine
from app.routes.auth import get_workspace_id, require_jwt_auth
from app.storage.oauth import GoogleDriveOAuth

logger = logging.getLogger(__name__)

gdrive_bp = Blueprint("gdrive", __name__, url_prefix="/api/gdrive")


def _get_current_user():
    """
    Returns the authenticated user dict from request.user.

    Raises RuntimeError if request.user is missing rather than
    silently defaulting to any user_id. Callers (route handlers)
    are responsible for catching this and returning a clean 401.
    """
    user = getattr(request, "user", None)
    if isinstance(user, dict):
        return user
    raise RuntimeError("Authentication required")


def _normalize_user_id(user_id: str):
    return int(user_id) if isinstance(user_id, str) and user_id.isdigit() else user_id


def _get_client_secrets_path() -> str:
    if GoogleDriveOAuth.CLIENT_SECRETS_FILE:
        return GoogleDriveOAuth.CLIENT_SECRETS_FILE
    return str(Path(__file__).resolve().parents[2] / "instance/client_secrets.json")


@gdrive_bp.route("/connect/<user_id>", methods=["GET"])
@require_jwt_auth
def start_gdrive_connect(user_id):
    user_id = _normalize_user_id(user_id)

    # CRITICAL: _get_current_user() can raise RuntimeError if request.user
    # was never set (e.g. AUTH_ENABLED=false and no session/JWT context).
    # This MUST be caught here — letting it propagate as an uncaught
    # exception is not a security fix, it's just a crash. A crash is not
    # the same as a clean, intentional rejection.
    try:
        current_user = _get_current_user()
    except RuntimeError as e:
        return jsonify({"success": False, "error": str(e)}), 401

    if current_user["user_id"] != user_id:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        workspace_id = get_workspace_id()
    except RuntimeError as e:
        return jsonify({"success": False, "error": str(e)}), 401

    try:
        redirect_uri = request.host_url.rstrip("/") + "/api/gdrive/callback"
        flow = InstalledAppFlow.from_client_secrets_file(
            _get_client_secrets_path(),
            scopes=GoogleDriveOAuth.SCOPES,
        )
        flow.redirect_uri = redirect_uri

        state_data = f"{user_id}:{workspace_id}:{int(datetime.utcnow().timestamp())}"
        state = base64.b64encode(state_data.encode()).decode()

        auth_uri, _ = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            state=state,
        )

        logger.info(f"User {user_id} initiated GDrive OAuth")
        return jsonify({"auth_uri": auth_uri, "user_id": user_id})
    except Exception as e:
        logger.error(f"OAuth flow error: {e}")
        return jsonify({"error": str(e)}), 500


@gdrive_bp.route("/callback", methods=["GET"])
def gdrive_callback():
    """OAuth callback - with debugging"""

    try:
        auth_code = request.args.get("code")
        state = request.args.get("state")
        error = request.args.get("error")

        logger.info("OAuth Callback received:")
        logger.info(f"  auth_code: {auth_code[:20] if auth_code else None}...")
        logger.info(f"  state: {state}")
        logger.info(f"  error: {error}")

        if error:
            logger.error(f"OAuth error from Google: {error}")
            return jsonify({"error": f"OAuth error: {error}"}), 400

        if not state:
            logger.error("No state parameter in callback")
            return jsonify({"error": "Missing state parameter"}), 400

        if not auth_code:
            logger.error("No authorization code in callback")
            return jsonify({"error": "Missing authorization code"}), 400

        try:
            logger.info(f"Attempting to decode state: {state}")
            state_data = base64.b64decode(state).decode()
            logger.info(f"Decoded state_data: {state_data}")
            parts = state_data.split(":")
            if len(parts) != 3:
                raise ValueError("Invalid state payload")
            user_id, workspace_id, timestamp = parts
            logger.info(f"Extracted user_id: {user_id}, workspace_id: {workspace_id}")
        except Exception as decode_error:
            logger.error(f"State decode failed: {decode_error}")
            logger.error(f"State value was: {state}")
            return jsonify({"error": f"Invalid state: {decode_error}"}), 400

        if not user_id or user_id == "":
            logger.error("user_id is empty after decode")
            return jsonify({"error": "user_id not found in state"}), 400

        logger.info(f"Processing OAuth for user_id: {user_id}")

        redirect_uri = request.host_url.rstrip("/") + "/api/gdrive/callback"
        flow = InstalledAppFlow.from_client_secrets_file(
            _get_client_secrets_path(),
            scopes=GoogleDriveOAuth.SCOPES,
        )
        flow.redirect_uri = redirect_uri
        flow.fetch_token(code=auth_code)

        credentials = flow.credentials
        logger.info("Got credentials from Google")

        user = User.query.get(user_id)
        if not user:
            logger.error(f"User {user_id} not found in database")
            return jsonify({"error": f"User {user_id} not found"}), 404

        encryption = CredentialEncryption()
        user.gdrive_access_token = encryption.encrypt(credentials.token)
        user.gdrive_refresh_token = encryption.encrypt(credentials.refresh_token or "")
        user.gdrive_connected = True
        user.gdrive_email = ""

        try:
            drive_service = build("drive", "v3", credentials=credentials)
            profile = drive_service.about().get(fields="user(emailAddress)").execute()
            user.gdrive_email = profile.get("user", {}).get("emailAddress", "") or ""
        except Exception:
            logger.warning("Unable to resolve Google Drive user email after OAuth connect")

        db.session.commit()

        EventEngine.emit(
            "gdrive_connected",
            workspace_id,
            {"user_id": user_id, "google_email": user.gdrive_email},
        )

        logger.info(f"✅ User {user_id} successfully connected GDrive: {user.gdrive_email}")

        return jsonify({
            "status": "connected",
            "user_id": user_id,
            "email": user.gdrive_email,
        })

    except Exception as e:
        logger.error(f"Unexpected error in callback: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500


@gdrive_bp.route("/status/<user_id>", methods=["GET"])
@require_jwt_auth
def get_gdrive_status(user_id):
    user_id = _normalize_user_id(user_id)

    try:
        current_user = _get_current_user()
    except RuntimeError as e:
        return jsonify({"success": False, "error": str(e)}), 401

    if current_user["user_id"] != user_id:
        return jsonify({"error": "Unauthorized"}), 401

    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    return jsonify({
        "is_connected": bool(user.gdrive_connected),
        "email": user.gdrive_email or None,
        "user_id": user_id,
    })


@gdrive_bp.route("/disconnect/<user_id>", methods=["POST"])
@require_jwt_auth
def disconnect_gdrive(user_id):
    user_id = _normalize_user_id(user_id)

    try:
        current_user = _get_current_user()
    except RuntimeError as e:
        return jsonify({"success": False, "error": str(e)}), 401

    if current_user["user_id"] != user_id:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404

        user.gdrive_access_token = None
        user.gdrive_refresh_token = None
        user.gdrive_connected = False
        user.gdrive_email = None
        db.session.commit()

        EventEngine.emit(
            "gdrive_disconnected",
            current_user.get("workspace_id", "default"),
            {"user_id": user_id},
        )

        logger.info(f"User {user_id} disconnected GDrive")
        return jsonify({"status": "disconnected"})
    except Exception as e:
        logger.error(f"Disconnect error: {e}")
        return jsonify({"error": str(e)}), 500
