import sqlite3
import pathlib
from werkzeug.security import generate_password_hash, check_password_hash


db_path = pathlib.Path('instance/centralized_db.sqlite3')
con = sqlite3.connect(str(db_path))
con.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL)")
cols = [r[1] for r in con.execute("PRAGMA table_info(users)")]
for column_name, definition in [('role', "TEXT DEFAULT 'admin'"), ('workspace_id', "TEXT DEFAULT 'default'"), ('status', "TEXT DEFAULT 'active'")]:
    if column_name not in cols:
        con.execute(f"ALTER TABLE users ADD COLUMN {column_name} {definition}")

password_hash = generate_password_hash('mobile_test_admin_123')
con.execute(
    "INSERT INTO users (username, password_hash, role, workspace_id, status, created_at) VALUES (?, ?, 'admin', 'default', 'active', datetime('now')) ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash, role=excluded.role, workspace_id=excluded.workspace_id, status=excluded.status",
    ('mobile_test_admin', password_hash),
)
con.commit()
row = con.execute("SELECT username, password_hash, role, status, workspace_id FROM users WHERE username='mobile_test_admin'").fetchone()
print('record', {'username': row[0], 'password_hash': row[1], 'role': row[2], 'status': row[3], 'workspace_id': row[4]})
print('password_match', check_password_hash(row[1], 'mobile_test_admin_123'))
print('status', row[3])
con.close()
