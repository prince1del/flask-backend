from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.three_step_verification import _extract_pdf_text
from app.routes.data import _parse_sales_order_header_fields
from centralized_db_system.db import CentralizedDB
root=Path(__file__).resolve().parents[1]
base=root/'instance'/'verification_uploads'
if not base.exists():
    print('no upload dir', base)
    raise SystemExit(0)

sessions=[]
for s in base.iterdir():
    if not s.is_dir():
        continue
    files={f.name:f for f in s.iterdir() if f.is_file()}
    if all(any(name.startswith(k+'_') for name in files) for k in ['order_file','filled_file','sales_order_file','invoice_file']):
        sessions.append((s, files))

sessions.sort(key=lambda item: max(f.stat().st_mtime for f in item[1].values()), reverse=True)
print('found', len(sessions), 'full sessions')
db=CentralizedDB('centralized_db.sqlite3')
summary = {
    'total': 0,
    'buyer_code_matches': 0,
    'name_matches': 0,
    'retailer_to_distributor_matches': 0,
    'unmatched': 0,
}

for s, files in sessions[:100]:
    sales_name = [n for n in files if n.startswith('sales_order_file_')][0]
    sales_pdf = files[sales_name]
    text = ''
    try:
        text = _extract_pdf_text(sales_pdf)
    except Exception:
        text = ''
    hdr = _parse_sales_order_header_fields(text)
    buyer_code = hdr.get('buyer_code')
    buyer_name = hdr.get('buyer_name')
    match = None
    matched_by = None
    if buyer_code:
        match = db.get_master_distributor_by_buyer_code(buyer_code)
        matched_by = 'buyer_code' if match else None
    # Fallback: try matching by buyer_name if buyer_code not found
    if match is None and buyer_name:
        match = db.get_master_distributor_by_name(buyer_name)
        matched_by = 'name' if match else None

    print('SESSION', s.name)
    print('  sales_file:', sales_name)
    print('  header:', hdr)

    summary['total'] += 1
    if match:
        print('  matched distributor:', match.get('id'), match.get('name'), f'(matched_by={matched_by})')
        if matched_by == 'buyer_code':
            summary['buyer_code_matches'] += 1
        elif matched_by == 'name':
            summary['name_matches'] += 1
    else:
        # try retailer name lookup -> distributor link
        retailer = None
        if buyer_name:
            retailer = db.get_master_retailer_by_name(buyer_name)
        if retailer and retailer.get('distributor_id'):
            dist = db.get_master_distributor(int(retailer.get('distributor_id')))
            if dist:
                print('  matched distributor via retailer:', dist.get('id'), dist.get('name'))
                summary['retailer_to_distributor_matches'] += 1
            else:
                print('  matched distributor: None')
                summary['unmatched'] += 1
        else:
            print('  matched distributor: None')
            summary['unmatched'] += 1

    print('  text snippet:', (text or '').replace('\n',' | ')[:240])
    print('---')

print('SUMMARY:', summary)
